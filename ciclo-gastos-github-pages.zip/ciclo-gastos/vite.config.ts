import { defineConfig } from "vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { viteSingleFile } from "vite-plugin-singlefile";
import path from "node:path";

const singleFile = process.env.SINGLE_FILE === "1";

export default defineConfig({
  base: "./",
  plugins: [
    tailwindcss(),
    viteReact(),
    ...(singleFile ? [viteSingleFile()] : []),
  ],
  build: singleFile
    ? { cssCodeSplit: false, assetsInlineLimit: 100000000 }
    : undefined,
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "./src"),
    },
  },
});
