import { MONTH_NAMES } from "./types";

export function formatEUR(n: number): string {
  return (
    n.toLocaleString("es-ES", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }) + " €"
  );
}

export function formatDateEs(epochMs: number | null | undefined): string {
  if (epochMs === null || epochMs === undefined) return "";
  const d = new Date(epochMs);
  if (Number.isNaN(d.getTime())) return "";
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  return `${dd}/${mm}/${d.getFullYear()}`;
}

export function formatDayMonth(epochMs: number | null | undefined): string {
  if (epochMs === null || epochMs === undefined) return "";
  const d = new Date(epochMs);
  if (Number.isNaN(d.getTime())) return "";
  const dd = String(d.getDate()).padStart(2, "0");
  const month = MONTH_NAMES[d.getMonth()].slice(0, 3);
  return `${dd} ${month}`;
}

export function capitalize(s: string): string {
  const t = s.trim();
  if (!t) return t;
  return t.charAt(0).toUpperCase() + t.slice(1);
}

export function slugifyKeyword(kw: string): string {
  return kw
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}
