import {
  CATEGORY_ONLY_RULES,
  COMERCIO_ALIASES,
  COMERCIO_CANONICAL_LABELS,
  FIXED_CATEGORIES,
  GROUP_RULES,
  type CategoryRule,
  type ExpenseGroup,
  type MonthData,
  type NamedItem,
  type PayCatRule,
  type RawRow,
} from "./types";
import { capitalize, slugifyKeyword } from "./format";
import {
  normalizeComercioKey,
  normalizeConceptText,
  parseRawDate,
  reviveRawDate,
} from "./parse";

export function allCategories(custom: NamedItem[]): NamedItem[] {
  return [...FIXED_CATEGORIES, ...custom];
}

export function catIdValid(
  id: string | null | undefined,
  custom: NamedItem[],
): boolean {
  return !!id && allCategories(custom).some((c) => c.id === id);
}

export function normalizedCategory(
  g: ExpenseGroup,
  custom: NamedItem[],
): string {
  return catIdValid(g.category, custom) ? (g.category as string) : "sin";
}

export function resolveGroupForConcept(
  lowerConcept: string,
  categoryDefaults: CategoryRule[],
): { key: string; label: string; category: string | null } | null {
  const fixedRule = GROUP_RULES.find((r) =>
    r.keywords.some((kw) => lowerConcept.includes(kw)),
  );
  if (fixedRule) {
    return {
      key: fixedRule.key,
      label: fixedRule.label,
      category: fixedRule.defaultCategory || null,
    };
  }
  const normConcept = normalizeConceptText(lowerConcept);
  const userRule = categoryDefaults.find((r) => {
    const rk = normalizeConceptText(r.keyword);
    return (
      !!rk &&
      !!normConcept &&
      (normConcept.includes(rk) || rk.includes(normConcept))
    );
  });
  if (userRule) {
    return {
      key: `user-${slugifyKeyword(userRule.keyword)}`,
      label: capitalize(userRule.keyword),
      category: userRule.category,
    };
  }
  return null;
}

export function matchPayCategoryDefault(
  lowerConcept: string,
  payCategoryDefaults: PayCatRule[],
): PayCatRule | null {
  const normConcept = normalizeConceptText(lowerConcept);
  return (
    payCategoryDefaults.find((r) =>
      normConcept.includes(normalizeConceptText(r.keyword)),
    ) || null
  );
}

export function categoryOnlyDefaultFor(lowerConcept: string): string | null {
  const rule = CATEGORY_ONLY_RULES.find((r) =>
    lowerConcept.includes(r.keyword),
  );
  return rule ? rule.category : null;
}

export function defaultsForNewGroup(
  lowerConcept: string,
  payCategoryDefaults: PayCatRule[],
): { category: string | null; metodoPago: string | null } {
  const userRule = matchPayCategoryDefault(lowerConcept, payCategoryDefaults);
  let category: string | null = null;
  if (userRule && userRule.category) category = userRule.category;
  else category = categoryOnlyDefaultFor(lowerConcept);
  const metodoPago = userRule?.metodoPago ? userRule.metodoPago : "tarjeta";
  return { category, metodoPago };
}

export function groupKeyForConcept(
  concept: string,
  categoryDefaults: CategoryRule[],
): { key: string; label: string; category: string | null } {
  const lower = concept.toLowerCase();
  const resolved = resolveGroupForConcept(lower, categoryDefaults);
  if (resolved) return resolved;
  const key = normalizeConceptText(lower) || lower;
  return { key, label: concept, category: null };
}

export function canonicalComercioKey(str: string): string {
  const key = normalizeComercioKey(str);
  return COMERCIO_ALIASES[key] || key;
}

export function canonicalComercioLabel(key: string, fallback: string): string {
  return COMERCIO_CANONICAL_LABELS[key] || fallback;
}

export function findOldGroupForConcept(
  months: Record<string, MonthData>,
  monthKey: string,
  key: string,
  groupLabel: string,
): ExpenseGroup | null {
  const oldMonth = months[monthKey];
  if (!oldMonth) return null;
  if (oldMonth.groups[key]) return oldMonth.groups[key];
  const normTarget = normalizeConceptText(groupLabel);
  if (!normTarget) return null;
  let best: ExpenseGroup | null = null;
  for (const g of Object.values(oldMonth.groups)) {
    const normG = normalizeConceptText(g.label);
    if (!normG) continue;
    const isSame = normG === normTarget;
    const isSimilar =
      !isSame &&
      normG.length >= 4 &&
      normTarget.length >= 4 &&
      (normG.includes(normTarget) || normTarget.includes(normG));
    if (isSame || isSimilar) {
      best = g;
      break;
    }
  }
  return best;
}

export function rawRowsForGroup(
  rawRows: RawRow[],
  mKey: string,
  cKey: string,
  categoryDefaults: CategoryRule[],
): RawRow[] {
  let startTime = -Infinity;
  let endTime = Infinity;
  if (/^\d{4}-\d{2}$/.test(mKey)) {
    const [y, m] = mKey.split("-").map(Number);
    startTime = new Date(y, m - 2, 28).getTime();
    endTime = new Date(y, m - 1, 27, 23, 59, 59).getTime();
  }
  return rawRows.filter((r) => {
    const d = parseRawDate(reviveRawDate(r.t));
    if (!d) return false;
    const t = d.getTime();
    if (t < startTime || t > endTime) return false;
    const lowerConcept = String(r.c || "").toLowerCase();
    const resolved = resolveGroupForConcept(lowerConcept, categoryDefaults);
    const rawKey = resolved
      ? resolved.key
      : normalizeConceptText(lowerConcept) || lowerConcept;
    return rawKey === cKey;
  });
}
