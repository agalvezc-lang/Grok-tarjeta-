import { dateToEpoch, parseAmount, parseRawDate } from "./parse";
import { getMonthInfo } from "./cycle";
import {
  defaultsForNewGroup,
  groupKeyForConcept,
} from "./groups";
import type {
  CategoryRule,
  ExpenseGroup,
  MonthData,
  PayCatRule,
  RawRow,
} from "./types";

type SheetCell = string | number | boolean | Date | null | undefined;
type SheetRow = SheetCell[];

function findHeaderRow(rows: SheetRow[]): number {
  const keywords = [
    "concepto",
    "importe",
    "fecha",
    "saldo",
    "apunte",
    "descripcion",
    "descripción",
    "cargo",
    "abono",
    "comercio",
  ];
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i] ?? [];
    const nonEmpty = row.filter((c) => String(c ?? "").trim() !== "");
    if (nonEmpty.length < 3) continue;
    const lower = nonEmpty.map((c) => String(c).trim().toLowerCase());
    if (lower.some((c) => keywords.some((k) => c.includes(k)))) return i;
  }
  return 0;
}

export type ImportResult = {
  fileMonths: Record<string, { label: string; groups: Record<string, ExpenseGroup> }>;
  rawRows: RawRow[];
  validRows: number;
  skipped: number;
  duplicates: number;
};

function dedupKey(t: RawRow["t"], c: string, a: number): string {
  const epoch = dateToEpoch(t);
  const day = epoch !== null ? Math.floor(epoch / 86400000) : String(t ?? "");
  const concept = String(c || "")
    .trim()
    .toLocaleLowerCase("es-ES")
    .replace(/\s+/g, " ");
  const amount = Math.round(a * 100);
  return `${day}|${concept}|${amount}`;
}

export function processSheetRows(
  rows: SheetRow[],
  categoryDefaults: CategoryRule[],
  payCategoryDefaults: PayCatRule[],
  existingRawRows: RawRow[] = [],
): ImportResult {
  const filtered = rows.filter((r) =>
    r.some((c) => String(c ?? "").trim() !== ""),
  );
  if (filtered.length < 2) {
    throw new Error("El archivo no tiene datos suficientes.");
  }

  const headerIdx = findHeaderRow(filtered);
  const header = filtered[headerIdx] ?? [];
  const dataRows = filtered.slice(headerIdx + 1);

  const trimmedHeader = header.map((h) => String(h ?? "").trim());

  let amountIdx = trimmedHeader.findIndex((h) =>
    h.toLowerCase().includes("importe"),
  );
  let conceptIdx = trimmedHeader.findIndex((h) =>
    h.toLowerCase().includes("concepto"),
  );
  if (conceptIdx === -1) {
    conceptIdx = trimmedHeader.findIndex((h) =>
      h.toLowerCase().includes("comercio"),
    );
  }

  let cargoIdx = -1;
  let abonoIdx = -1;
  if (amountIdx === -1) {
    cargoIdx = trimmedHeader.findIndex((h) => h.toLowerCase().includes("cargo"));
    abonoIdx = trimmedHeader.findIndex((h) => h.toLowerCase().includes("abono"));
    if (cargoIdx === -1 && abonoIdx === -1) amountIdx = 0;
  }
  if (conceptIdx === -1) {
    conceptIdx = trimmedHeader.length - 1;
    if (conceptIdx === amountIdx) conceptIdx = trimmedHeader.length - 2;
  }

  const emisorIdx = trimmedHeader.findIndex((h) =>
    h.toLowerCase().includes("emisor"),
  );

  let dateIdx = header.findIndex((h) =>
    String(h ?? "").trim().toLowerCase().startsWith("fecha"),
  );
  if (dateIdx === -1) {
    dateIdx = header.findIndex((h) =>
      String(h ?? "").trim().toLowerCase().includes("fecha valor"),
    );
  }
  if (dateIdx === -1) {
    dateIdx = header.findIndex((h) =>
      String(h ?? "").trim().toLowerCase().includes("fecha"),
    );
  }

  const fileMonths: ImportResult["fileMonths"] = {};
  const rawRows: RawRow[] = [];
  let skipped = 0;
  let validRows = 0;
  let duplicates = 0;
  const seenKeys = new Set(
    existingRawRows.map((r) => dedupKey(r.t, r.c, r.a)),
  );

  dataRows.forEach((row) => {
    if (!row.some((c) => String(c ?? "").trim() !== "")) return;
    let amount: number | null;
    if (amountIdx !== -1) {
      amount = parseAmount(row[amountIdx]);
    } else {
      const cargoVal = cargoIdx !== -1 ? parseAmount(row[cargoIdx]) : null;
      const abonoVal = abonoIdx !== -1 ? parseAmount(row[abonoIdx]) : null;
      if (cargoVal !== null && cargoVal !== 0) amount = cargoVal;
      else if (abonoVal !== null && abonoVal !== 0) amount = -abonoVal;
      else amount = null;
    }
    let concept = String(row[conceptIdx] ?? "")
      .trim()
      .replace(/^"|"$/g, "");
    if (emisorIdx !== -1) {
      const emisor = String(row[emisorIdx] ?? "")
        .trim()
        .replace(/^"|"$/g, "");
      if (emisor) concept = concept ? `${emisor} — ${concept}` : emisor;
    }
    if (amount === null || !concept) {
      skipped++;
      return;
    }

    const dateVal = dateIdx !== -1 ? row[dateIdx] : null;
    const rawT = dateVal instanceof Date ? dateVal.getTime() : (dateVal as RawRow["t"]);
    const key = dedupKey(rawT, concept, amount);
    if (seenKeys.has(key)) {
      duplicates++;
      return;
    }
    seenKeys.add(key);
    validRows++;

    rawRows.push({ t: rawT, c: concept, a: amount });
    const { key: monthKey, label: monthLabel } = getMonthInfo(dateVal, true);
    if (!fileMonths[monthKey]) fileMonths[monthKey] = { label: monthLabel, groups: {} };

    const lowerConcept = concept.toLowerCase();
    const resolved = groupKeyForConcept(concept, categoryDefaults);
    const groupKey = resolved.key;
    const groupLabel = resolved.label;
    const g = fileMonths[monthKey].groups;
    if (!g[groupKey]) {
      const defs = resolved.category
        ? { category: resolved.category, metodoPago: "tarjeta" as const }
        : defaultsForNewGroup(lowerConcept, payCategoryDefaults);
      g[groupKey] = {
        label: groupLabel,
        total: 0,
        category: defs.category,
        metodoPago: defs.metodoPago,
        date: null,
      };
    }
    g[groupKey].total += amount;
    const rowEpoch = dateToEpoch(dateVal);
    if (rowEpoch !== null && (g[groupKey].date === null || rowEpoch > g[groupKey].date!)) {
      g[groupKey].date = rowEpoch;
    }
  });

  if (Object.keys(fileMonths).length === 0 && duplicates === 0) {
    throw new Error("No se encontraron filas válidas de importe/concepto.");
  }

  return { fileMonths, rawRows, validRows, skipped, duplicates };
}

export function mergeImportedMonths(
  existing: Record<string, MonthData>,
  fileMonths: ImportResult["fileMonths"],
): { months: Record<string, MonthData>; addedNew: number } {
  const months: Record<string, MonthData> = { ...existing };
  let addedNew = 0;
  Object.entries(fileMonths).forEach(([mKey, mData]) => {
    if (!months[mKey]) months[mKey] = { label: mData.label, order: [], groups: {} };
    const bucket = months[mKey];
    Object.entries(mData.groups).forEach(([cKey, g]) => {
      if (!bucket.groups[cKey]) {
        bucket.groups[cKey] = { ...g };
        bucket.order.push(cKey);
        addedNew++;
      }
    });
  });
  return { months, addedNew };
}

export async function readSpreadsheetFile(file: File): Promise<SheetRow[]> {
  const XLSX = await import("xlsx");
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(new Uint8Array(buf), { type: "array", cellDates: true });
  const sheet = wb.Sheets[wb.SheetNames[0] ?? ""];
  if (!sheet) throw new Error("El archivo no contiene ninguna hoja.");
  return XLSX.utils.sheet_to_json(sheet, {
    header: 1,
    raw: true,
    defval: "",
  }) as SheetRow[];
}

export function parseRawDateSafe(v: unknown): Date | null {
  return parseRawDate(v);
}
