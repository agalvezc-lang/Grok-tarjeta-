export type TicketGuess = {
  date: string | null;
  amount: number | null;
  merchant: string | null;
  rawText: string;
};

function extraerFechaTique(texto: string): string | null {
  const re = /\b(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})\b/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(texto)) !== null) {
    const d = parseInt(m[1], 10);
    const mo = parseInt(m[2], 10);
    const y = m[3].length === 2 ? 2000 + parseInt(m[3], 10) : parseInt(m[3], 10);
    if (d < 1 || d > 31 || mo < 1 || mo > 12) continue;
    const fecha = new Date(y, mo - 1, d);
    if (
      Number.isNaN(fecha.getTime()) ||
      fecha.getFullYear() < 2000 ||
      fecha > new Date(Date.now() + 86400000)
    )
      continue;
    return fecha.toISOString().slice(0, 10);
  }
  return null;
}

function extraerImporteTique(texto: string): number | null {
  const numRe = /(\d{1,3}(?:[.\s]\d{3})*|\d+)[,.](\d{2})\b/g;
  const lineas = texto.split(/\r?\n/);
  for (const linea of lineas) {
    if (/total/i.test(linea) && !/subtotal/i.test(linea)) {
      numRe.lastIndex = 0;
      let m: RegExpExecArray | null;
      let ultimo: RegExpExecArray | null = null;
      while ((m = numRe.exec(linea)) !== null) ultimo = m;
      if (ultimo) {
        return parseFloat(ultimo[1].replace(/[.\s]/g, "") + "." + ultimo[2]);
      }
    }
  }
  let mejor: number | null = null;
  let m2: RegExpExecArray | null;
  numRe.lastIndex = 0;
  while ((m2 = numRe.exec(texto)) !== null) {
    const val = parseFloat(m2[1].replace(/[.\s]/g, "") + "." + m2[2]);
    if (val > 0 && val < 10000 && (mejor === null || val > mejor)) mejor = val;
  }
  return mejor;
}

function extraerComercioTique(texto: string): string | null {
  const lineas = texto
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  for (const linea of lineas.slice(0, 6)) {
    if (
      /^[A-ZÁÉÍÓÚÑ][A-ZÁÉÍÓÚÑ0-9 .,&'-]{2,40}$/i.test(linea) &&
      /[a-zA-ZÁÉÍÓÚÑáéíóúñ]{3,}/.test(linea) &&
      !/^\d/.test(linea)
    ) {
      return linea;
    }
  }
  return lineas[0] || null;
}

type TesseractMod = {
  recognize: (
    file: File | Blob | string,
    lang: string,
  ) => Promise<{ data: { text: string } }>;
};

export async function analyzeTicket(file: File): Promise<TicketGuess> {
  let Tesseract: TesseractMod;
  try {
    const spec = "tesseract.js";
    Tesseract = (await import(/* @vite-ignore */ spec)) as TesseractMod;
  } catch {
    throw new Error("El lector de tiques no está disponible. Rellena a mano.");
  }
  const { data } = await Tesseract.recognize(file, "spa");
  const texto = (data && data.text) || "";
  if (!texto.trim()) throw new Error("Sin texto detectado.");
  return {
    date: extraerFechaTique(texto),
    amount: extraerImporteTique(texto),
    merchant: extraerComercioTique(texto),
    rawText: texto,
  };
}
