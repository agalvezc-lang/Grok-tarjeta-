import type {
  CategoryRule,
  ComercioMerge,
  ExpenseGroup,
  MonthData,
  NamedItem,
  PeriodRange,
  RawRow,
  SummaryCluster,
} from "./types";
import {
  canonicalComercioKey,
  canonicalComercioLabel,
  groupKeyForConcept,
  normalizedCategory,
  resolveGroupForConcept,
} from "./groups";
import { dayStart, normalizeConceptText, parseRawDate, reviveRawDate } from "./parse";
import { ALL_FIXED_PAYMENT_METHODS } from "./types";

export type PeriodGroup = ExpenseGroup & { key: string };

export function computePeriodSummary(
  rawRows: RawRow[],
  months: Record<string, MonthData>,
  range: PeriodRange,
  categoryDefaults: CategoryRule[],
): { order: string[]; groups: Record<string, ExpenseGroup>; count: number } {
  const startTime = dayStart(range.start);
  const endTime = dayStart(range.end);
  const groups: Record<string, ExpenseGroup> = {};
  const order: string[] = [];
  let count = 0;

  if (rawRows.length > 0) {
    rawRows.forEach((r) => {
      const d = parseRawDate(reviveRawDate(r.t));
      if (!d) return;
      const t = d.getTime();
      if (t < startTime || t > endTime) return;
      const resolved = groupKeyForConcept(r.c, categoryDefaults);
      if (!groups[resolved.key]) {
        groups[resolved.key] = {
          label: resolved.label,
          total: 0,
          category: resolved.category,
          metodoPago: "tarjeta",
          date: null,
        };
        order.push(resolved.key);
      }
      groups[resolved.key].total += r.a;
      const epoch = d.getTime();
      const g = groups[resolved.key];
      if (g.date === null || epoch > g.date) g.date = epoch;
      count++;
    });
    overlayMetaFromMonths(groups, months);
  } else {
    Object.entries(months).forEach(([mKey, mData]) => {
      const [y, m] = mKey.split("-").map(Number);
      if (Number.isNaN(y) || Number.isNaN(m)) return;
      const cycleStart = new Date(y, m - 2, 28).getTime();
      const cycleEnd = new Date(y, m - 1, 27).getTime();
      if (cycleEnd < startTime || cycleStart > endTime) return;
      mData.order.forEach((cKey) => {
        const g = mData.groups[cKey];
        if (!g) return;
        if (!groups[cKey]) {
          groups[cKey] = { ...g, total: 0 };
          order.push(cKey);
        }
        groups[cKey].total += g.total;
        count++;
      });
    });
  }

  return { order, groups, count };
}

function overlayMetaFromMonths(
  groups: Record<string, ExpenseGroup>,
  months: Record<string, MonthData>,
) {
  const byKey: Record<string, ExpenseGroup> = {};
  const byNorm: Record<string, ExpenseGroup> = {};
  Object.values(months).forEach((m) => {
    Object.entries(m.groups).forEach(([k, g]) => {
      byKey[k] = g;
      byNorm[normalizeConceptText(g.label)] = g;
    });
  });
  Object.entries(groups).forEach(([k, g]) => {
    const meta = byKey[k] || byNorm[normalizeConceptText(g.label)];
    if (!meta) return;
    if (meta.category) g.category = meta.category;
    if (meta.metodoPago) g.metodoPago = meta.metodoPago;
    if (meta.label) g.label = meta.label;
  });
}

export function computeGlobalConceptSummary(
  rawRows: RawRow[],
  months: Record<string, MonthData>,
  merges: ComercioMerge[],
  categoryDefaults: CategoryRule[],
  range?: PeriodRange | null,
): SummaryCluster[] {
  const clusters = new Map<
    string,
    {
      key: string;
      label: string;
      total: number;
      origins: Map<string, number>;
      merged?: boolean;
      mergeId?: string;
    }
  >();

  const push = (comercio: string, coste: number) => {
    const resolved = resolveGroupForConcept(comercio.toLowerCase(), categoryDefaults);
    const groupLabel = resolved ? resolved.label : comercio;
    const key = canonicalComercioKey(groupLabel);
    if (!key) return;
    if (!clusters.has(key)) {
      clusters.set(key, {
        key,
        label: canonicalComercioLabel(key, groupLabel),
        total: 0,
        origins: new Map(),
      });
    }
    const c = clusters.get(key)!;
    c.total += coste;
    c.origins.set(groupLabel, (c.origins.get(groupLabel) || 0) + coste);
  };

  if (range && rawRows.length > 0) {
    const startTime = dayStart(range.start);
    const endTime = dayStart(range.end);
    rawRows.forEach((r) => {
      const d = parseRawDate(reviveRawDate(r.t));
      if (!d) return;
      const t = d.getTime();
      if (t < startTime || t > endTime) return;
      const comercio = String(r.c || "").trim();
      if (!comercio) return;
      push(comercio, Number(r.a) || 0);
    });
  } else {
    Object.values(months).forEach((mData) => {
      Object.values(mData.groups).forEach((g) => {
        const comercio = String(g.label || "").trim();
        if (!comercio) return;
        push(comercio, Number(g.total) || 0);
      });
    });
  }

  merges.forEach((merge) => {
    let total = 0;
    const origins = new Map<string, number>();
    let found = false;
    const matchedKeys = new Set<string>();
    clusters.forEach((c, key) => {
      const isExact = merge.keys.includes(key);
      const isSimilar =
        !isExact &&
        merge.keys.some(
          (mk) =>
            mk.length >= 4 &&
            key.length >= 4 &&
            (key.includes(mk) || mk.includes(key)),
        );
      if (isExact || isSimilar) matchedKeys.add(key);
    });
    matchedKeys.forEach((key) => {
      const c = clusters.get(key);
      if (!c) return;
      total += c.total;
      c.origins.forEach((amount, label) => {
        origins.set(label, (origins.get(label) || 0) + amount);
      });
      clusters.delete(key);
      found = true;
    });
    if (found) {
      const mergedKey = "merge:" + merge.id;
      clusters.set(mergedKey, {
        key: mergedKey,
        label: merge.label,
        total,
        merged: true,
        mergeId: merge.id,
        origins,
      });
    }
  });

  return [...clusters.values()]
    .map((c) => ({
      ...c,
      origins: [...c.origins.entries()]
        .map(([label, total]) => ({ label, total }))
        .sort((a, b) => b.total - a.total),
    }))
    .sort((a, b) => b.total - a.total);
}

export function categorySubtotals(
  groups: Record<string, ExpenseGroup>,
  custom: NamedItem[],
): Record<string, number> {
  const totals: Record<string, number> = { sin: 0 };
  custom.concat([
    { id: "personal", label: "Personal" },
    { id: "casa", label: "Casa" },
    { id: "trabajo", label: "Trabajo" },
  ]).forEach((c) => {
    totals[c.id] = totals[c.id] ?? 0;
  });
  Object.values(groups).forEach((g) => {
    const id = normalizedCategory(g, custom);
    totals[id] = (totals[id] || 0) + g.total;
  });
  return totals;
}

export function paymentSubtotals(
  groups: Record<string, ExpenseGroup>,
  custom: NamedItem[],
): Record<string, number> {
  const methods = [...ALL_FIXED_PAYMENT_METHODS, ...custom];
  const totals: Record<string, number> = { sin: 0 };
  methods.forEach((m) => {
    totals[m.id] = 0;
  });
  Object.values(groups).forEach((g) => {
    const id =
      g.metodoPago && methods.some((m) => m.id === g.metodoPago)
        ? g.metodoPago
        : "sin";
    totals[id] = (totals[id] || 0) + g.total;
  });
  return totals;
}

export function findDuplicateCandidates(
  rawRows: RawRow[],
  startTime: number,
  endTime: number,
): { concept: string; amount: number; date: Date | null; count: number }[] {
  const seen: Record<
    string,
    { concept: string; amount: number; date: Date | null; count: number }
  > = {};
  rawRows.forEach((r) => {
    const d = parseRawDate(reviveRawDate(r.t));
    if (!d) return;
    const t = d.getTime();
    if (t < startTime || t > endTime) return;
    const dayKey = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
    const normConcept =
      normalizeConceptText(String(r.c).toLowerCase()) ||
      String(r.c).toLowerCase();
    const key = `${dayKey}|${Number(r.a).toFixed(2)}|${normConcept}`;
    if (!seen[key])
      seen[key] = { concept: r.c, amount: r.a, date: d, count: 0 };
    seen[key].count++;
  });
  return Object.values(seen).filter((x) => x.count > 1);
}

export function findPossibleDuplicate(
  rawRows: RawRow[],
  dateVal: Date,
  concept: string,
  amount: number,
): RawRow | null {
  const target = dayStart(dateVal);
  const normTarget = normalizeConceptText(concept);
  return (
    rawRows.find((r) => {
      const d = parseRawDate(reviveRawDate(r.t));
      if (!d) return false;
      if (dayStart(d) !== target) return false;
      const sameAmount = Math.abs((r.a || 0) - amount) < 0.005;
      const rNorm = normalizeConceptText(r.c);
      const similarConcept =
        !!rNorm &&
        !!normTarget &&
        (rNorm === normTarget ||
          rNorm.includes(normTarget) ||
          normTarget.includes(rNorm));
      return sameAmount || similarConcept;
    }) || null
  );
}
