export function parseSignedAmount(raw: unknown): {
  abs: number | null;
  negative: boolean | null;
} {
  if (raw === null || raw === undefined) return { abs: null, negative: null };
  if (typeof raw === "number")
    return { abs: Math.abs(raw), negative: raw < 0 };
  let s = String(raw).trim();
  if (!s) return { abs: null, negative: null };
  s = s.replace(/[€$]/g, "").trim();
  let negative = false;
  if (/^\(.*\)$/.test(s)) {
    negative = true;
    s = s.replace(/^\(|\)$/g, "");
  } else if (/^-/.test(s)) {
    negative = true;
    s = s.replace(/^-/, "");
  } else if (/-\s*$/.test(s)) {
    negative = true;
    s = s.replace(/-\s*$/, "");
  } else if (/^\+/.test(s)) {
    negative = false;
    s = s.replace(/^\+/, "");
  }
  s = s.trim();
  if (/,\d{1,2}$/.test(s)) {
    s = s.replace(/\./g, "").replace(",", ".");
  } else {
    s = s.replace(/,/g, "");
  }
  const num = parseFloat(s);
  if (Number.isNaN(num)) return { abs: null, negative };
  return { abs: Math.abs(num), negative };
}

export function parseAmount(raw: unknown): number | null {
  return parseSignedAmount(raw).abs;
}

function excelSerialToDate(n: number): Date {
  const utc = Date.UTC(1899, 11, 30) + Math.round(n * 86400000);
  const d = new Date(utc);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

export function parseRawDate(dateVal: unknown): Date | null {
  let d: Date | null = null;
  if (dateVal instanceof Date && !Number.isNaN(dateVal.getTime())) {
    d = dateVal;
  } else if (typeof dateVal === "number") {
    if (dateVal > 1e10) d = new Date(dateVal);
    else if (dateVal > 20000 && dateVal < 80000) d = excelSerialToDate(dateVal);
  } else if (typeof dateVal === "string" && dateVal.trim()) {
    const m = dateVal
      .trim()
      .match(/(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})/);
    if (m) {
      let year = parseInt(m[3], 10);
      if (year < 100) year += 2000;
      d = new Date(year, parseInt(m[2], 10) - 1, parseInt(m[1], 10));
    }
  }
  return d && !Number.isNaN(d.getTime()) ? d : null;
}

export function dateToEpoch(dateVal: unknown): number | null {
  const d = parseRawDate(dateVal);
  return d ? d.getTime() : null;
}

export function reviveRawDate(raw: unknown): unknown {
  if (raw === null || raw === undefined || raw === "") return null;
  if (typeof raw === "number" && raw > 1e10) return new Date(raw);
  return raw;
}

export function normalizeConceptText(str: unknown): string {
  return String(str || "")
    .toLocaleLowerCase("es-ES")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\b\d+\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function normalizeComercioKey(str: unknown): string {
  const key = String(str || "")
    .toLocaleLowerCase("es-ES")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[.,()[\]\-_/:;]/g, " ")
    .replace(/['’‘`´]/g, "")
    .replace(/\b\d+\b/g, " ")
    .replace(/sequura/g, "sequra")
    .replace(/\s+/g, " ")
    .trim();
  return key;
}

export function dayStart(d: Date): number {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}
