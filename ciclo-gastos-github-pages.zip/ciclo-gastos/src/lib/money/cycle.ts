import { MONTH_NAMES, type PeriodRange } from "./types";
import { parseRawDate } from "./parse";

export function getCycleRangeForMonth(
  year: number,
  monthIndex: number,
): PeriodRange {
  const start = new Date(year, monthIndex - 2, 28);
  const end = new Date(year, monthIndex - 1, 27);
  return { start, end };
}

export function getCurrentCycleRange(now = new Date()): PeriodRange {
  return getCycleRangeForMonth(now.getFullYear(), now.getMonth() + 1);
}

export function getPreviousCycleRange(now = new Date()): PeriodRange {
  return getCycleRangeForMonth(now.getFullYear(), now.getMonth());
}

export function cycleKeyFromRange(range: PeriodRange): string {
  const y = range.end.getFullYear();
  const m = String(range.end.getMonth() + 1).padStart(2, "0");
  return `${y}-${m}`;
}

export function cycleLabelFromRange(range: PeriodRange): string {
  const name = MONTH_NAMES[range.end.getMonth()];
  return (
    "Ciclo " +
    name.charAt(0).toUpperCase() +
    name.slice(1) +
    " " +
    range.end.getFullYear()
  );
}

export function rangeFromMonthKey(mKey: string): PeriodRange | null {
  if (!/^\d{4}-\d{2}$/.test(mKey)) return null;
  const [y, m] = mKey.split("-").map(Number);
  return getCycleRangeForMonth(y, m);
}

export function getMonthInfo(
  dateVal: unknown,
  useCycle = true,
): { key: string; label: string } {
  const d = parseRawDate(dateVal);
  if (!d) return { key: "sin-fecha", label: "Sin fecha" };
  let effective: Date;
  if (useCycle) {
    effective =
      d.getDate() >= 28
        ? new Date(d.getFullYear(), d.getMonth() + 1, 1)
        : new Date(d.getFullYear(), d.getMonth(), 1);
  } else {
    effective = d;
  }
  const key = `${effective.getFullYear()}-${String(effective.getMonth() + 1).padStart(2, "0")}`;
  const monthName = MONTH_NAMES[effective.getMonth()];
  const label =
    (useCycle ? "Ciclo " : "") +
    monthName.charAt(0).toUpperCase() +
    monthName.slice(1) +
    " " +
    effective.getFullYear();
  return { key, label };
}

export function cycleBoundsForMonthKey(mKey: string): {
  startTime: number;
  endTime: number;
} {
  if (!/^\d{4}-\d{2}$/.test(mKey)) {
    return { startTime: -Infinity, endTime: Infinity };
  }
  const [y, m] = mKey.split("-").map(Number);
  return {
    startTime: new Date(y, m - 2, 28).getTime(),
    endTime: new Date(y, m - 1, 27, 23, 59, 59).getTime(),
  };
}
