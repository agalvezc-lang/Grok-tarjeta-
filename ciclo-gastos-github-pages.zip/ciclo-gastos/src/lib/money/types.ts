export type RawRow = {
  t: number | string | null;
  c: string;
  a: number;
};

export type ExpenseGroup = {
  label: string;
  total: number;
  category: string | null;
  metodoPago: string | null;
  date: number | null;
  real?: boolean;
};

export type ManualSumGroup = { keys: string[] };

export type MonthData = {
  label: string;
  order: string[];
  groups: Record<string, ExpenseGroup>;
  manualSumGroups?: ManualSumGroup[];
};

export type NamedItem = { id: string; label: string };

export type CategoryRule = { keyword: string; category: string };

export type PayCatRule = {
  keyword: string;
  category: string | null;
  metodoPago: string | null;
};

export type ComercioMerge = { id: string; label: string; keys: string[] };

export type ThemeId = "blanco" | "azul-claro" | "cobalto" | "negro" | "verde";

export type BackupV1 = {
  months: Record<string, MonthData>;
  filesLoaded?: number;
  validRowsAccum?: number;
  skippedAccum?: number;
};

export type BackupV2 = BackupV1 & {
  version: 2;
  rawRows: RawRow[];
  customCategories: NamedItem[];
  customPaymentMethods: NamedItem[];
  categoryDefaults: CategoryRule[];
  payCategoryDefaults: PayCatRule[];
  comercioMerges: ComercioMerge[];
  dispuesto: number;
  liquidacion: number;
  theme: ThemeId;
  isDemo?: boolean;
};

export type PeriodRange = { start: Date; end: Date };

export type ClusterOrigin = { label: string; total: number };

export type SummaryCluster = {
  key: string;
  label: string;
  total: number;
  merged?: boolean;
  mergeId?: string;
  origins: ClusterOrigin[];
};

export const ACCOUNT_PREFIX = "tarjeta_";

export const LS = {
  data: ACCOUNT_PREFIX + "agrupadorGastosData_v1",
  raw: ACCOUNT_PREFIX + "agrupadorGastosData_v1_raw",
  catDefaults: ACCOUNT_PREFIX + "agrupadorCategoriaDefaults_v1",
  payCatDefaults: ACCOUNT_PREFIX + "agrupadorReglasProveedorSinFusion_v1",
  customCats: ACCOUNT_PREFIX + "agrupadorCategoriasPropias_v1",
  payMethods: ACCOUNT_PREFIX + "agrupadorMetodosPagoPropios_v1",
  merges: ACCOUNT_PREFIX + "agrupadorComercioMerges_gastos",
  theme: ACCOUNT_PREFIX + "agrupadorGastosBgTheme",
  dispuesto: ACCOUNT_PREFIX + "agrupadorDispuesto_v1",
  liquidacion: ACCOUNT_PREFIX + "agrupadorLiquidacion_v1",
  demo: ACCOUNT_PREFIX + "agrupadorIsDemo_v1",
} as const;

export const FIXED_CATEGORIES: NamedItem[] = [
  { id: "personal", label: "Personal" },
  { id: "casa", label: "Casa" },
  { id: "trabajo", label: "Trabajo" },
];

export const FIXED_PAYMENT_METHODS: NamedItem[] = [
  { id: "tarjeta", label: "Tarjeta" },
  { id: "efectivo", label: "Efectivo" },
];

export const ALL_FIXED_PAYMENT_METHODS: NamedItem[] = [
  { id: "tarjeta", label: "Tarjeta" },
  { id: "efectivo", label: "Efectivo" },
  { id: "transferencia", label: "Transferencia" },
  { id: "en_cuenta", label: "En cuenta" },
  { id: "abono", label: "Abono" },
  { id: "otro", label: "Otro" },
];

export const GROUP_RULES: {
  key: string;
  label: string;
  keywords: string[];
  defaultCategory?: string;
}[] = [
  { key: "trf", label: "TRF", keywords: ["trf"] },
  {
    key: "telfy-orange",
    label: "Telfy / Orange",
    keywords: ["telfy", "orange"],
    defaultCategory: "casa",
  },
  { key: "devoluciones", label: "Devoluciones", keywords: ["devol"] },
  { key: "dev", label: "DEV", keywords: ["dev"] },
  { key: "farmacia-alicia", label: "Farmacia Alicia", keywords: ["alicia"] },
  { key: "kiosco-paseo", label: "Kiosco El Paseo", keywords: ["kiosco", "paseo"] },
  { key: "amazon", label: "Amazon", keywords: ["amazon"] },
];

export const CATEGORY_ONLY_RULES: { keyword: string; category: string }[] = [
  { keyword: "basic", category: "trabajo" },
  { keyword: "colegio", category: "trabajo" },
];

export const COMERCIO_ALIASES: Record<string, string> = {
  bp: "levante diesel",
  "bp levante diesel": "levante diesel",
};

export const COMERCIO_CANONICAL_LABELS: Record<string, string> = {
  "levante diesel": "Levante Diesel",
};

export const MONTH_NAMES = [
  "enero",
  "febrero",
  "marzo",
  "abril",
  "mayo",
  "junio",
  "julio",
  "agosto",
  "septiembre",
  "octubre",
  "noviembre",
  "diciembre",
] as const;

export const THEMES: { id: ThemeId; label: string }[] = [
  { id: "blanco", label: "Papel" },
  { id: "azul-claro", label: "Cielo" },
  { id: "cobalto", label: "Cobalto" },
  { id: "negro", label: "Noche" },
  { id: "verde", label: "Olivo" },
];
