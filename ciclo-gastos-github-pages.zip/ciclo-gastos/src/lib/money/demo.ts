import type { RawRow } from "./types";

function at(y: number, m: number, d: number): number {
  return new Date(y, m, d).getTime();
}

/** Sample card movements around the current cycle (28–27) so the preview is full. */
export function buildDemoRawRows(now = new Date()): RawRow[] {
  const y = now.getFullYear();
  const m = now.getMonth();
  // Current cycle: day 28 of previous month → day 27 of this month
  const rows: RawRow[] = [
    { t: at(y, m - 1, 29), c: "MERCADONA ALICANTE", a: 54.2 },
    { t: at(y, m - 1, 30), c: "AMAZON EU SARL", a: 23.99 },
    { t: at(y, m, 1), c: "TELFY COMUNICACIONES", a: 19.9 },
    { t: at(y, m, 2), c: "FARMACIA ALICIA", a: 12.4 },
    { t: at(y, m, 3), c: "LEVANTE DIESEL", a: 68.0 },
    { t: at(y, m, 4), c: "NETFLIX.COM", a: 12.99 },
    { t: at(y, m, 5), c: "CARREFOUR ALICANTE", a: 89.12 },
    { t: at(y, m, 6), c: "KIOSCO EL PASEO", a: 4.5 },
    { t: at(y, m, 7), c: "AMAZON MARKETPLACE", a: 45.8 },
    { t: at(y, m, 8), c: "BASIC FORMACION", a: 120.0 },
    { t: at(y, m, 9), c: "MERCADONA SAN JUAN", a: 71.33 },
    { t: at(y, m, 10), c: "MCDONALDS ALICANTE", a: 11.5 },
    { t: at(y, m, 11), c: "HIDRAQUA", a: 38.4 },
    { t: at(y, m, 12), c: "EL CORTE INGLES", a: 56.0 },
    { t: at(y, m, 13), c: "BP LEVANTE DIESEL", a: 55.2 },
    { t: at(y, m, 14), c: "MERCADONA", a: 42.1 },
    { t: at(y, m, 15), c: "FARMACIA ALICIA", a: 8.75 },
    // Previous cycle
    { t: at(y, m - 2, 29), c: "MERCADONA ALICANTE", a: 61.4 },
    { t: at(y, m - 2, 31), c: "AMAZON EU SARL", a: 18.5 },
    { t: at(y, m - 1, 2), c: "TELFY COMUNICACIONES", a: 19.9 },
    { t: at(y, m - 1, 5), c: "LEVANTE DIESEL", a: 72.3 },
    { t: at(y, m - 1, 8), c: "NETFLIX.COM", a: 12.99 },
    { t: at(y, m - 1, 10), c: "CARREFOUR", a: 44.2 },
    { t: at(y, m - 1, 14), c: "COLEGIO SAGRADA FAMILIA", a: 95.0 },
    { t: at(y, m - 1, 18), c: "MERCADONA", a: 58.7 },
    { t: at(y, m - 1, 22), c: "IBERDROLA CLIENTES", a: 67.8 },
    { t: at(y, m - 1, 25), c: "KIOSCO EL PASEO", a: 3.2 },
  ];
  return rows;
}

export const DEMO_DISPUSTO = 750;
