import { create } from "zustand";
import {
  ALL_FIXED_PAYMENT_METHODS,
  FIXED_PAYMENT_METHODS,
  LS,
  type BackupV1,
  type BackupV2,
  type CategoryRule,
  type ComercioMerge,
  type ExpenseGroup,
  type MonthData,
  type NamedItem,
  type PayCatRule,
  type PeriodRange,
  type RawRow,
  type ThemeId,
} from "@/lib/money/types";
import { loadJSON, removeKey, saveJSON } from "@/lib/money/storage";
import { buildDemoRawRows, DEMO_DISPUSTO } from "@/lib/money/demo";
import {
  defaultsForNewGroup,
  findOldGroupForConcept,
  groupKeyForConcept,
} from "@/lib/money/groups";
import { getMonthInfo } from "@/lib/money/cycle";
import { dateToEpoch, parseAmount } from "@/lib/money/parse";
import { slugifyKeyword } from "@/lib/money/format";
import {
  mergeImportedMonths,
  processSheetRows,
  readSpreadsheetFile,
} from "@/lib/money/import-xlsx";

export type TabId = "inicio" | "ciclo" | "resumen" | "mas";

type State = {
  hydrated: boolean;
  isDemo: boolean;
  months: Record<string, MonthData>;
  rawRows: RawRow[];
  filesLoaded: number;
  validRowsAccum: number;
  skippedAccum: number;
  customCategories: NamedItem[];
  customPaymentMethods: NamedItem[];
  categoryDefaults: CategoryRule[];
  payCategoryDefaults: PayCatRule[];
  comercioMerges: ComercioMerge[];
  dispuesto: number;
  liquidacion: number;
  theme: ThemeId;
  tab: TabId;
  activeRange: PeriodRange | null;
  lastImportMsg: string | null;
};

type Actions = {
  hydrate: () => void;
  setTab: (tab: TabId) => void;
  setActiveRange: (range: PeriodRange) => void;
  setTheme: (theme: ThemeId) => void;
  setDispuesto: (n: number) => void;
  setLiquidacion: (n: number) => void;
  importFile: (file: File) => Promise<{
    addedNew: number;
    validRows: number;
    duplicates: number;
  }>;
  addExpense: (input: {
    date: Date;
    concept: string;
    amount: number;
    category: string | null;
    metodoPago: string | null;
  }) => void;
  updateGroup: (
    mKey: string,
    cKey: string,
    patch: Partial<ExpenseGroup>,
  ) => void;
  deleteGroup: (mKey: string, cKey: string) => void;
  setGroupCategory: (mKey: string, cKey: string, category: string | null) => void;
  setGroupMetodo: (mKey: string, cKey: string, metodoPago: string | null) => void;
  deleteRawRow: (row: RawRow, mKey: string, cKey: string) => void;
  reprocess: () => number;
  resetAll: () => void;
  seedDemo: () => void;
  addCustomCategory: (name: string) => NamedItem | null;
  removeCustomCategory: (id: string) => void;
  addCustomPayMethod: (name: string) => NamedItem | null;
  removeCustomPayMethod: (id: string) => void;
  addCategoryRule: (keyword: string, category: string) => void;
  updateCategoryRule: (idx: number, patch: Partial<CategoryRule>) => void;
  removeCategoryRule: (idx: number) => void;
  applyCategoryRules: () => number;
  addPayCatRule: (rule: PayCatRule) => void;
  updatePayCatRule: (idx: number, patch: Partial<PayCatRule>) => void;
  removePayCatRule: (idx: number) => void;
  applyPayCatRules: () => number;
  mergeComercios: (keys: string[], label: string) => void;
  unmergeComercio: (id: string) => void;
  addManualSum: (mKey: string, keys: string[]) => void;
  removeFromManualSum: (mKey: string, key: string) => void;
  exportBackup: () => string;
  importBackup: (json: string) => void;
  persist: () => void;
};

function persistAll(s: State) {
  saveJSON(LS.data, {
    months: s.months,
    filesLoaded: s.filesLoaded,
    validRowsAccum: s.validRowsAccum,
    skippedAccum: s.skippedAccum,
  });
  saveJSON(LS.raw, s.rawRows);
  saveJSON(LS.customCats, s.customCategories);
  saveJSON(LS.payMethods, s.customPaymentMethods);
  saveJSON(LS.catDefaults, s.categoryDefaults);
  saveJSON(LS.payCatDefaults, s.payCategoryDefaults);
  saveJSON(LS.merges, s.comercioMerges);
  saveJSON(LS.theme, s.theme);
  saveJSON(LS.dispuesto, String(s.dispuesto));
  saveJSON(LS.liquidacion, String(s.liquidacion));
  saveJSON(LS.demo, s.isDemo);
}

function emptyState(): Omit<State, "hydrated" | "tab" | "activeRange" | "lastImportMsg"> {
  return {
    isDemo: false,
    months: {},
    rawRows: [],
    filesLoaded: 0,
    validRowsAccum: 0,
    skippedAccum: 0,
    customCategories: [],
    customPaymentMethods: [],
    categoryDefaults: [],
    payCategoryDefaults: [],
    comercioMerges: [],
    dispuesto: 0,
    liquidacion: 0,
    theme: "blanco",
  };
}

function rebuildMonthsFromRaw(
  rawRows: RawRow[],
  oldMonths: Record<string, MonthData>,
  categoryDefaults: CategoryRule[],
  payCategoryDefaults: PayCatRule[],
): Record<string, MonthData> {
  const newMonths: Record<string, MonthData> = {};
  rawRows.forEach((r) => {
    const dateVal =
      typeof r.t === "number" && r.t > 1e10 ? new Date(r.t) : r.t;
    const { key: monthKey, label: monthLabel } = getMonthInfo(dateVal, true);
    if (!newMonths[monthKey])
      newMonths[monthKey] = { label: monthLabel, order: [], groups: {} };
    const resolved = groupKeyForConcept(r.c, categoryDefaults);
    const bucket = newMonths[monthKey];
    const oldGroup = findOldGroupForConcept(
      oldMonths,
      monthKey,
      resolved.key,
      resolved.label,
    );
    if (!bucket.groups[resolved.key]) {
      const defs = resolved.category
        ? { category: resolved.category, metodoPago: "tarjeta" }
        : defaultsForNewGroup(r.c.toLowerCase(), payCategoryDefaults);
      bucket.groups[resolved.key] = oldGroup
        ? {
            label: oldGroup.label,
            total: 0,
            category: oldGroup.category,
            metodoPago: oldGroup.metodoPago,
            date: null,
            real: oldGroup.real,
          }
        : {
            label: resolved.label,
            total: 0,
            category: defs.category,
            metodoPago: defs.metodoPago,
            date: null,
          };
      bucket.order.push(resolved.key);
    }
    bucket.groups[resolved.key].total += r.a;
    const epoch = dateToEpoch(dateVal);
    const g = bucket.groups[resolved.key];
    if (epoch !== null && (g.date === null || epoch > g.date)) g.date = epoch;
  });
  Object.keys(newMonths).forEach((monthKey) => {
    const oldMonth = oldMonths[monthKey];
    if (!oldMonth?.manualSumGroups?.length) return;
    const validKeys = new Set(Object.keys(newMonths[monthKey].groups));
    const carried = oldMonth.manualSumGroups
      .map((g) => ({ keys: g.keys.filter((k) => validKeys.has(k)) }))
      .filter((g) => g.keys.length >= 2);
    if (carried.length) newMonths[monthKey].manualSumGroups = carried;
  });
  return newMonths;
}

export function paymentMethodsForAccount(custom: NamedItem[]): NamedItem[] {
  return [...FIXED_PAYMENT_METHODS, ...custom];
}

export function allPayMethods(custom: NamedItem[]): NamedItem[] {
  return [...ALL_FIXED_PAYMENT_METHODS, ...custom];
}

export const useExpenses = create<State & Actions>((set, get) => ({
  hydrated: false,
  tab: "inicio",
  activeRange: null,
  lastImportMsg: null,
  ...emptyState(),

  hydrate: () => {
    if (typeof window === "undefined") return;
    if (get().hydrated) return;
    const data = loadJSON<BackupV1 | null>(LS.data, null);
    const rawRows = loadJSON<RawRow[]>(LS.raw, []);
    const customCategories = loadJSON<NamedItem[]>(LS.customCats, []);
    const customPaymentMethods = loadJSON<NamedItem[]>(LS.payMethods, []);
    const categoryDefaults = loadJSON<CategoryRule[]>(LS.catDefaults, []);
    const payCategoryDefaults = loadJSON<PayCatRule[]>(LS.payCatDefaults, []);
    const comercioMerges = loadJSON<ComercioMerge[]>(LS.merges, []);
    const themeRaw = loadJSON<ThemeId | string>(LS.theme, "blanco");
    const theme: ThemeId = (
      ["blanco", "azul-claro", "cobalto", "negro", "verde"] as ThemeId[]
    ).includes(themeRaw as ThemeId)
      ? (themeRaw as ThemeId)
      : "blanco";
    const dispuestoRaw = loadJSON<string | number>(LS.dispuesto, "0");
    const liquidacionRaw = loadJSON<string | number>(LS.liquidacion, "0");
    const isDemo = loadJSON<boolean>(LS.demo, false);

    const months = data?.months || {};
    const hasData =
      Object.keys(months).length > 0 || (rawRows && rawRows.length > 0);

    if (!hasData) {
      get().seedDemo();
      set({ hydrated: true, theme });
      applyTheme(theme);
      return;
    }

    set({
      hydrated: true,
      isDemo,
      months,
      rawRows: rawRows || [],
      filesLoaded: data?.filesLoaded || 0,
      validRowsAccum: data?.validRowsAccum || 0,
      skippedAccum: data?.skippedAccum || 0,
      customCategories,
      customPaymentMethods,
      categoryDefaults,
      payCategoryDefaults,
      comercioMerges,
      theme,
      dispuesto: parseAmount(dispuestoRaw) || 0,
      liquidacion: parseAmount(liquidacionRaw) || 0,
    });
    applyTheme(theme);
  },

  persist: () => persistAll(get()),

  setTab: (tab) => set({ tab }),
  setActiveRange: (range) => set({ activeRange: range }),

  setTheme: (theme) => {
    applyTheme(theme);
    set({ theme });
    saveJSON(LS.theme, theme);
  },

  setDispuesto: (n) => {
    set({ dispuesto: n });
    saveJSON(LS.dispuesto, String(n));
  },
  setLiquidacion: (n) => {
    set({ liquidacion: n });
    saveJSON(LS.liquidacion, String(n));
  },

  seedDemo: () => {
    const rawRows = buildDemoRawRows();
    const months = rebuildMonthsFromRaw(rawRows, {}, [], []);
    const next: State = {
      ...get(),
      isDemo: true,
      months,
      rawRows,
      filesLoaded: 0,
      validRowsAccum: rawRows.length,
      skippedAccum: 0,
      dispuesto: DEMO_DISPUSTO,
      liquidacion: 0,
    };
    persistAll(next);
    set({
      isDemo: true,
      months,
      rawRows,
      filesLoaded: 0,
      validRowsAccum: rawRows.length,
      skippedAccum: 0,
      dispuesto: DEMO_DISPUSTO,
      liquidacion: 0,
    });
  },

  importFile: async (file) => {
    const rows = await readSpreadsheetFile(file);
    const s = get();
    if (s.isDemo) {
      set({
        isDemo: false,
        months: {},
        rawRows: [],
        filesLoaded: 0,
        validRowsAccum: 0,
        skippedAccum: 0,
      });
    }
    const cur = get();
    const result = processSheetRows(
      rows,
      cur.categoryDefaults,
      cur.payCategoryDefaults,
      cur.rawRows,
    );
    const { months, addedNew } = mergeImportedMonths(cur.months, result.fileMonths);
    const rawRows = [...cur.rawRows, ...result.rawRows];
    const filesLoaded = cur.filesLoaded + 1;
    const validRowsAccum = cur.validRowsAccum + result.validRows;
    const skippedAccum = cur.skippedAccum + result.skipped;
    set({
      months,
      rawRows,
      filesLoaded,
      validRowsAccum,
      skippedAccum,
      isDemo: false,
      lastImportMsg: `${addedNew} concepto${addedNew === 1 ? "" : "s"} nuevo${addedNew === 1 ? "" : "s"} · ${result.validRows} movimientos${result.duplicates ? ` · ${result.duplicates} duplicado${result.duplicates === 1 ? "" : "s"} omitido${result.duplicates === 1 ? "" : "s"}` : ""}`,
    });
    persistAll(get());
    return { addedNew, validRows: result.validRows, duplicates: result.duplicates };
  },

  addExpense: ({ date, concept, amount, category, metodoPago }) => {
    const s = get();
    let months = s.months;
    let rawRows = s.rawRows;
    const isDemo = false;
    rawRows = [
      ...rawRows,
      { t: date.getTime(), c: concept, a: amount },
    ];
    const { key: mKey, label: monthLabel } = getMonthInfo(date, true);
    const nextMonths: Record<string, MonthData> = { ...months };
    if (!nextMonths[mKey])
      nextMonths[mKey] = { label: monthLabel, order: [], groups: {} };
    const bucket = {
      ...nextMonths[mKey],
      groups: { ...nextMonths[mKey].groups },
      order: [...nextMonths[mKey].order],
    };
    const resolved = groupKeyForConcept(concept, s.categoryDefaults);
    if (!bucket.groups[resolved.key]) {
      const defs = resolved.category
        ? { category: resolved.category, metodoPago: "tarjeta" }
        : defaultsForNewGroup(concept.toLowerCase(), s.payCategoryDefaults);
      bucket.groups[resolved.key] = {
        label: resolved.label,
        total: 0,
        category: defs.category,
        metodoPago: defs.metodoPago,
        date: null,
      };
      bucket.order.push(resolved.key);
    } else {
      bucket.groups[resolved.key] = { ...bucket.groups[resolved.key] };
    }
    const g = bucket.groups[resolved.key];
    g.total += amount;
    if (category) g.category = category;
    if (metodoPago) g.metodoPago = metodoPago;
    const epoch = date.getTime();
    if (g.date === null || epoch > g.date) g.date = epoch;
    nextMonths[mKey] = bucket;
    set({
      months: nextMonths,
      rawRows,
      isDemo,
      validRowsAccum: get().validRowsAccum + 1,
    });
    persistAll(get());
  },

  updateGroup: (mKey, cKey, patch) => {
    const months = { ...get().months };
    const existingMonth = months[mKey];
    const m = existingMonth ?? {
      label: mKey,
      order: [],
      groups: {},
    };
    const existing = m.groups[cKey] ?? {
      label: (patch.label as string) || cKey,
      total: typeof patch.total === "number" ? patch.total : 0,
      category: null,
      metodoPago: "tarjeta",
      date: null,
    };
    const groups = { ...m.groups, [cKey]: { ...existing, ...patch } };
    const order = m.order.includes(cKey) ? m.order : [...m.order, cKey];
    months[mKey] = { ...m, groups, order };
    set({ months });
    persistAll(get());
  },

  deleteGroup: (mKey, cKey) => {
    const months = { ...get().months };
    const m = months[mKey];
    if (!m || !m.groups[cKey]) return;
    const groups = { ...m.groups };
    delete groups[cKey];
    months[mKey] = {
      ...m,
      groups,
      order: m.order.filter((k) => k !== cKey),
    };
    set({ months });
    persistAll(get());
  },

  setGroupCategory: (mKey, cKey, category) => {
    get().updateGroup(mKey, cKey, { category });
  },
  setGroupMetodo: (mKey, cKey, metodoPago) => {
    get().updateGroup(mKey, cKey, { metodoPago });
  },

  deleteRawRow: (row, mKey, cKey) => {
    const rawRows = get().rawRows.filter((r) => r !== row);
    const months = { ...get().months };
    const m = months[mKey];
    if (m && m.groups[cKey]) {
      const g = { ...m.groups[cKey] };
      g.total -= Number(row.a) || 0;
      const groups = { ...m.groups };
      if (g.total <= 0.001) {
        delete groups[cKey];
        months[mKey] = {
          ...m,
          groups,
          order: m.order.filter((k) => k !== cKey),
        };
      } else {
        groups[cKey] = g;
        months[mKey] = { ...m, groups };
      }
    }
    set({ rawRows, months });
    persistAll(get());
  },

  reprocess: () => {
    const s = get();
    if (!s.rawRows.length) return 0;
    const months = rebuildMonthsFromRaw(
      s.rawRows,
      s.months,
      s.categoryDefaults,
      s.payCategoryDefaults,
    );
    set({ months });
    persistAll(get());
    return s.rawRows.length;
  },

  resetAll: () => {
    removeKey(LS.data);
    removeKey(LS.raw);
    removeKey(LS.demo);
    set({
      ...emptyState(),
      theme: get().theme,
      hydrated: true,
      tab: "inicio",
      activeRange: null,
      lastImportMsg: null,
    });
  },

  addCustomCategory: (name) => {
    const label = name.trim();
    if (!label) return null;
    const id = "cat-" + slugifyKeyword(label);
    const custom = get().customCategories;
    if (custom.some((c) => c.id === id)) return null;
    const item = { id, label };
    set({ customCategories: [...custom, item] });
    persistAll(get());
    return item;
  },
  removeCustomCategory: (id) => {
    set({
      customCategories: get().customCategories.filter((c) => c.id !== id),
    });
    persistAll(get());
  },
  addCustomPayMethod: (name) => {
    const label = name.trim();
    if (!label) return null;
    const id = "pm-" + slugifyKeyword(label);
    const custom = get().customPaymentMethods;
    if (custom.some((c) => c.id === id)) return null;
    const item = { id, label };
    set({ customPaymentMethods: [...custom, item] });
    persistAll(get());
    return item;
  },
  removeCustomPayMethod: (id) => {
    set({
      customPaymentMethods: get().customPaymentMethods.filter((c) => c.id !== id),
    });
    persistAll(get());
  },
  addCategoryRule: (keyword, category) => {
    const kw = keyword.trim().toLowerCase();
    if (!kw) return;
    set({
      categoryDefaults: [...get().categoryDefaults, { keyword: kw, category }],
    });
    persistAll(get());
  },
  updateCategoryRule: (idx, patch) => {
    const next = get().categoryDefaults.map((r, i) =>
      i === idx ? { ...r, ...patch } : r,
    );
    set({ categoryDefaults: next });
    persistAll(get());
  },
  removeCategoryRule: (idx) => {
    set({
      categoryDefaults: get().categoryDefaults.filter((_, i) => i !== idx),
    });
    persistAll(get());
  },
  applyCategoryRules: () => {
    const s = get();
    let changed = 0;
    const months: Record<string, MonthData> = {};
    Object.entries(s.months).forEach(([mKey, mData]) => {
      const groups = { ...mData.groups };
      let order = [...mData.order];
      Object.entries(groups).forEach(([cKey, g]) => {
        const resolved = groupKeyForConcept(g.label, s.categoryDefaults);
        if (resolved.key === cKey) {
          if (!g.category && resolved.category) {
            groups[cKey] = { ...g, category: resolved.category };
            changed++;
          }
          return;
        }
        if (g.category) return;
        if (!groups[resolved.key]) {
          groups[resolved.key] = {
            label: resolved.label,
            total: 0,
            category: resolved.category,
            metodoPago: g.metodoPago,
            date: null,
          };
          order.push(resolved.key);
        }
        groups[resolved.key] = {
          ...groups[resolved.key],
          total: groups[resolved.key].total + g.total,
          category: resolved.category || groups[resolved.key].category,
          date:
            g.date != null &&
            (groups[resolved.key].date == null ||
              g.date > groups[resolved.key].date!)
              ? g.date
              : groups[resolved.key].date,
        };
        delete groups[cKey];
        order = order.filter((k) => k !== cKey);
        changed++;
      });
      months[mKey] = { ...mData, groups, order };
    });
    if (changed) {
      set({ months });
      persistAll(get());
    }
    return changed;
  },
  addPayCatRule: (rule) => {
    set({ payCategoryDefaults: [...get().payCategoryDefaults, rule] });
    persistAll(get());
  },
  updatePayCatRule: (idx, patch) => {
    const next = get().payCategoryDefaults.map((r, i) =>
      i === idx ? { ...r, ...patch } : r,
    );
    set({ payCategoryDefaults: next });
    persistAll(get());
  },
  removePayCatRule: (idx) => {
    set({
      payCategoryDefaults: get().payCategoryDefaults.filter((_, i) => i !== idx),
    });
    persistAll(get());
  },
  applyPayCatRules: () => {
    const s = get();
    let changed = 0;
    const months: Record<string, MonthData> = {};
    Object.entries(s.months).forEach(([mKey, mData]) => {
      const groups = { ...mData.groups };
      Object.entries(groups).forEach(([cKey, g]) => {
        const defs = defaultsForNewGroup(
          g.label.toLowerCase(),
          s.payCategoryDefaults,
        );
        let next = g;
        if (!g.category && defs.category) {
          next = { ...next, category: defs.category };
          changed++;
        }
        if (!g.metodoPago && defs.metodoPago) {
          next = { ...next, metodoPago: defs.metodoPago };
          changed++;
        }
        groups[cKey] = next;
      });
      months[mKey] = { ...mData, groups };
    });
    if (changed) {
      set({ months });
      persistAll(get());
    }
    return changed;
  },
  mergeComercios: (keys, label) => {
    const merges = [...get().comercioMerges];
    let allKeys: string[] = [];
    keys.forEach((key) => {
      if (key.startsWith("merge:")) {
        const mid = key.slice("merge:".length);
        const idx = merges.findIndex((m) => String(m.id) === mid);
        if (idx !== -1) {
          allKeys.push(...merges[idx].keys);
          merges.splice(idx, 1);
        }
      } else {
        allKeys.push(key);
      }
    });
    merges.push({
      id: Date.now().toString(36),
      label,
      keys: allKeys,
    });
    set({ comercioMerges: merges });
    persistAll(get());
  },
  unmergeComercio: (id) => {
    set({
      comercioMerges: get().comercioMerges.filter((m) => m.id !== id),
    });
    persistAll(get());
  },
  addManualSum: (mKey, keys) => {
    const months = { ...get().months };
    const m = months[mKey];
    if (!m) return;
    months[mKey] = {
      ...m,
      manualSumGroups: [...(m.manualSumGroups || []), { keys }],
    };
    set({ months });
    persistAll(get());
  },
  removeFromManualSum: (mKey, key) => {
    const months = { ...get().months };
    const m = months[mKey];
    if (!m?.manualSumGroups) return;
    months[mKey] = {
      ...m,
      manualSumGroups: m.manualSumGroups
        .map((g) => ({ keys: g.keys.filter((k) => k !== key) }))
        .filter((g) => g.keys.length >= 2),
    };
    set({ months });
    persistAll(get());
  },
  exportBackup: () => {
    const s = get();
    const payload: BackupV2 = {
      version: 2,
      months: s.months,
      filesLoaded: s.filesLoaded,
      validRowsAccum: s.validRowsAccum,
      skippedAccum: s.skippedAccum,
      rawRows: s.rawRows,
      customCategories: s.customCategories,
      customPaymentMethods: s.customPaymentMethods,
      categoryDefaults: s.categoryDefaults,
      payCategoryDefaults: s.payCategoryDefaults,
      comercioMerges: s.comercioMerges,
      dispuesto: s.dispuesto,
      liquidacion: s.liquidacion,
      theme: s.theme,
      isDemo: s.isDemo,
    };
    return JSON.stringify(payload, null, 2);
  },
  importBackup: (json) => {
    const data = JSON.parse(json) as BackupV2 & BackupV1;
    set({
      months: data.months || {},
      filesLoaded: data.filesLoaded || 0,
      validRowsAccum: data.validRowsAccum || 0,
      skippedAccum: data.skippedAccum || 0,
      rawRows: data.rawRows || [],
      customCategories: data.customCategories || get().customCategories,
      customPaymentMethods:
        data.customPaymentMethods || get().customPaymentMethods,
      categoryDefaults: data.categoryDefaults || get().categoryDefaults,
      payCategoryDefaults:
        data.payCategoryDefaults || get().payCategoryDefaults,
      comercioMerges: data.comercioMerges || get().comercioMerges,
      dispuesto: data.dispuesto ?? get().dispuesto,
      liquidacion: data.liquidacion ?? get().liquidacion,
      theme: data.theme || get().theme,
      isDemo: false,
    });
    persistAll(get());
    applyTheme(get().theme);
  },
}));

function applyTheme(theme: ThemeId) {
  if (typeof document === "undefined") return;
  document.documentElement.setAttribute("data-theme", theme);
  const colors: Record<ThemeId, string> = {
    blanco: "#f3f0e8",
    "azul-claro": "#eaf4ff",
    cobalto: "#003d94",
    negro: "#0a0a0b",
    verde: "#0d3b2e",
  };
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", colors[theme]);
}
