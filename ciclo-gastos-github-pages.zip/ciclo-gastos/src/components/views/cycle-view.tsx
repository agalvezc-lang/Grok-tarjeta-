import { useMemo, useState } from "react";
import { Pencil, Search, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  cycleKeyFromRange,
  cycleLabelFromRange,
  getCurrentCycleRange,
  rangeFromMonthKey,
} from "@/lib/money/cycle";
import { formatDateEs, formatEUR } from "@/lib/money/format";
import { parseAmount } from "@/lib/money/parse";
import { allCategories, rawRowsForGroup } from "@/lib/money/groups";
import {
  categorySubtotals,
  computePeriodSummary,
  paymentSubtotals,
} from "@/lib/money/summary";
import { FIXED_CATEGORIES, FIXED_PAYMENT_METHODS } from "@/lib/money/types";
import { paymentMethodsForAccount, useExpenses } from "@/store/expenses";
import { cn } from "@/lib/utils";

export function CycleView() {
  const months = useExpenses((s) => s.months);
  const rawRows = useExpenses((s) => s.rawRows);
  const categoryDefaults = useExpenses((s) => s.categoryDefaults);
  const customCategories = useExpenses((s) => s.customCategories);
  const customPay = useExpenses((s) => s.customPaymentMethods);
  const activeRange = useExpenses((s) => s.activeRange);
  const setActiveRange = useExpenses((s) => s.setActiveRange);
  const setGroupCategory = useExpenses((s) => s.setGroupCategory);
  const setGroupMetodo = useExpenses((s) => s.setGroupMetodo);
  const updateGroup = useExpenses((s) => s.updateGroup);
  const deleteGroup = useExpenses((s) => s.deleteGroup);
  const deleteRawRow = useExpenses((s) => s.deleteRawRow);

  const range = activeRange ?? getCurrentCycleRange();
  const mKey = cycleKeyFromRange(range);
  const summary = computePeriodSummary(
    rawRows,
    months,
    range,
    categoryDefaults,
  );
  const cats = allCategories(customCategories);
  const methods = paymentMethodsForAccount(customPay);

  const [q, setQ] = useState("");
  const [catFilter, setCatFilter] = useState("");
  const [editing, setEditing] = useState<string | null>(null);
  const [openBreakdown, setOpenBreakdown] = useState<string | null>(null);

  const monthKeys = Object.keys(months)
    .filter((k) => k !== "sin-fecha")
    .sort()
    .reverse();

  const grouped = useMemo(() => {
    const buckets: Record<string, string[]> = { sin: [] };
    cats.forEach((c) => {
      buckets[c.id] = [];
    });
    summary.order.forEach((k) => {
      const g = summary.groups[k];
      if (!g) return;
      if (q) {
        const hay = (g.label + " " + formatEUR(g.total)).toLowerCase();
        if (!hay.includes(q.toLowerCase())) return;
      }
      const cat =
        g.category && cats.some((c) => c.id === g.category)
          ? g.category
          : "sin";
      if (catFilter && cat !== catFilter) return;
      buckets[cat].push(k);
    });
    return buckets;
  }, [summary, q, catFilter, cats]);

  const total = summary.order.reduce(
    (s, k) => s + (summary.groups[k]?.total || 0),
    0,
  );
  const catTotals = categorySubtotals(summary.groups, customCategories);
  const payTotals = paymentSubtotals(summary.groups, customPay);

  const displayCats = [
    ...cats.map((c) => ({ id: c.id, label: c.label })),
    { id: "sin", label: "Sin categoría" },
  ];

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-2xl font-medium tracking-tight">
            {cycleLabelFromRange(range)}
          </h2>
          <p className="text-xs text-muted-foreground">
            {formatDateEs(range.start.getTime())} —{" "}
            {formatDateEs(range.end.getTime())}
          </p>
        </div>
        <p className="font-display text-xl font-medium tabular">
          {formatEUR(total)}
        </p>
      </div>

      {monthKeys.length > 0 ? (
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
          {monthKeys.map((k) => {
            const r = rangeFromMonthKey(k);
            if (!r) return null;
            const active = k === mKey;
            return (
              <button
                key={k}
                type="button"
                onClick={() => setActiveRange(r)}
                className={cn(
                  "shrink-0 rounded-full px-3 py-1.5 text-xs font-medium",
                  active
                    ? "bg-accent text-accent-foreground"
                    : "bg-secondary text-secondary-foreground",
                )}
              >
                {months[k].label.replace("Ciclo ", "")}
              </button>
            );
          })}
        </div>
      ) : null}

      <div className="relative">
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar comercio"
          className="pl-9"
        />
      </div>
      <div className="-mx-4 flex gap-2 overflow-x-auto px-4">
        <Chip
          active={!catFilter}
          onClick={() => setCatFilter("")}
          label="Todas"
        />
        {cats.map((c) => (
          <Chip
            key={c.id}
            active={catFilter === c.id}
            onClick={() => setCatFilter(c.id)}
            label={c.label}
          />
        ))}
      </div>

      {summary.count === 0 ? (
        <Card>
          <CardContent className="py-10 text-center text-sm text-muted-foreground">
            No hay gastos en este ciclo. Importa un extracto o añade uno a mano.
          </CardContent>
        </Card>
      ) : (
        displayCats.map((cat) => {
          const keys = grouped[cat.id] || [];
          if (!keys.length) return null;
          const sub = keys.reduce((s, k) => s + summary.groups[k].total, 0);
          return (
            <section key={cat.id} className="flex flex-col gap-2">
              <div className="flex items-baseline justify-between px-1">
                <h3 className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">
                  {cat.label}
                </h3>
                <span className="text-xs tabular text-muted-foreground">
                  {formatEUR(sub)} · {keys.length}
                </span>
              </div>
              <ul className="flex flex-col gap-2">
                {keys.map((cKey) => {
                  const g = summary.groups[cKey];
                  const isEditing = editing === cKey;
                  const breakdown = rawRowsForGroup(
                    rawRows,
                    mKey,
                    cKey,
                    categoryDefaults,
                  );
                  return (
                    <li key={cKey}>
                      <article className="rounded-2xl bg-card p-3 shadow-border">
                        <div className="flex items-start justify-between gap-3">
                          <button
                            type="button"
                            className="min-w-0 flex-1 text-left"
                            onClick={() =>
                              setOpenBreakdown(
                                openBreakdown === cKey ? null : cKey,
                              )
                            }
                          >
                            <p className="truncate text-sm font-medium">
                              {g.label}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              {formatDateEs(g.date)}
                              {breakdown.length > 1
                                ? ` · ${breakdown.length} movimientos`
                                : ""}
                            </p>
                          </button>
                          <p className="font-display text-lg font-medium tabular">
                            {formatEUR(g.total)}
                          </p>
                        </div>
                        <div className="mt-2 flex items-center gap-2">
                          <select
                            className="native-select"
                            value={g.category || ""}
                            onChange={(e) =>
                              setGroupCategory(
                                mKey,
                                cKey,
                                e.target.value || null,
                              )
                            }
                          >
                            <option value="">Sin cat.</option>
                            {cats.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.label}
                              </option>
                            ))}
                          </select>
                          <select
                            className="native-select"
                            value={g.metodoPago || ""}
                            onChange={(e) =>
                              setGroupMetodo(mKey, cKey, e.target.value || null)
                            }
                          >
                            <option value="">Método</option>
                            {methods.map((m) => (
                              <option key={m.id} value={m.id}>
                                {m.label}
                              </option>
                            ))}
                          </select>
                          <div className="ml-auto flex gap-1">
                            <button
                              type="button"
                              className="inline-flex size-9 items-center justify-center rounded-lg hover:bg-muted"
                              onClick={() =>
                                setEditing(isEditing ? null : cKey)
                              }
                              aria-label="Editar"
                            >
                              <Pencil className="size-4" />
                            </button>
                            <button
                              type="button"
                              className="inline-flex size-9 items-center justify-center rounded-lg hover:bg-muted"
                              onClick={() => {
                                if (confirm(`¿Borrar «${g.label}»?`))
                                  deleteGroup(mKey, cKey);
                              }}
                              aria-label="Borrar"
                            >
                              <Trash2 className="size-4 text-danger" />
                            </button>
                          </div>
                        </div>
                        {isEditing ? (
                          <EditRow
                            label={g.label}
                            amount={g.total}
                            date={formatDateEs(g.date)}
                            onSave={(next) => {
                              updateGroup(mKey, cKey, next);
                              setEditing(null);
                            }}
                            onCancel={() => setEditing(null)}
                          />
                        ) : null}
                        {openBreakdown === cKey && breakdown.length > 1 ? (
                          <ul className="mt-3 border-t border-border pt-2">
                            {breakdown.map((r, i) => {
                              const d = r.t
                                ? formatDateEs(
                                    typeof r.t === "number" ? r.t : undefined,
                                  )
                                : "";
                              return (
                                <li
                                  key={i}
                                  className="flex items-center gap-2 py-1.5 text-xs"
                                >
                                  <span className="w-16 tabular text-muted-foreground">
                                    {d}
                                  </span>
                                  <span className="min-w-0 flex-1 truncate">
                                    {r.c}
                                  </span>
                                  <span className="tabular font-medium">
                                    {formatEUR(r.a)}
                                  </span>
                                  <button
                                    type="button"
                                    className="size-8 shrink-0"
                                    onClick={() => {
                                      if (confirm("¿Borrar este movimiento?"))
                                        deleteRawRow(r, mKey, cKey);
                                    }}
                                    aria-label="Borrar movimiento"
                                  >
                                    <Trash2 className="size-3.5 text-danger" />
                                  </button>
                                </li>
                              );
                            })}
                          </ul>
                        ) : null}
                      </article>
                    </li>
                  );
                })}
              </ul>
            </section>
          );
        })
      )}

      {summary.count > 0 ? (
        <Card>
          <CardContent className="flex flex-col gap-2">
            <p className="text-sm font-medium">Desglose</p>
            {[
              ...FIXED_CATEGORIES,
              ...customCategories,
              { id: "sin", label: "Sin categoría" },
            ]
              .filter((c) => (catTotals[c.id] || 0) !== 0)
              .map((c) => (
                <div
                  key={c.id}
                  className="flex justify-between text-sm text-muted-foreground"
                >
                  <span>{c.label}</span>
                  <span className="tabular text-foreground">
                    {formatEUR(catTotals[c.id] || 0)}
                  </span>
                </div>
              ))}
            <div className="my-1 h-px bg-border" />
            {[
              ...FIXED_PAYMENT_METHODS,
              ...customPay,
              { id: "sin", label: "Sin método" },
            ]
              .filter((m) => (payTotals[m.id] || 0) !== 0)
              .map((m) => (
                <div
                  key={m.id}
                  className="flex justify-between text-sm text-muted-foreground"
                >
                  <span>{m.label}</span>
                  <span className="tabular text-foreground">
                    {formatEUR(payTotals[m.id] || 0)}
                  </span>
                </div>
              ))}
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}

function Chip({
  active,
  onClick,
  label,
}: {
  active: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "shrink-0 rounded-full px-3 py-1.5 text-xs font-medium",
        active
          ? "bg-accent text-accent-foreground"
          : "bg-secondary text-secondary-foreground",
      )}
    >
      {label}
    </button>
  );
}

function EditRow({
  label,
  amount,
  date,
  onSave,
  onCancel,
}: {
  label: string;
  amount: number;
  date: string;
  onSave: (p: { label: string; total: number; date: number | null }) => void;
  onCancel: () => void;
}) {
  const [l, setL] = useState(label);
  const [a, setA] = useState(String(amount).replace(".", ","));
  const [d, setD] = useState(date);
  return (
    <div className="mt-3 flex flex-col gap-2 border-t border-border pt-3">
      <Input value={l} onChange={(e) => setL(e.target.value)} />
      <div className="grid grid-cols-2 gap-2">
        <Input
          inputMode="decimal"
          value={a}
          onChange={(e) => setA(e.target.value)}
        />
        <Input
          placeholder="dd/mm/aaaa"
          value={d}
          onChange={(e) => setD(e.target.value)}
        />
      </div>
      <div className="flex gap-2">
        <Button
          size="sm"
          onClick={() => {
            const total = parseAmount(a);
            if (total === null || !l.trim()) return;
            let epoch: number | null = null;
            if (d.trim()) {
              const m = d
                .trim()
                .match(/(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})/);
              if (!m) return;
              let y = parseInt(m[3], 10);
              if (y < 100) y += 2000;
              epoch = new Date(
                y,
                parseInt(m[2], 10) - 1,
                parseInt(m[1], 10),
              ).getTime();
            }
            onSave({ label: l.trim(), total, date: epoch });
          }}
        >
          Guardar
        </Button>
        <Button size="sm" variant="ghost" onClick={onCancel}>
          Cancelar
        </Button>
      </div>
    </div>
  );
}
