import { useEffect, useMemo, useRef, useState } from "react";
import { Camera } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { parseAmount } from "@/lib/money/parse";
import { findPossibleDuplicate } from "@/lib/money/summary";
import { allCategories } from "@/lib/money/groups";
import { paymentMethodsForAccount, useExpenses } from "@/store/expenses";

export function AddExpenseDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const addExpense = useExpenses((s) => s.addExpense);
  const rawRows = useExpenses((s) => s.rawRows);
  const customCategories = useExpenses((s) => s.customCategories);
  const customPay = useExpenses((s) => s.customPaymentMethods);

  const [date, setDate] = useState("");
  const [amount, setAmount] = useState("");
  const [concept, setConcept] = useState("");
  const [category, setCategory] = useState("");
  const [metodo, setMetodo] = useState("tarjeta");
  const [msg, setMsg] = useState("");
  const [dup, setDup] = useState(false);
  const [ocr, setOcr] = useState("");
  const photoRef = useRef<HTMLInputElement>(null);

  const cats = allCategories(customCategories);
  const methods = paymentMethodsForAccount(customPay);

  const suggestions = useMemo(() => {
    const seen = new Map<string, string>();
    rawRows.forEach((r) => {
      const c = (r.c || "").trim();
      if (c && !seen.has(c.toLowerCase())) seen.set(c.toLowerCase(), c);
    });
    return [...seen.values()].sort((a, b) => a.localeCompare(b, "es"));
  }, [rawRows]);

  const matches = concept.trim()
    ? suggestions
        .filter((s) =>
          s.toLowerCase().includes(concept.trim().toLowerCase()),
        )
        .slice(0, 6)
    : [];

  useEffect(() => {
    if (open) {
      setDate(new Date().toISOString().slice(0, 10));
      setAmount("");
      setConcept("");
      setCategory("");
      setMetodo("tarjeta");
      setMsg("");
      setDup(false);
      setOcr("");
    }
  }, [open]);

  function trySave(force: boolean) {
    const n = parseAmount(amount);
    const c = concept.trim();
    if (!c) {
      setMsg("Escribe un concepto.");
      setDup(false);
      return;
    }
    if (n === null || n <= 0) {
      setMsg("Importe no válido.");
      setDup(false);
      return;
    }
    const parts = (date || "").split("-").map((x) => parseInt(x, 10));
    const dateVal =
      parts.length === 3
        ? new Date(parts[0], parts[1] - 1, parts[2])
        : new Date();
    if (!force && findPossibleDuplicate(rawRows, dateVal, c, n)) {
      setMsg("");
      setDup(true);
      return;
    }
    addExpense({
      date: dateVal,
      concept: c,
      amount: n,
      category: category || null,
      metodoPago: metodo || null,
    });
    toast.success("Gasto añadido");
    onOpenChange(false);
  }

  async function onPhoto(file: File) {
    setOcr("Leyendo el tique…");
    try {
      const { analyzeTicket } = await import("@/lib/money/ocr");
      const guess = await analyzeTicket(file);
      if (guess.date) setDate(guess.date);
      if (guess.amount !== null) setAmount(String(guess.amount));
      if (guess.merchant) setConcept(guess.merchant);
      setOcr("Revisa los datos antes de guardar.");
    } catch {
      setOcr("No se pudo leer el tique. Rellena a mano.");
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Añadir gasto</DialogTitle>
          <DialogDescription>
            Se guarda con el mismo formato que un movimiento importado.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-3 overflow-y-auto">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="add-date">Fecha</Label>
              <Input
                id="add-date"
                type="date"
                className="mt-1"
                value={date}
                onChange={(e) => {
                  setDate(e.target.value);
                  setDup(false);
                }}
              />
            </div>
            <div>
              <Label htmlFor="add-amount">Importe</Label>
              <Input
                id="add-amount"
                inputMode="decimal"
                className="mt-1"
                placeholder="0,00"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value);
                  setDup(false);
                }}
              />
            </div>
          </div>
          <div className="relative">
            <Label htmlFor="add-concept">Concepto</Label>
            <Input
              id="add-concept"
              className="mt-1"
              value={concept}
              onChange={(e) => {
                setConcept(e.target.value);
                setDup(false);
              }}
              autoComplete="off"
            />
            {matches.length > 0 ? (
              <ul className="absolute z-10 mt-1 max-h-40 w-full overflow-auto rounded-lg border border-border bg-card shadow-border">
                {matches.map((s) => (
                  <li key={s}>
                    <button
                      type="button"
                      className="w-full px-3 py-2 text-left text-sm hover:bg-muted"
                      onClick={() => setConcept(s)}
                    >
                      {s}
                    </button>
                  </li>
                ))}
              </ul>
            ) : null}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <select
              className="native-select max-w-none w-full"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              <option value="">Sin categoría</option>
              {cats.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
            <select
              className="native-select max-w-none w-full"
              value={metodo}
              onChange={(e) => setMetodo(e.target.value)}
            >
              <option value="">Sin método</option>
              {methods.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>
          {msg ? <p className="text-xs text-danger">{msg}</p> : null}
          {ocr ? <p className="text-xs text-muted-foreground">{ocr}</p> : null}
          {dup ? (
            <div className="rounded-xl bg-muted p-3">
              <p className="mb-2 text-sm">
                Ya existe un gasto parecido ese día.
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => setDup(false)}
                >
                  Cancelar
                </Button>
                <Button className="flex-1" onClick={() => trySave(true)}>
                  Añadir igual
                </Button>
              </div>
            </div>
          ) : (
            <Button onClick={() => trySave(false)}>Añadir gasto</Button>
          )}
          <Button
            variant="outline"
            onClick={() => photoRef.current?.click()}
          >
            <Camera className="size-4" />
            Foto del tique
          </Button>
          <input
            ref={photoRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) void onPhoto(f);
              e.target.value = "";
            }}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}
