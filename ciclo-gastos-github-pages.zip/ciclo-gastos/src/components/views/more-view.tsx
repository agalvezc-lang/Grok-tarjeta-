import { useRef, useState } from "react";
import {
  Download,
  HelpCircle,
  Palette,
  RotateCcw,
  Trash2,
  Upload,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { THEMES } from "@/lib/money/types";
import { allCategories } from "@/lib/money/groups";
import { paymentMethodsForAccount, useExpenses } from "@/store/expenses";
import { cn } from "@/lib/utils";

export function MoreView({ onImportFile }: { onImportFile: (f: File) => void }) {
  const theme = useExpenses((s) => s.theme);
  const setTheme = useExpenses((s) => s.setTheme);
  const reprocess = useExpenses((s) => s.reprocess);
  const resetAll = useExpenses((s) => s.resetAll);
  const seedDemo = useExpenses((s) => s.seedDemo);
  const exportBackup = useExpenses((s) => s.exportBackup);
  const importBackup = useExpenses((s) => s.importBackup);
  const rawRows = useExpenses((s) => s.rawRows);

  const [helpOpen, setHelpOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const backupRef = useRef<HTMLInputElement>(null);

  function saveBackup() {
    const payload = exportBackup();
    const blob = new Blob([payload], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ciclo-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Copia descargada");
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="font-display text-2xl font-medium tracking-tight">Más</h2>
        <p className="text-sm text-muted-foreground">
          Importar, categorías, tema y copias.
        </p>
      </div>

      <Card>
        <CardContent className="flex flex-col gap-2">
          <p className="text-sm font-medium">Extracto</p>
          <p className="text-xs text-muted-foreground">
            Sube un .xlsx, .xls o .csv de la tarjeta. Se detectan Importe,
            Concepto y Fecha, y se agrupan por comercio en el ciclo 28–27.
          </p>
          <Button onClick={() => fileRef.current?.click()}>
            <Upload className="size-4" />
            Importar extracto
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept=".xlsx,.xls,.csv"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onImportFile(f);
              e.target.value = "";
            }}
          />
          <Button
            variant="outline"
            onClick={() => {
              if (!rawRows.length) {
                toast.error(
                  "No hay movimientos originales. Importa el extracto otra vez.",
                );
                return;
              }
              const n = reprocess();
              toast.success(`Reprocesados ${n} movimientos`);
            }}
          >
            <RefreshCw className="size-4" />
            Reprocesar con las reglas actuales
          </Button>
        </CardContent>
      </Card>

      <ThemePicker theme={theme} onChange={setTheme} />

      <RulesCard />

      <Card>
        <CardContent className="flex flex-col gap-2">
          <p className="text-sm font-medium">Copia de seguridad</p>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" onClick={saveBackup}>
              <Download className="size-4" />
              Guardar
            </Button>
            <Button variant="outline" onClick={() => backupRef.current?.click()}>
              <Upload className="size-4" />
              Cargar
            </Button>
          </div>
          <input
            ref={backupRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              f.text()
                .then((t) => {
                  importBackup(t);
                  toast.success("Copia restaurada");
                })
                .catch(() => toast.error("El archivo no es válido"));
              e.target.value = "";
            }}
          />
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex flex-col gap-2">
          <Button variant="outline" onClick={() => setHelpOpen(true)}>
            <HelpCircle className="size-4" />
            Cómo funciona
          </Button>
          <Button variant="outline" onClick={() => seedDemo()}>
            <RotateCcw className="size-4" />
            Cargar datos de ejemplo
          </Button>
          <Button variant="danger" onClick={() => setResetOpen(true)}>
            <Trash2 className="size-4" />
            Borrar todo
          </Button>
        </CardContent>
      </Card>

      <Dialog open={helpOpen} onOpenChange={setHelpOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cómo funciona</DialogTitle>
            <DialogDescription>
              Ciclo agrupa el extracto de tu tarjeta Caja Rural por comercio y
              por ciclo de facturación (del 28 al 27).
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2 overflow-y-auto text-sm text-muted-foreground">
            <p>
              Sube la hoja (.xlsx / .xls / .csv). Se localizan Importe y
              Concepto, y los movimientos del 28 al 27 se muestran juntos.
            </p>
            <p>
              Si subes otro archivo del mismo mes, solo se añaden los conceptos
              que todavía no estaban.
            </p>
            <p>
              Cada gasto tiene categoría (Personal, Casa, Trabajo o las que
              crees) y método de pago. Desde aquí puedes definir palabras clave
              —por ejemplo «netflix»— para que se categoricen solas.
            </p>
            <p>
              Amazon, Telfy/Orange, Farmacia Alicia, Kiosco El Paseo, TRF y DEV
              se agrupan automáticamente aunque el texto cambie un poco.
            </p>
            <p>
              El dispuesto es el importe que indica el banco para este ciclo. La
              diferencia te dice si falta o sobra gasto por registrar.
            </p>
            <p>
              Resumen unifica comercios iguales de todos los meses. Puedes unir
              a mano los que el banco escribe distinto.
            </p>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={resetOpen} onOpenChange={setResetOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Borrar todos los datos?</AlertDialogTitle>
            <AlertDialogDescription>
              Se eliminan extractos, reglas y copias de este dispositivo. No se
              puede deshacer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                resetAll();
                toast.success("Datos borrados");
              }}
            >
              Borrar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function ThemePicker({
  theme,
  onChange,
}: {
  theme: string;
  onChange: (t: (typeof THEMES)[number]["id"]) => void;
}) {
  return (
    <Card>
      <CardContent>
        <p className="mb-3 flex items-center gap-2 text-sm font-medium">
          <Palette className="size-4" />
          Fondo
        </p>
        <div className="flex flex-wrap gap-3">
          {THEMES.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => onChange(t.id)}
              className={cn(
                "flex flex-col items-center gap-1",
                theme === t.id && "opacity-100",
              )}
              aria-label={t.label}
            >
              <span
                className={cn(
                  "theme-swatch size-10 rounded-full border-2",
                  theme === t.id ? "border-accent" : "border-border",
                )}
                data-sw={t.id}
              />
              <span className="text-[10px] text-muted-foreground">{t.label}</span>
            </button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function RulesCard() {
  const customCategories = useExpenses((s) => s.customCategories);
  const addCustomCategory = useExpenses((s) => s.addCustomCategory);
  const removeCustomCategory = useExpenses((s) => s.removeCustomCategory);
  const customPay = useExpenses((s) => s.customPaymentMethods);
  const addCustomPayMethod = useExpenses((s) => s.addCustomPayMethod);
  const removeCustomPayMethod = useExpenses((s) => s.removeCustomPayMethod);
  const categoryDefaults = useExpenses((s) => s.categoryDefaults);
  const addCategoryRule = useExpenses((s) => s.addCategoryRule);
  const removeCategoryRule = useExpenses((s) => s.removeCategoryRule);
  const applyCategoryRules = useExpenses((s) => s.applyCategoryRules);
  const payCategoryDefaults = useExpenses((s) => s.payCategoryDefaults);
  const addPayCatRule = useExpenses((s) => s.addPayCatRule);
  const removePayCatRule = useExpenses((s) => s.removePayCatRule);
  const applyPayCatRules = useExpenses((s) => s.applyPayCatRules);

  const [newCat, setNewCat] = useState("");
  const [newPm, setNewPm] = useState("");
  const [kw, setKw] = useState("");
  const [kwCat, setKwCat] = useState("personal");
  const [pkw, setPkw] = useState("");
  const [pCat, setPCat] = useState("");
  const [pMet, setPMet] = useState("");

  const cats = allCategories(customCategories);
  const methods = paymentMethodsForAccount(customPay);

  return (
    <Card>
      <CardContent className="flex flex-col gap-4">
        <p className="text-sm font-medium">Categorías y reglas</p>

        <div className="flex gap-2">
          <Input
            placeholder="Nueva categoría"
            value={newCat}
            onChange={(e) => setNewCat(e.target.value)}
          />
          <Button
            variant="secondary"
            onClick={() => {
              if (addCustomCategory(newCat)) setNewCat("");
            }}
          >
            Añadir
          </Button>
        </div>
        {customCategories.length ? (
          <ul className="flex flex-col">
            {customCategories.map((c) => (
              <li
                key={c.id}
                className="flex items-center justify-between border-b border-border py-1.5 text-sm"
              >
                {c.label}
                <button
                  type="button"
                  onClick={() => removeCustomCategory(c.id)}
                  className="size-8 text-danger"
                >
                  <Trash2 className="size-3.5" />
                </button>
              </li>
            ))}
          </ul>
        ) : null}

        <div className="flex flex-col gap-2">
          <Label>Palabra clave → categoría (agrupa)</Label>
          <div className="flex flex-wrap gap-2">
            <Input
              placeholder="netflix"
              value={kw}
              onChange={(e) => setKw(e.target.value)}
              className="flex-1"
            />
            <select
              className="native-select max-w-none"
              value={kwCat}
              onChange={(e) => setKwCat(e.target.value)}
            >
              {cats.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
            <Button
              variant="secondary"
              onClick={() => {
                addCategoryRule(kw, kwCat);
                setKw("");
              }}
            >
              Añadir
            </Button>
          </div>
          {categoryDefaults.map((r, i) => (
            <div
              key={`${r.keyword}-${i}`}
              className="flex items-center justify-between text-sm"
            >
              <span>
                <span className="font-medium">{r.keyword}</span>
                <span className="text-muted-foreground">
                  {" "}
                  → {cats.find((c) => c.id === r.category)?.label || r.category}
                </span>
              </span>
              <button
                type="button"
                onClick={() => removeCategoryRule(i)}
                className="size-8 text-danger"
              >
                <Trash2 className="size-3.5" />
              </button>
            </div>
          ))}
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              const n = applyCategoryRules();
              toast.success(
                n
                  ? `Actualizados ${n} conceptos`
                  : "Nada pendiente de categorizar",
              );
            }}
          >
            Aplicar a lo ya cargado
          </Button>
        </div>

        <div className="flex flex-col gap-2">
          <Label>Métodos de pago propios</Label>
          <div className="flex gap-2">
            <Input
              placeholder="Bizum"
              value={newPm}
              onChange={(e) => setNewPm(e.target.value)}
            />
            <Button
              variant="secondary"
              onClick={() => {
                if (addCustomPayMethod(newPm)) setNewPm("");
              }}
            >
              Añadir
            </Button>
          </div>
          {customPay.map((m) => (
            <div
              key={m.id}
              className="flex items-center justify-between text-sm"
            >
              {m.label}
              <button
                type="button"
                onClick={() => removeCustomPayMethod(m.id)}
                className="size-8 text-danger"
              >
                <Trash2 className="size-3.5" />
              </button>
            </div>
          ))}
        </div>

        <div className="flex flex-col gap-2">
          <Label>Proveedor sin fusionar</Label>
          <p className="text-xs text-muted-foreground">
            Rellena categoría o método sin juntar recibos (p. ej. Iberdrola).
          </p>
          <Input
            placeholder="iberdrola"
            value={pkw}
            onChange={(e) => setPkw(e.target.value)}
          />
          <div className="flex gap-2">
            <select
              className="native-select max-w-none flex-1"
              value={pCat}
              onChange={(e) => setPCat(e.target.value)}
            >
              <option value="">Sin categoría</option>
              {cats.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
            <select
              className="native-select max-w-none flex-1"
              value={pMet}
              onChange={(e) => setPMet(e.target.value)}
            >
              <option value="">Sin método</option>
              {methods.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>
          <Button
            variant="secondary"
            onClick={() => {
              if (!pkw.trim()) return;
              addPayCatRule({
                keyword: pkw.trim().toLowerCase(),
                category: pCat || null,
                metodoPago: pMet || null,
              });
              setPkw("");
            }}
          >
            Añadir regla
          </Button>
          {payCategoryDefaults.map((r, i) => (
            <div
              key={`${r.keyword}-${i}`}
              className="flex items-center justify-between text-sm"
            >
              <span>{r.keyword}</span>
              <button
                type="button"
                onClick={() => removePayCatRule(i)}
                className="size-8 text-danger"
              >
                <Trash2 className="size-3.5" />
              </button>
            </div>
          ))}
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              const n = applyPayCatRules();
              toast.success(
                n ? `Actualizados ${n} recibos` : "Nada pendiente",
              );
            }}
          >
            Aplicar a lo ya cargado
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
