import { useState } from "react";
import { Link2, Unlink, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { formatEUR } from "@/lib/money/format";
import { computeGlobalConceptSummary } from "@/lib/money/summary";
import { getCurrentCycleRange } from "@/lib/money/cycle";
import { useExpenses } from "@/store/expenses";
import { cn } from "@/lib/utils";

export function SummaryView() {
  const months = useExpenses((s) => s.months);
  const rawRows = useExpenses((s) => s.rawRows);
  const merges = useExpenses((s) => s.comercioMerges);
  const categoryDefaults = useExpenses((s) => s.categoryDefaults);
  const mergeComercios = useExpenses((s) => s.mergeComercios);
  const unmergeComercio = useExpenses((s) => s.unmergeComercio);
  const activeRange = useExpenses((s) => s.activeRange);

  const [scope, setScope] = useState<"ciclo" | "todo">("ciclo");
  const [selected, setSelected] = useState<string[]>([]);
  const [openKey, setOpenKey] = useState<string | null>(null);
  const [mergeName, setMergeName] = useState("");

  const range =
    scope === "ciclo" ? (activeRange ?? getCurrentCycleRange()) : null;
  const clusters = computeGlobalConceptSummary(
    rawRows,
    months,
    merges,
    categoryDefaults,
    range,
  );
  const total = clusters.reduce((s, c) => s + c.total, 0);

  function toggle(key: string) {
    setSelected((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key],
    );
  }

  function doMerge() {
    const name = mergeName.trim();
    if (selected.length < 2 || !name) return;
    mergeComercios(selected, name);
    setSelected([]);
    setMergeName("");
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="font-display text-2xl font-medium tracking-tight">
          Resumen
        </h2>
        <p className="text-sm text-muted-foreground">
          Comercios unificados, de mayor a menor.
        </p>
      </div>

      <div className="flex gap-2">
        <Button
          size="sm"
          variant={scope === "ciclo" ? "default" : "outline"}
          onClick={() => setScope("ciclo")}
        >
          Este ciclo
        </Button>
        <Button
          size="sm"
          variant={scope === "todo" ? "default" : "outline"}
          onClick={() => setScope("todo")}
        >
          Todo el histórico
        </Button>
      </div>

      {selected.length >= 2 ? (
        <Card>
          <CardContent className="flex flex-col gap-2">
            <p className="text-sm font-medium">
              Unir {selected.length} comercios
            </p>
            <Input
              placeholder="Nombre final"
              value={mergeName}
              onChange={(e) => setMergeName(e.target.value)}
            />
            <Button onClick={doMerge} disabled={!mergeName.trim()}>
              <Link2 className="size-4" />
              Unir
            </Button>
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardContent className="p-0">
          {clusters.length === 0 ? (
            <p className="p-5 text-center text-sm text-muted-foreground">
              Todavía no hay datos en este alcance.
            </p>
          ) : (
            <ul>
              {clusters.map((c) => (
                <li key={c.key} className="border-b border-border last:border-0">
                  <div className="flex items-center gap-2 px-4 py-3">
                    <input
                      type="checkbox"
                      className="size-4 accent-[var(--accent)]"
                      checked={selected.includes(c.key)}
                      onChange={() => toggle(c.key)}
                    />
                    <button
                      type="button"
                      className="flex min-w-0 flex-1 items-center justify-between gap-2 text-left"
                      onClick={() =>
                        setOpenKey(openKey === c.key ? null : c.key)
                      }
                    >
                      <span className="flex min-w-0 items-center gap-1.5">
                        <span className="truncate text-sm font-medium">
                          {c.label}
                        </span>
                        {c.merged ? (
                          <button
                            type="button"
                            className="inline-flex size-7 items-center justify-center rounded-md hover:bg-muted"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (c.mergeId) unmergeComercio(c.mergeId);
                            }}
                            aria-label="Deshacer unión"
                          >
                            <Unlink className="size-3.5 text-muted-foreground" />
                          </button>
                        ) : null}
                      </span>
                      <span className="flex items-center gap-1">
                        <span className="tabular text-sm font-semibold">
                          {formatEUR(c.total)}
                        </span>
                        <ChevronDown
                          className={cn(
                            "size-4 text-muted-foreground transition-transform",
                            openKey === c.key && "rotate-180",
                          )}
                        />
                      </span>
                    </button>
                  </div>
                  {openKey === c.key ? (
                    <div className="bg-muted/50 px-4 py-2">
                      {c.origins.map((o) => (
                        <div
                          key={o.label}
                          className="flex justify-between gap-2 py-0.5 text-xs text-muted-foreground"
                        >
                          <span className="truncate">{o.label}</span>
                          <span className="tabular">{formatEUR(o.total)}</span>
                        </div>
                      ))}
                    </div>
                  ) : null}
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {clusters.length > 0 ? (
        <div className="flex items-baseline justify-between px-1">
          <span className="text-sm text-muted-foreground">Total</span>
          <span className="font-display text-2xl font-medium tabular">
            {formatEUR(total)}
          </span>
        </div>
      ) : null}
    </div>
  );
}
