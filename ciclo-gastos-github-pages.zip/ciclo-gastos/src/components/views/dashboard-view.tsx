import { ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  cycleKeyFromRange,
  cycleLabelFromRange,
  getCurrentCycleRange,
  getPreviousCycleRange,
  rangeFromMonthKey,
} from "@/lib/money/cycle";
import { formatDateEs, formatEUR } from "@/lib/money/format";
import { parseAmount } from "@/lib/money/parse";
import {
  categorySubtotals,
  computePeriodSummary,
  findDuplicateCandidates,
} from "@/lib/money/summary";
import { allCategories } from "@/lib/money/groups";
import { useExpenses } from "@/store/expenses";

export function DashboardView() {
  const months = useExpenses((s) => s.months);
  const rawRows = useExpenses((s) => s.rawRows);
  const customCategories = useExpenses((s) => s.customCategories);
  const categoryDefaults = useExpenses((s) => s.categoryDefaults);
  const dispuesto = useExpenses((s) => s.dispuesto);
  const setDispuesto = useExpenses((s) => s.setDispuesto);
  const liquidacion = useExpenses((s) => s.liquidacion);
  const setLiquidacion = useExpenses((s) => s.setLiquidacion);
  const setActiveRange = useExpenses((s) => s.setActiveRange);
  const setTab = useExpenses((s) => s.setTab);
  const isDemo = useExpenses((s) => s.isDemo);

  const current = getCurrentCycleRange();
  const previous = getPreviousCycleRange();
  const currentSum = computePeriodSummary(
    rawRows,
    months,
    current,
    categoryDefaults,
  );
  const prevSum = computePeriodSummary(
    rawRows,
    months,
    previous,
    categoryDefaults,
  );
  const total = currentSum.order.reduce(
    (s, k) => s + currentSum.groups[k].total,
    0,
  );
  const prevTotal = prevSum.order.reduce(
    (s, k) => s + prevSum.groups[k].total,
    0,
  );
  const diff = dispuesto - total;
  const pct =
    dispuesto > 0 ? Math.min(100, Math.max(0, (total / dispuesto) * 100)) : 0;

  const cats = allCategories(customCategories);
  const catTotals = categorySubtotals(currentSum.groups, customCategories);
  const catRows = [
    ...cats.map((c) => ({ id: c.id, label: c.label, total: catTotals[c.id] || 0 })),
    { id: "sin", label: "Sin categoría", total: catTotals.sin || 0 },
  ].filter((r) => r.total > 0);

  const startTime = current.start.getTime();
  const endTime = new Date(
    current.end.getFullYear(),
    current.end.getMonth(),
    current.end.getDate(),
    23,
    59,
    59,
  ).getTime();
  const dups = findDuplicateCandidates(rawRows, startTime, endTime);

  const trend = buildTrend(months, rawRows, categoryDefaults);

  const top = [...currentSum.order]
    .sort((a, b) => currentSum.groups[b].total - currentSum.groups[a].total)
    .slice(0, 5);

  const delta = prevTotal > 0 ? ((total - prevTotal) / prevTotal) * 100 : 0;

  return (
    <div className="flex flex-col gap-4">
      {isDemo ? (
        <p className="rounded-xl bg-secondary px-3 py-2 text-xs text-secondary-foreground">
          Estás viendo un ciclo de ejemplo. Importa tu extracto o añade un
          gasto para sustituirlo.
        </p>
      ) : null}

      <Card>
        <CardContent className="flex flex-col gap-3">
          <div className="flex items-baseline justify-between gap-3">
            <div>
              <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
                {cycleLabelFromRange(current)}
              </p>
              <p className="text-xs text-muted-foreground">
                {formatDateEs(current.start.getTime())} —{" "}
                {formatDateEs(current.end.getTime())}
              </p>
            </div>
            {prevTotal > 0 ? (
              <span className="text-xs font-medium text-muted-foreground">
                {delta >= 0 ? "+" : ""}
                {delta.toFixed(0)}% vs anterior
              </span>
            ) : null}
          </div>
          <p className="font-display text-4xl font-medium tracking-tight tabular">
            {formatEUR(total)}
          </p>
          <p className="text-sm text-muted-foreground">
            {currentSum.count} movimiento{currentSum.count === 1 ? "" : "s"} este
            ciclo
          </p>
          <Button
            className="mt-1 w-full"
            onClick={() => {
              setActiveRange(current);
              setTab("ciclo");
            }}
          >
            Ver gastos del ciclo
            <ChevronRight className="size-4" />
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex flex-col gap-3">
          <div className="flex items-end justify-between gap-3">
            <div className="flex-1">
              <Label htmlFor="dispuesto">Dispuesto del banco</Label>
              <Input
                id="dispuesto"
                inputMode="decimal"
                className="mt-1 tabular"
                defaultValue={dispuesto ? String(dispuesto).replace(".", ",") : ""}
                placeholder="0,00"
                onBlur={(e) => setDispuesto(parseAmount(e.target.value) || 0)}
              />
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">Diferencia</p>
              <p
                className="text-lg font-semibold tabular"
                style={{
                  color:
                    Math.abs(diff) < 0.005
                      ? "var(--success)"
                      : diff < 0
                        ? "var(--danger)"
                        : "var(--success)",
                }}
              >
                {formatEUR(diff)}
              </p>
            </div>
          </div>
          {dispuesto > 0 ? (
            <div className="h-2 overflow-hidden rounded-full bg-muted">
              <div
                className="h-full rounded-full bg-accent transition-[width] duration-300"
                style={{ width: `${pct}%` }}
              />
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">
              Escribe el dispuesto de la app del banco para cuadrar el ciclo.
            </p>
          )}
          <StatusLine diff={diff} dups={dups} />
          <div>
            <Label htmlFor="liquidacion">Liquidación anterior</Label>
            <Input
              id="liquidacion"
              inputMode="decimal"
              className="mt-1 tabular"
              defaultValue={
                liquidacion ? String(liquidacion).replace(".", ",") : ""
              }
              placeholder="0,00"
              onBlur={(e) => setLiquidacion(parseAmount(e.target.value) || 0)}
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Button
          variant="outline"
          className="h-auto flex-col items-start gap-1 py-3"
          onClick={() => {
            setActiveRange(current);
            setTab("ciclo");
          }}
        >
          <span className="text-[11px] text-muted-foreground">Actual</span>
          <span className="text-sm font-semibold">
            {cycleLabelFromRange(current).replace("Ciclo ", "")}
          </span>
        </Button>
        <Button
          variant="outline"
          className="h-auto flex-col items-start gap-1 py-3"
          onClick={() => {
            setActiveRange(previous);
            setTab("ciclo");
          }}
        >
          <span className="text-[11px] text-muted-foreground">Anterior</span>
          <span className="text-sm font-semibold">
            {cycleLabelFromRange(previous).replace("Ciclo ", "")}
          </span>
        </Button>
      </div>

      {catRows.length > 0 ? (
        <Card>
          <CardContent>
            <p className="mb-3 text-sm font-medium">Por categoría</p>
            <div className="mb-3 flex h-2.5 overflow-hidden rounded-full">
              {catRows.map((r) => (
                <div
                  key={r.id}
                  title={r.label}
                  className="h-full"
                  style={{
                    width: `${(r.total / total) * 100}%`,
                    background: `var(--cat-${r.id}, var(--cat-sin))`,
                  }}
                />
              ))}
            </div>
            <ul className="flex flex-col gap-1.5">
              {catRows.map((r) => (
                <li
                  key={r.id}
                  className="flex items-center justify-between text-sm"
                >
                  <span className="flex items-center gap-2 text-muted-foreground">
                    <span
                      className="size-2 rounded-full"
                      style={{
                        background: `var(--cat-${r.id}, var(--cat-sin))`,
                      }}
                    />
                    {r.label}
                  </span>
                  <span className="tabular font-medium">{formatEUR(r.total)}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      ) : null}

      {trend.length > 1 ? (
        <Card>
          <CardContent>
            <p className="mb-3 text-sm font-medium">Tendencia</p>
            <TrendBars
              items={trend}
              onSelect={(key) => {
                const range = rangeFromMonthKey(key);
                if (range) {
                  setActiveRange(range);
                  setTab("ciclo");
                }
              }}
              activeKey={cycleKeyFromRange(current)}
            />
          </CardContent>
        </Card>
      ) : null}

      {top.length > 0 ? (
        <Card>
          <CardContent>
            <p className="mb-3 text-sm font-medium">Comercios de este ciclo</p>
            <ul className="flex flex-col">
              {top.map((k) => {
                const g = currentSum.groups[k];
                return (
                  <li
                    key={k}
                    className="flex items-baseline justify-between gap-3 border-b border-border py-2 last:border-0"
                  >
                    <span className="min-w-0 truncate text-sm">{g.label}</span>
                    <span className="tabular text-sm font-semibold">
                      {formatEUR(g.total)}
                    </span>
                  </li>
                );
              })}
            </ul>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}

function StatusLine({
  diff,
  dups,
}: {
  diff: number;
  dups: { concept: string; amount: number; count: number }[];
}) {
  if (Math.abs(diff) < 0.005) {
    return (
      <p className="text-xs font-medium" style={{ color: "var(--success)" }}>
        Cuadra exacto con el dispuesto.
      </p>
    );
  }
  if (diff > 0) {
    return (
      <p className="text-xs text-muted-foreground">
        Faltan {formatEUR(diff)} por registrar para llegar al dispuesto.
      </p>
    );
  }
  return (
    <div className="text-xs" style={{ color: "var(--danger)" }}>
      <p className="font-medium">Sobran {formatEUR(Math.abs(diff))}.</p>
      {dups.length ? (
        <ul className="mt-1 text-foreground">
          {dups.map((d) => (
            <li key={d.concept}>
              Posible duplicado: {d.concept} ×{d.count}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-muted-foreground">
          Revisa gastos a mano o movimientos repetidos.
        </p>
      )}
    </div>
  );
}

function buildTrend(
  months: Record<string, { groups: Record<string, { total: number }> }>,
  _rawRows: unknown,
  _rules: unknown,
) {
  const keys = Object.keys(months)
    .filter((k) => k !== "sin-fecha")
    .sort();
  return keys.slice(-6).map((key) => ({
    key,
    total: Object.values(months[key].groups).reduce((s, g) => s + g.total, 0),
    label: key.slice(5),
  }));
}

function TrendBars({
  items,
  onSelect,
  activeKey,
}: {
  items: { key: string; total: number; label: string }[];
  onSelect: (key: string) => void;
  activeKey: string;
}) {
  const max = Math.max(...items.map((i) => i.total), 1);
  return (
    <div className="flex h-28 items-end gap-2">
      {items.map((i) => (
        <button
          key={i.key}
          type="button"
          onClick={() => onSelect(i.key)}
          className="flex h-full flex-1 flex-col items-center justify-end gap-1"
        >
          <span
            className="w-full rounded-t-md"
            style={{
              height: `${(i.total / max) * 100}%`,
              background:
                i.key === activeKey ? "var(--accent)" : "var(--bg-subtle)",
              minHeight: 4,
            }}
          />
          <span className="text-[10px] text-muted-foreground">{i.label}</span>
        </button>
      ))}
    </div>
  );
}
