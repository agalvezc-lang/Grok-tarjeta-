import {
  CreditCard,
  Home,
  MoreHorizontal,
  PieChart,
  Plus,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useExpenses, type TabId } from "@/store/expenses";

const NAV: { id: TabId; label: string; icon: typeof Home }[] = [
  { id: "inicio", label: "Inicio", icon: Home },
  { id: "ciclo", label: "Ciclo", icon: CreditCard },
  { id: "resumen", label: "Resumen", icon: PieChart },
  { id: "mas", label: "Más", icon: MoreHorizontal },
];

export function AppShell({
  children,
  onAdd,
}: {
  children: React.ReactNode;
  onAdd: () => void;
}) {
  const tab = useExpenses((s) => s.tab);
  const setTab = useExpenses((s) => s.setTab);
  const isDemo = useExpenses((s) => s.isDemo);

  return (
    <div className="mx-auto min-h-dvh max-w-lg bg-background pb-28">
      <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-background/90 px-4 py-3 backdrop-blur-sm">
        <div>
          <p className="font-display text-xl font-medium leading-tight tracking-tight italic">
            Ciclo
          </p>
          <p className="text-[11px] font-medium tracking-[0.14em] text-muted-foreground uppercase">
            Tarjeta Caja Rural
          </p>
        </div>
        {isDemo ? (
          <span className="rounded-full bg-secondary px-2.5 py-1 text-[11px] font-medium text-secondary-foreground">
            Datos de ejemplo
          </span>
        ) : null}
      </header>

      <main className="px-4 py-5">{children}</main>

      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm">
        <div className="mx-auto flex max-w-lg items-end">
          {NAV.slice(0, 2).map((item) => (
            <NavBtn
              key={item.id}
              item={item}
              active={tab === item.id}
              onClick={() => setTab(item.id)}
            />
          ))}
          <div className="flex flex-1 justify-center pb-2">
            <button
              type="button"
              onClick={onAdd}
              className="flex size-12 -translate-y-3 items-center justify-center rounded-full bg-accent text-accent-foreground shadow-border"
              aria-label="Añadir gasto"
            >
              <Plus className="size-5" />
            </button>
          </div>
          {NAV.slice(2).map((item) => (
            <NavBtn
              key={item.id}
              item={item}
              active={tab === item.id}
              onClick={() => setTab(item.id)}
            />
          ))}
        </div>
      </nav>
    </div>
  );
}

function NavBtn({
  item,
  active,
  onClick,
}: {
  item: (typeof NAV)[number];
  active: boolean;
  onClick: () => void;
}) {
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex flex-1 flex-col items-center gap-1 py-2.5 text-[11px] font-medium",
        active ? "text-accent" : "text-muted-foreground",
      )}
    >
      <Icon className="size-5" strokeWidth={active ? 2.2 : 1.8} />
      {item.label}
    </button>
  );
}
