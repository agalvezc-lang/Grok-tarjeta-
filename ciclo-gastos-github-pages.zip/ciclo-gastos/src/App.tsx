import { useState } from "react";
import { Toaster, toast } from "sonner";
import { AppShell } from "@/components/layout/app-shell";
import { AddExpenseDialog } from "@/components/views/add-expense-dialog";
import { CycleView } from "@/components/views/cycle-view";
import { DashboardView } from "@/components/views/dashboard-view";
import { MoreView } from "@/components/views/more-view";
import { SummaryView } from "@/components/views/summary-view";
import { getCurrentCycleRange } from "@/lib/money/cycle";
import { useExpenses } from "@/store/expenses";

export default function App() {
  const hydrated = useExpenses((s) => s.hydrated);
  const tab = useExpenses((s) => s.tab);
  const importFile = useExpenses((s) => s.importFile);
  const [addOpen, setAddOpen] = useState(false);

  if (typeof window !== "undefined" && !useExpenses.getState().hydrated) {
    useExpenses.getState().hydrate();
    const s = useExpenses.getState();
    if (!s.activeRange) s.setActiveRange(getCurrentCycleRange());
  }

  const ready = hydrated || (typeof window !== "undefined" && useExpenses.getState().hydrated);

  async function onImport(file: File) {
    try {
      toast.loading("Leyendo extracto…", { id: "import" });
      const res = await importFile(file);
      toast.success(
        `Importados ${res.validRows} movimientos · ${res.addedNew} conceptos nuevos${res.duplicates ? ` · ${res.duplicates} duplicados omitidos` : ""}`,
        { id: "import" },
      );
      useExpenses.getState().setTab("ciclo");
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : "No se pudo leer el archivo",
        { id: "import" },
      );
    }
  }

  if (!ready) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center bg-background text-foreground">
        <p className="font-display text-3xl font-medium italic tracking-tight">
          Ciclo
        </p>
        <p className="mt-2 text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">
          Tarjeta Caja Rural
        </p>
      </div>
    );
  }

  return (
    <>
      <AppShell onAdd={() => setAddOpen(true)}>
        {tab === "inicio" ? <DashboardView /> : null}
        {tab === "ciclo" ? <CycleView /> : null}
        {tab === "resumen" ? <SummaryView /> : null}
        {tab === "mas" ? <MoreView onImportFile={onImport} /> : null}
      </AppShell>
      <AddExpenseDialog open={addOpen} onOpenChange={setAddOpen} />
      <Toaster
        position="top-center"
        theme="system"
        richColors={false}
        toastOptions={{
          className: "font-sans",
        }}
      />
    </>
  );
}
