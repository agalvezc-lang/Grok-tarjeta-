import {
  Clapperboard,
  Cross,
  Ellipsis,
  House,
  Plane,
  ShoppingBag,
  ShoppingCart,
  Sparkles,
  TrainFront,
  Utensils,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import type { CategoryId } from "./types";

export const CATEGORY_META: Record<
  CategoryId,
  { label: string; icon: LucideIcon; chart: string }
> = {
  food: { label: "Comida", icon: Utensils, chart: "var(--color-chart-1)" },
  groceries: { label: "Despensa", icon: ShoppingCart, chart: "var(--color-chart-2)" },
  transport: { label: "Transporte", icon: TrainFront, chart: "var(--color-chart-3)" },
  home: { label: "Hogar", icon: House, chart: "var(--color-chart-4)" },
  health: { label: "Salud", icon: Cross, chart: "var(--color-chart-5)" },
  entertainment: { label: "Ocio", icon: Clapperboard, chart: "var(--color-chart-6)" },
  shopping: { label: "Compras", icon: ShoppingBag, chart: "var(--color-chart-1)" },
  subscriptions: { label: "Suscripciones", icon: Sparkles, chart: "var(--color-chart-3)" },
  travel: { label: "Viajes", icon: Plane, chart: "var(--color-chart-4)" },
  services: { label: "Servicios", icon: Wrench, chart: "var(--color-chart-5)" },
  other: { label: "Otros", icon: Ellipsis, chart: "var(--color-chart-6)" },
};

export const CATEGORY_LIST = (Object.keys(CATEGORY_META) as CategoryId[]).map((id) => ({
  id,
  ...CATEGORY_META[id],
}));

const MERCHANT_HINTS: Array<[RegExp, CategoryId]> = [
  [/oxxo|seven eleven|7-eleven|circle k|mercadona|carrefour|dia |aldi|lidl/i, "groceries"],
  [/uber|didi|cabify|metro|pemex|gasolin|shell|bp |renfe|bolt/i, "transport"],
  [/netflix|spotify|disney|hbo|prime video|youtube|apple one|icloud/i, "subscriptions"],
  [/cfe|telmex|izzi|totalplay|axtel|telcel|movistar|at&t|endesa|iberdrola|naturgy/i, "services"],
  [/uber eats|rappi|didi food|starbucks|vips|sanborns|restaur|mcdonald|burger king/i, "food"],
  [/walmart|soriana|chedraui|aurrera|superama|heb |costco|sams|mercadona/i, "groceries"],
  [/farmacia|guadalajara|similares|benavides|hospital|farmacias/i, "health"],
  [/cinepolis|cinemex|boleto|ticketmaster|cinesa/i, "entertainment"],
  [/liverpool|palacio|zara|h&m|amazon|mercado libre|shein|el corte ingles/i, "shopping"],
  [/aeromexico|volaris|viva aerobus|booking|airbnb|hotel|iberia|vueling|ryanair/i, "travel"],
  [/ikea|home depot|sodimac|coppel hogar|leroy merlin/i, "home"],
];

export function guessCategory(merchant: string): CategoryId {
  for (const [re, cat] of MERCHANT_HINTS) {
    if (re.test(merchant)) return cat;
  }
  return "other";
}
