export const IMAGE_ACCEPT =
  "image/*,image/jpeg,image/png,image/webp,image/heic,image/heif,.jpg,.jpeg,.png,.webp,.heic,.heif";

export async function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export async function compressImage(
  source: File | Blob | HTMLImageElement | string,
  maxEdge = 1280,
  quality = 0.72,
): Promise<string> {
  const img = await loadImage(source);
  const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
  const width = Math.max(1, Math.round(img.width * scale));
  const height = Math.max(1, Math.round(img.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("No se pudo procesar la imagen");
  ctx.fillStyle = "#111110";
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(img, 0, 0, width, height);
  return canvas.toDataURL("image/jpeg", quality);
}

async function loadImage(source: File | Blob | HTMLImageElement | string) {
  if (source instanceof HTMLImageElement) return source;

  if (typeof createImageBitmap === "function" && typeof source !== "string") {
    try {
      const bitmap = await createImageBitmap(source);
      const canvas = document.createElement("canvas");
      canvas.width = bitmap.width;
      canvas.height = bitmap.height;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("bitmap");
      ctx.drawImage(bitmap, 0, 0);
      bitmap.close();
      const img = new Image();
      img.crossOrigin = "anonymous";
      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error("No se pudo leer la imagen"));
        img.src = canvas.toDataURL("image/jpeg", 0.92);
      });
      return img;
    } catch {
      // Fall through to the Image() path (JPEG/PNG).
    }
  }

  const img = new Image();
  img.crossOrigin = "anonymous";
  const url = typeof source === "string" ? source : URL.createObjectURL(source);
  try {
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error("No se pudo leer la imagen"));
      img.src = url;
    });
  } finally {
    if (typeof source !== "string") URL.revokeObjectURL(url);
  }
  return img;
}

export function isSupportedImage(file: File) {
  if (!file) return false;
  if (/image\/(jpeg|jpg|png|webp|gif|heic|heif|bmp)/i.test(file.type)) return true;
  return /\.(jpe?g|png|webp|gif|heic|heif|bmp)$/i.test(file.name);
}

export function filesFromList(list: FileList | File[] | null | undefined): File[] {
  if (!list) return [];
  return Array.from(list).filter(isSupportedImage);
}

export async function prepareReceipt(file: File): Promise<{ scanSrc: string; thumb: string }> {
  if (!isSupportedImage(file)) {
    throw new Error("Usa una foto JPG, PNG o WEBP del ticket.");
  }
  try {
    const scanSrc = await compressImage(file, 1024, 0.6);
    const thumb = await compressImage(file, 360, 0.5);
    return { scanSrc, thumb };
  } catch {
    throw new Error("No se pudo abrir esa foto. Elige otra de la galería (JPG o PNG).");
  }
}
