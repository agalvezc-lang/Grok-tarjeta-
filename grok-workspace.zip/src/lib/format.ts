import { format } from "date-fns";
import { es } from "date-fns/locale";
import type { Currency } from "./types";

export function formatMoney(amount: number, currency: Currency) {
  return new Intl.NumberFormat("es-MX", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
  }).format(amount);
}

export function formatMoneyCompact(amount: number, currency: Currency) {
  const abs = Math.abs(amount);
  if (abs >= 1_000_000) {
    return new Intl.NumberFormat("es-MX", {
      style: "currency",
      currency,
      maximumFractionDigits: 1,
    }).format(amount / 1_000_000) + " M";
  }
  return formatMoney(amount, currency);
}

export function formatDayMonth(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  const date = new Date(y, m - 1, d);
  return format(date, "d MMM", { locale: es });
}

export function formatFullDate(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  const date = new Date(y, m - 1, d);
  return format(date, "d 'de' MMMM yyyy", { locale: es });
}

export function formatMonthTitle(year: number, month: number) {
  const date = new Date(year, month, 1);
  return format(date, "MMMM yyyy", { locale: es });
}

export function formatMonthShort(year: number, month: number) {
  const date = new Date(year, month, 1);
  return format(date, "MMM yy", { locale: es });
}

export function parseAmount(raw: string): number | null {
  const cleaned = raw.replace(/[^\d.,-]/g, "").trim();
  if (!cleaned) return null;
  const hasComma = cleaned.includes(",");
  const hasDot = cleaned.includes(".");
  let normalized = cleaned;
  if (hasComma && hasDot) {
    if (cleaned.lastIndexOf(",") > cleaned.lastIndexOf(".")) {
      normalized = cleaned.replace(/\./g, "").replace(",", ".");
    } else {
      normalized = cleaned.replace(/,/g, "");
    }
  } else if (hasComma) {
    const parts = cleaned.split(",");
    normalized = parts.length === 2 && parts[1].length <= 2
      ? parts.join(".")
      : cleaned.replace(/,/g, "");
  }
  const n = Number(normalized);
  return Number.isFinite(n) ? Math.round(n * 100) / 100 : null;
}

export function splitInstallments(total: number, n: number): number[] {
  const count = Math.max(1, Math.min(24, Math.round(n)));
  const cents = Math.round(total * 100);
  const base = Math.floor(cents / count);
  const rem = cents - base * count;
  return Array.from({ length: count }, (_, i) => (base + (i < rem ? 1 : 0)) / 100);
}

export function daysUntil(date: Date) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const target = new Date(date);
  target.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - today.getTime()) / 86_400_000);
}
