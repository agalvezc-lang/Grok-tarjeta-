import type { Card, Expense } from "./types";
import { todayISO } from "./utils";

function shiftISO(days: number) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function createDemoCards(): Card[] {
  const now = "2026-01-01T00:00:00.000Z";
  return [
    {
      id: "card-nu",
      name: "Nu",
      last4: "4412",
      brand: "mastercard",
      color: "plum",
      limit: 35000,
      closeDay: 12,
      dueDay: 20,
      createdAt: now,
    },
    {
      id: "card-bbva",
      name: "BBVA Azul",
      last4: "8891",
      brand: "visa",
      color: "navy",
      limit: 50000,
      closeDay: 25,
      dueDay: 12,
      createdAt: now,
    },
    {
      id: "card-santander",
      name: "Santander Like",
      last4: "2204",
      brand: "visa",
      color: "wine",
      limit: 22000,
      closeDay: 5,
      dueDay: 18,
      createdAt: now,
    },
  ];
}

export function createDemoExpenses(cards: Card[]): Expense[] {
  const nu = cards[0]?.id ?? "card-nu";
  const bbva = cards[1]?.id ?? "card-bbva";
  const san = cards[2]?.id ?? "card-santander";
  const rows: Array<Omit<Expense, "id" | "createdAt">> = [
    { cardId: nu, merchant: "Netflix", amount: 299, category: "subscriptions", date: shiftISO(-2), installments: 1, note: "Plan estándar" },
    { cardId: nu, merchant: "Uber", amount: 186.5, category: "transport", date: shiftISO(-1), installments: 1, note: "" },
    { cardId: nu, merchant: "Oxxo Reforma", amount: 99.4, category: "groceries", date: todayISO(), installments: 1, note: "" },
    { cardId: nu, merchant: "Spotify", amount: 129, category: "subscriptions", date: shiftISO(-18), installments: 1, note: "" },
    { cardId: bbva, merchant: "CFE", amount: 1240, category: "services", date: shiftISO(-6), installments: 1, note: "Recibo bimestral" },
    { cardId: bbva, merchant: "Liverpool", amount: 7200, category: "shopping", date: shiftISO(-10), installments: 6, note: "MSI" },
    { cardId: bbva, merchant: "Walmart", amount: 1864.2, category: "groceries", date: shiftISO(-4), installments: 1, note: "" },
    { cardId: bbva, merchant: "Uber Eats", amount: 312, category: "food", date: shiftISO(-3), installments: 1, note: "" },
    { cardId: san, merchant: "Cinépolis", amount: 248, category: "entertainment", date: shiftISO(-8), installments: 1, note: "" },
    { cardId: san, merchant: "Farmacia Guadalajara", amount: 540.8, category: "health", date: shiftISO(-5), installments: 1, note: "" },
    { cardId: san, merchant: "Telcel", amount: 449, category: "services", date: shiftISO(-14), installments: 1, note: "Plan" },
    { cardId: nu, merchant: "Rappi", amount: 221, category: "food", date: shiftISO(-12), installments: 1, note: "" },
    { cardId: bbva, merchant: "Pemex", amount: 980, category: "transport", date: shiftISO(-9), installments: 1, note: "" },
    { cardId: san, merchant: "Aeroméxico", amount: 4680, category: "travel", date: shiftISO(-22), installments: 3, note: "Vuelo GDL" },
  ];
  return rows.map((row, i) => ({
    ...row,
    id: `exp-demo-${i}`,
    createdAt: `${row.date}T12:00:00.000Z`,
  }));
}

