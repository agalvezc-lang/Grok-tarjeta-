import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Card, Currency, Expense, PaidCycle } from "./types";
import { createDemoCards, createDemoExpenses } from "./seed";
import { uid } from "./utils";

export type TabId = "home" | "cards" | "history" | "insights";

type Store = {
  cards: Card[];
  expenses: Expense[];
  paid: PaidCycle[];
  currency: Currency;
  isDemo: boolean;
  hasOnboarded: boolean;
  hydrated: boolean;
  tab: TabId;
  setHydrated: (v: boolean) => void;
  setTab: (tab: TabId) => void;
  setCurrency: (c: Currency) => void;
  addCard: (card: Omit<Card, "id" | "createdAt">) => string;
  updateCard: (id: string, patch: Partial<Card>) => void;
  deleteCard: (id: string) => void;
  addExpense: (expense: Omit<Expense, "id" | "createdAt">) => string;
  updateExpense: (id: string, patch: Partial<Expense>) => void;
  deleteExpense: (id: string) => void;
  togglePaid: (cardId: string, year: number, month: number) => void;
  loadDemo: () => void;
  clearAll: () => void;
};

const empty = {
  cards: [] as Card[],
  expenses: [] as Expense[],
  paid: [] as PaidCycle[],
  currency: "MXN" as Currency,
  isDemo: false,
  hasOnboarded: false,
};

function demoState() {
  const cards = createDemoCards();
  return {
    cards,
    expenses: createDemoExpenses(cards),
    paid: [] as PaidCycle[],
    currency: "MXN" as Currency,
    isDemo: true,
    hasOnboarded: false,
  };
}

export const useStore = create<Store>()(
  persist(
    (set, get) => ({
      ...demoState(),
      hydrated: false,
      tab: "home",
      setHydrated: (v) => set({ hydrated: v }),
      setTab: (tab) => set({ tab }),
      setCurrency: (currency) => set({ currency }),
      addCard: (card) => {
        const id = uid();
        set({
          cards: [...get().cards, { ...card, id, createdAt: new Date().toISOString() }],
          isDemo: false,
          hasOnboarded: true,
        });
        return id;
      },
      updateCard: (id, patch) =>
        set({
          cards: get().cards.map((c) => (c.id === id ? { ...c, ...patch, id } : c)),
        }),
      deleteCard: (id) =>
        set({
          cards: get().cards.filter((c) => c.id !== id),
          expenses: get().expenses.filter((e) => e.cardId !== id),
          paid: get().paid.filter((p) => p.cardId !== id),
          isDemo: false,
          hasOnboarded: true,
        }),
      addExpense: (expense) => {
        const id = uid();
        set({
          expenses: [
            { ...expense, id, createdAt: new Date().toISOString() },
            ...get().expenses,
          ],
          isDemo: false,
          hasOnboarded: true,
        });
        return id;
      },
      updateExpense: (id, patch) =>
        set({
          expenses: get().expenses.map((e) => (e.id === id ? { ...e, ...patch, id } : e)),
          isDemo: false,
        }),
      deleteExpense: (id) =>
        set({
          expenses: get().expenses.filter((e) => e.id !== id),
          isDemo: false,
        }),
      togglePaid: (cardId, year, month) => {
        const paid = get().paid;
        const exists = paid.some((p) => p.cardId === cardId && p.year === year && p.month === month);
        set({
          paid: exists
            ? paid.filter((p) => !(p.cardId === cardId && p.year === year && p.month === month))
            : [...paid, { cardId, year, month }],
        });
      },
      loadDemo: () => {
        const cards = createDemoCards();
        set({
          cards,
          expenses: createDemoExpenses(cards),
          paid: [],
          isDemo: true,
          hasOnboarded: true,
          currency: "MXN",
        });
      },
      clearAll: () => set({ ...empty, hasOnboarded: true }),
    }),
    {
      name: "gastos-alcorte-v1",
      partialize: (s) => ({
        cards: s.cards,
        expenses: s.expenses,
        paid: s.paid,
        currency: s.currency,
        isDemo: s.isDemo,
        hasOnboarded: s.hasOnboarded,
      }),
      onRehydrateStorage: () => (state) => {
        if (!state) return;
        if (state.cards.length === 0 && !state.hasOnboarded) state.loadDemo();
        state.setHydrated(true);
      },
    },
  ),
);
