export const CARD_COLORS = [
  "navy",
  "wine",
  "forest",
  "ink",
  "slate",
  "rust",
  "ocean",
  "plum",
] as const;

export type CardColor = (typeof CARD_COLORS)[number];

export const CARD_BRANDS = ["visa", "mastercard", "amex", "carnet", "other"] as const;
export type CardBrand = (typeof CARD_BRANDS)[number];

export const CATEGORIES = [
  "food",
  "groceries",
  "transport",
  "home",
  "health",
  "entertainment",
  "shopping",
  "subscriptions",
  "travel",
  "services",
  "other",
] as const;

export type CategoryId = (typeof CATEGORIES)[number];

export const CURRENCIES = ["MXN", "USD", "EUR", "COP", "ARS", "CLP", "PEN"] as const;
export type Currency = (typeof CURRENCIES)[number];

export type Card = {
  id: string;
  name: string;
  last4: string;
  brand: CardBrand;
  color: CardColor;
  limit: number;
  closeDay: number;
  dueDay: number;
  createdAt: string;
};

export type Expense = {
  id: string;
  cardId: string;
  merchant: string;
  amount: number;
  category: CategoryId;
  date: string;
  installments: number;
  note: string;
  receiptThumb?: string;
  createdAt: string;
};

export type PaidCycle = {
  cardId: string;
  year: number;
  month: number;
};

export type CycleKey = {
  year: number;
  month: number;
};

export type Charge = {
  expense: Expense;
  installmentIndex: number;
  amount: number;
  cycle: CycleKey;
};
