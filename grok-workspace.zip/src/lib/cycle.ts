import { addMonths, clampDay, isoToParts } from "./utils";
import type { Card, Charge, CycleKey, Expense, PaidCycle } from "./types";
import { splitInstallments } from "./format";

export type Cycle = CycleKey & {
  close: Date;
  due: Date;
  start: Date;
};

export function cycleKeyOf(closeDay: number, isoDate: string): CycleKey {
  const { year, month, day } = isoToParts(isoDate);
  if (day > closeDay) return addMonths(year, month, 1);
  return { year, month };
}

export function buildCycle(card: Card, key: CycleKey): Cycle {
  const closeDay = clampDay(key.year, key.month, card.closeDay);
  const close = new Date(key.year, key.month, closeDay);
  const prev = addMonths(key.year, key.month, -1);
  const prevCloseDay = clampDay(prev.year, prev.month, card.closeDay);
  const start = new Date(prev.year, prev.month, prevCloseDay + 1);
  let dueYear = key.year;
  let dueMonth = key.month;
  if (card.dueDay <= card.closeDay) {
    const next = addMonths(key.year, key.month, 1);
    dueYear = next.year;
    dueMonth = next.month;
  }
  const due = new Date(dueYear, dueMonth, clampDay(dueYear, dueMonth, card.dueDay));
  return { ...key, close, due, start };
}

export function currentCycleKey(card: Card, from = new Date()): CycleKey {
  const iso = `${from.getFullYear()}-${String(from.getMonth() + 1).padStart(2, "0")}-${String(from.getDate()).padStart(2, "0")}`;
  return cycleKeyOf(card.closeDay, iso);
}

export function cycleId(key: CycleKey) {
  return `${key.year}-${key.month}`;
}

export function sameCycle(a: CycleKey, b: CycleKey) {
  return a.year === b.year && a.month === b.month;
}

export function expenseCharges(expense: Expense, card: Card): Charge[] {
  const parts = splitInstallments(expense.amount, expense.installments);
  const first = cycleKeyOf(card.closeDay, expense.date);
  return parts.map((amount, installmentIndex) => {
    const cycle = addMonths(first.year, first.month, installmentIndex);
    return { expense, installmentIndex, amount, cycle };
  });
}

export function chargesInCycle(expenses: Expense[], card: Card, key: CycleKey): Charge[] {
  return expenses
    .filter((e) => e.cardId === card.id)
    .flatMap((e) => expenseCharges(e, card))
    .filter((c) => sameCycle(c.cycle, key));
}

export function cycleTotal(expenses: Expense[], card: Card, key: CycleKey) {
  return chargesInCycle(expenses, card, key).reduce((s, c) => s + c.amount, 0);
}

export function isPaid(paid: PaidCycle[], cardId: string, key: CycleKey) {
  return paid.some((p) => p.cardId === cardId && p.year === key.year && p.month === key.month);
}

export function outstandingForCard(expenses: Expense[], card: Card, paid: PaidCycle[], from = new Date()) {
  const current = currentCycleKey(card, from);
  let total = 0;
  for (const expense of expenses.filter((e) => e.cardId === card.id)) {
    for (const charge of expenseCharges(expense, card)) {
      const isFutureOrCurrent =
        charge.cycle.year > current.year ||
        (charge.cycle.year === current.year && charge.cycle.month >= current.month);
      const unpaidPast =
        !isFutureOrCurrent && !isPaid(paid, card.id, charge.cycle);
      if (isFutureOrCurrent || unpaidPast) total += charge.amount;
    }
  }
  return total;
}

export function availableCredit(expenses: Expense[], card: Card, paid: PaidCycle[]) {
  return Math.round((card.limit - outstandingForCard(expenses, card, paid)) * 100) / 100;
}

export function compareCycle(a: CycleKey, b: CycleKey) {
  return a.year - b.year || a.month - b.month;
}
