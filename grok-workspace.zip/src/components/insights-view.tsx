import { useMemo } from "react";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip, Bar, BarChart, XAxis, YAxis } from "recharts";
import { CATEGORY_META } from "@/lib/categories";
import { cycleKeyOf, cycleTotal } from "@/lib/cycle";
import { formatMoney, formatMonthShort } from "@/lib/format";
import { addMonths } from "@/lib/utils";
import { useStore } from "@/lib/store";
import type { CategoryId, CycleKey } from "@/lib/types";
import { Button } from "./ui/button";
import { CURRENCIES } from "@/lib/types";

export function InsightsView({ cycle }: { cycle: CycleKey }) {
  const cards = useStore((s) => s.cards);
  const expenses = useStore((s) => s.expenses);
  const currency = useStore((s) => s.currency);
  const setCurrency = useStore((s) => s.setCurrency);
  const loadDemo = useStore((s) => s.loadDemo);
  const clearAll = useStore((s) => s.clearAll);
  const isDemo = useStore((s) => s.isDemo);

  const byCategory = useMemo(() => {
    const map = new Map<CategoryId, number>();
    for (const e of expenses) {
      const card = cards.find((c) => c.id === e.cardId);
      if (!card) continue;
      const key = cycleKeyOf(card.closeDay, e.date);
      if (key.year !== cycle.year || key.month !== cycle.month) continue;
      map.set(e.category, (map.get(e.category) ?? 0) + e.amount);
    }
    return [...map.entries()]
      .map(([id, value]) => ({
        id,
        name: CATEGORY_META[id].label,
        value: Math.round(value * 100) / 100,
        fill: CATEGORY_META[id].chart,
      }))
      .sort((a, b) => b.value - a.value);
  }, [cards, expenses, cycle]);

  const trend = useMemo(() => {
    const points = [];
    for (let i = 5; i >= 0; i--) {
      const key = addMonths(cycle.year, cycle.month, -i);
      const total = cards.reduce((s, c) => s + cycleTotal(expenses, c, key), 0);
      points.push({
        name: formatMonthShort(key.year, key.month),
        total: Math.round(total),
      });
    }
    return points;
  }, [cards, expenses, cycle]);

  const catTotal = byCategory.reduce((s, c) => s + c.value, 0);

  return (
    <div className="flex flex-col gap-6 pb-8">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-fg-subtle">Lectura</p>
        <h1 className="font-display text-3xl font-medium tracking-tight">Análisis</h1>
      </header>

      <section className="rounded-xl bg-surface p-4">
        <h2 className="text-sm font-medium">Por categoría</h2>
        {byCategory.length === 0 ? (
          <p className="py-10 text-center text-sm text-fg-muted">Sin gastos en este corte.</p>
        ) : (
          <div className="mt-2 grid grid-cols-2 items-center gap-2">
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={byCategory}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={42}
                    outerRadius={68}
                    paddingAngle={2}
                    stroke="none"
                  >
                    {byCategory.map((e) => (
                      <Cell key={e.id} fill={e.fill} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(v) => formatMoney(Number(v), currency)}
                    contentStyle={{
                      background: "var(--color-surface-2)",
                      border: "none",
                      borderRadius: 8,
                      color: "var(--color-fg)",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <ul className="flex flex-col gap-1.5">
              {byCategory.slice(0, 5).map((c) => (
                <li key={c.id} className="flex items-center justify-between gap-2 text-xs">
                  <span className="truncate text-fg-muted">{c.name}</span>
                  <span className="tabular text-fg">
                    {catTotal ? Math.round((c.value / catTotal) * 100) : 0}%
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </section>

      <section className="rounded-xl bg-surface p-4">
        <h2 className="text-sm font-medium">Últimos cortes</h2>
        <div className="mt-3 h-44">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={trend} barCategoryGap="28%">
              <XAxis
                dataKey="name"
                tick={{ fill: "var(--color-fg-muted)", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis hide />
              <Tooltip
                formatter={(v) => formatMoney(Number(v), currency)}
                cursor={{ fill: "rgb(243 239 230 / 0.04)" }}
                contentStyle={{
                  background: "var(--color-surface-2)",
                  border: "none",
                  borderRadius: 8,
                  color: "var(--color-fg)",
                }}
              />
              <Bar dataKey="total" fill="var(--color-accent)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="rounded-xl bg-surface p-4">
        <h2 className="text-sm font-medium">Ajustes</h2>
        <p className="mt-1 text-xs text-fg-muted">Moneda de la app. Los montos no se convierten.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {CURRENCIES.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCurrency(c)}
              className={
                c === currency
                  ? "h-9 rounded-full bg-accent px-3 text-xs font-medium text-accent-fg"
                  : "h-9 rounded-full bg-bg px-3 text-xs font-medium text-fg-muted"
              }
            >
              {c}
            </button>
          ))}
        </div>
        <div className="mt-5 flex flex-col gap-2">
          {isDemo ? (
            <p className="text-xs text-fg-subtle">
              Estás viendo datos de ejemplo. Se reemplazan al agregar un gasto real.
            </p>
          ) : null}
          <Button variant="secondary" onClick={loadDemo}>
            Restaurar ejemplo
          </Button>
          <Button variant="ghost" className="text-danger" onClick={clearAll}>
            Borrar todos los datos
          </Button>
        </div>
      </section>
    </div>
  );
}
