import { useEffect, useRef, useState } from "react";
import { Camera, ImageIcon, Keyboard, Loader2, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "./ui/button";
import { ExpenseForm, draftFromExpense, emptyDraft, type ExpenseDraft } from "./expense-form";
import { CAMERA_INPUT_ID, GALLERY_INPUT_ID, GalleryLabel } from "./gallery-capture";
import { filesFromList, isSupportedImage, prepareReceipt } from "@/lib/image";
import { guessCategory } from "@/lib/categories";
import { parseAmount } from "@/lib/format";
import { scanReceipt } from "@/lib/scan-receipt";
import { useStore } from "@/lib/store";
import type { Expense } from "@/lib/types";
import { todayISO } from "@/lib/utils";

type Step = "pick" | "reading" | "form";

export function AddExpense({
  open,
  onClose,
  editing,
  forceManual = false,
  incomingFiles,
  onConsumedIncoming,
}: {
  open: boolean;
  onClose: () => void;
  editing?: Expense | null;
  forceManual?: boolean;
  incomingFiles?: File[];
  onConsumedIncoming?: () => void;
}) {
  const cards = useStore((s) => s.cards);
  const currency = useStore((s) => s.currency);
  const addExpense = useStore((s) => s.addExpense);
  const updateExpense = useStore((s) => s.updateExpense);
  const [step, setStep] = useState<Step>(
    editing ? "form" : incomingFiles && incomingFiles.length > 0 ? "reading" : forceManual ? "form" : "pick",
  );
  const [preview, setPreview] = useState<string | null>(editing?.receiptThumb ?? null);
  const [draft, setDraft] = useState<ExpenseDraft>(
    editing ? draftFromExpense(editing) : emptyDraft(cards[0]?.id ?? ""),
  );
  const [hint, setHint] = useState<string | null>(null);
  const [queue, setQueue] = useState<File[]>([]);
  const handledRef = useRef<File[] | null>(null);

  useEffect(() => {
    if (!open) {
      handledRef.current = null;
      return;
    }
    setHint(null);
    setQueue([]);
    if (editing) {
      setStep("form");
      setPreview(editing.receiptThumb ?? null);
      setDraft(draftFromExpense(editing));
    } else if (incomingFiles && incomingFiles.length > 0) {
      // handled below
    } else {
      setStep(forceManual ? "form" : "pick");
      setPreview(null);
      setDraft(emptyDraft(cards[0]?.id ?? ""));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editing]);

  useEffect(() => {
    if (!open || !incomingFiles?.length) return;
    if (handledRef.current === incomingFiles) return;
    handledRef.current = incomingFiles;
    const [first, ...rest] = incomingFiles;
    setQueue(rest);
    onConsumedIncoming?.();
    void handleFile(first);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, incomingFiles]);

  if (!open) return null;

  function resetAndClose() {
    setStep(editing ? "form" : "pick");
    setPreview(null);
    setHint(null);
    setQueue([]);
    setDraft(emptyDraft(cards[0]?.id ?? ""));
    onClose();
  }

  async function handleFile(file: File) {
    if (!isSupportedImage(file)) {
      toast.error("Usa una foto JPG o PNG del ticket.");
      setStep(editing ? "form" : "pick");
      return;
    }
    setStep("reading");
    setHint(null);
    try {
      const { scanSrc, thumb } = await prepareReceipt(file);
      setPreview(scanSrc);
      setDraft((d) => ({
        ...d,
        receiptThumb: thumb,
        cardId: d.cardId || cards[0]?.id || "",
      }));

      const result = await scanReceipt({ data: { image: scanSrc } });
      if (!result.ok) {
        setHint(result.error);
        setStep("form");
        return;
      }
      const merchant = result.merchant || "";
      setDraft((d) => ({
        ...d,
        merchant: merchant || d.merchant,
        amount: result.amount != null ? String(result.amount) : d.amount,
        date: result.date || d.date || todayISO(),
        category: result.category !== "other" ? result.category : guessCategory(merchant || d.merchant),
        installments: result.installments || d.installments || 1,
        note: result.note || d.note,
        receiptThumb: thumb,
      }));
      if (!result.merchant && result.amount == null) {
        setHint("No encontré el total. Revisa el ticket y completa el gasto. La foto queda adjunta.");
      }
      setStep("form");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "No se pudo abrir esa imagen.");
      setStep(editing ? "form" : "pick");
    }
  }

  async function loadDemoTicket() {
    try {
      const res = await fetch("/demo-ticket.png");
      const blob = await res.blob();
      const file = new File([blob], "ticket.png", { type: "image/png" });
      await handleFile(file);
    } catch {
      toast.error("No se pudo cargar el ticket de ejemplo.");
    }
  }

  function save() {
    const amount = parseAmount(draft.amount);
    if (amount == null || amount <= 0 || !draft.merchant.trim()) {
      toast.error("Falta el comercio o el monto.");
      return;
    }
    const payload = {
      cardId: draft.cardId || cards[0]?.id || "",
      merchant: draft.merchant.trim(),
      amount,
      category: draft.category,
      date: draft.date || todayISO(),
      installments: draft.installments,
      note: draft.note.trim(),
      receiptThumb: draft.receiptThumb,
    };
    if (!payload.cardId) {
      toast.error("Primero agrega una tarjeta.");
      return;
    }
    if (editing) updateExpense(editing.id, payload);
    else addExpense(payload);

    if (!editing && queue.length > 0) {
      const [next, ...rest] = queue;
      setQueue(rest);
      toast.success("Gasto agregado. Siguiente ticket…");
      setDraft(emptyDraft(payload.cardId));
      void handleFile(next);
      return;
    }

    toast.success(editing ? "Gasto actualizado" : "Gasto agregado");
    resetAndClose();
  }

  const queueLabel =
    queue.length > 0 ? ` · ${queue.length + 1} tickets` : "";

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-bg">
      <header className="flex items-center justify-between px-4 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-fg-subtle">
            {editing ? "Editar" : "Nuevo gasto"}
            {queueLabel}
          </p>
          <h2 className="font-display text-2xl font-medium tracking-tight">
            {step === "pick"
              ? "Desde la galería"
              : step === "reading"
                ? "Leyendo ticket"
                : "Revisa los datos"}
          </h2>
        </div>
        <Button variant="ghost" size="icon" onClick={resetAndClose} aria-label="Cerrar">
          <X className="size-5" />
        </Button>
      </header>

      <div className="flex-1 overflow-y-auto px-4 pb-8">
        {step === "pick" ? (
          <div className="mx-auto flex max-w-lg flex-col gap-4 pt-2 fade-up">
            <GalleryLabel
              className="flex min-h-56 flex-col items-center justify-center gap-3 rounded-xl bg-surface px-6 text-center shadow-[var(--shadow-border)]"
              onDragOver={(e) => {
                e.preventDefault();
              }}
              onDrop={(e) => {
                e.preventDefault();
                const files = filesFromList(e.dataTransfer.files);
                if (files[0]) {
                  setQueue(files.slice(1));
                  void handleFile(files[0]);
                }
              }}
            >
              <span className="flex size-14 items-center justify-center rounded-lg bg-surface-2 text-accent">
                <ImageIcon className="size-6" />
              </span>
              <div>
                <p className="text-base font-medium">Elegir de la galería</p>
                <p className="mt-1 max-w-xs text-sm text-fg-muted">
                  Abre tus fotos, elige el ticket y rellenamos el gasto. Puedes elegir varios.
                </p>
              </div>
            </GalleryLabel>

            <div className="grid grid-cols-2 gap-3">
              <Button asChild variant="secondary" className="h-14">
                <GalleryLabel htmlFor={CAMERA_INPUT_ID} className="flex h-14 items-center justify-center gap-2">
                  <Camera className="size-4" />
                  Cámara
                </GalleryLabel>
              </Button>
              <Button
                variant="secondary"
                className="h-14"
                onClick={() => {
                  setDraft(emptyDraft(cards[0]?.id ?? ""));
                  setPreview(null);
                  setStep("form");
                }}
              >
                <Keyboard className="size-4" />
                A mano
              </Button>
            </div>

            <button
              type="button"
              onClick={() => void loadDemoTicket()}
              className="text-center text-sm text-fg-muted underline-offset-4 hover:text-fg hover:underline"
            >
              Probar con un ticket de ejemplo
            </button>
          </div>
        ) : null}

        {step === "reading" ? (
          <div className="mx-auto max-w-lg pt-2 fade-up">
            <div className="relative overflow-hidden rounded-xl bg-surface">
              {preview ? (
                <img
                  src={preview}
                  alt="Ticket seleccionado"
                  className="max-h-80 w-full object-contain outline outline-1 -outline-offset-1 outline-fg/10"
                />
              ) : (
                <div className="flex h-64 items-center justify-center text-fg-muted">
                  <Loader2 className="size-6 animate-spin" />
                </div>
              )}
              <div className="scan-line pointer-events-none absolute inset-x-0 top-0 h-px bg-accent shadow-[0_0_18px_var(--color-accent)]" />
            </div>
            <p className="mt-4 text-center text-sm text-fg-muted">
              Leyendo comercio, total y fecha…
            </p>
          </div>
        ) : null}

        {step === "form" ? (
          <div className="mx-auto max-w-lg pt-2 fade-up">
            {hint ? (
              <p className="mb-4 rounded-md bg-surface px-3 py-2 text-sm text-fg-muted">{hint}</p>
            ) : null}
            <ExpenseForm
              cards={cards}
              currency={currency}
              draft={draft}
              onChange={setDraft}
              onSubmit={save}
              onCancel={resetAndClose}
              submitLabel={
                editing
                  ? "Guardar cambios"
                  : queue.length > 0
                    ? `Agregar y seguir (${queue.length} más)`
                    : "Agregar gasto"
              }
            />
            {editing ? (
              <button
                type="button"
                onClick={() => {
                  useStore.getState().deleteExpense(editing.id);
                  toast.success("Gasto eliminado");
                  resetAndClose();
                }}
                className="mt-3 w-full text-center text-sm text-danger"
              >
                Eliminar gasto
              </button>
            ) : (
              <GalleryLabel
                htmlFor={GALLERY_INPUT_ID}
                className="mt-4 block w-full text-center text-sm text-fg-muted underline-offset-4 hover:text-fg hover:underline"
              >
                Elegir otra foto de la galería
              </GalleryLabel>
            )}
          </div>
        ) : null}
      </div>
    </div>
  );
}
