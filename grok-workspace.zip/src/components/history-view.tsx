import { useMemo, useState, type ReactNode } from "react";
import { Search } from "lucide-react";
import { ExpenseRow } from "./expense-row";
import { Input } from "./ui/input";
import { chargesInCycle, cycleKeyOf } from "@/lib/cycle";
import { formatMoney } from "@/lib/format";
import { useStore } from "@/lib/store";
import type { CycleKey } from "@/lib/types";
import { cn } from "@/lib/utils";

export function HistoryView({
  cycle,
  onOpenExpense,
}: {
  cycle: CycleKey;
  onOpenExpense: (id: string) => void;
}) {
  const cards = useStore((s) => s.cards);
  const expenses = useStore((s) => s.expenses);
  const currency = useStore((s) => s.currency);
  const [q, setQ] = useState("");
  const [cardId, setCardId] = useState<string>("all");
  const [mode, setMode] = useState<"cycle" | "purchase">("cycle");

  const rows = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (mode === "cycle") {
      const list = cards
        .filter((c) => cardId === "all" || c.id === cardId)
        .flatMap((card) => chargesInCycle(expenses, card, cycle).map((charge) => ({ charge, card })))
        .filter(({ charge }) =>
          query ? charge.expense.merchant.toLowerCase().includes(query) : true,
        )
        .sort((a, b) => b.charge.expense.date.localeCompare(a.charge.expense.date));
      return list;
    }
    return expenses
      .filter((e) => (cardId === "all" ? true : e.cardId === cardId))
      .filter((e) => {
        const key = cards.find((c) => c.id === e.cardId);
        if (!key) return false;
        const ck = cycleKeyOf(key.closeDay, e.date);
        return ck.year === cycle.year && ck.month === cycle.month;
      })
      .filter((e) => (query ? e.merchant.toLowerCase().includes(query) : true))
      .sort((a, b) => b.date.localeCompare(a.date))
      .map((expense) => ({
        charge: {
          expense,
          installmentIndex: 0,
          amount: expense.amount,
          cycle,
        },
        card: cards.find((c) => c.id === expense.cardId)!,
      }))
      .filter((r) => r.card);
  }, [cards, expenses, cycle, cardId, q, mode]);

  const total = rows.reduce((s, r) => s + r.charge.amount, 0);

  return (
    <div className="flex flex-col gap-5 pb-8">
      <header>
        <p className="text-xs font-medium uppercase tracking-[0.16em] text-fg-subtle">Movimientos</p>
        <h1 className="font-display text-3xl font-medium tracking-tight">Historial</h1>
        <p className="mt-1 font-display text-xl tabular text-fg-muted">{formatMoney(total, currency)}</p>
      </header>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-fg-subtle" />
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar comercio"
          className="pl-9"
        />
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        <FilterChip on={mode === "cycle"} onClick={() => setMode("cycle")}>
          Por corte
        </FilterChip>
        <FilterChip on={mode === "purchase"} onClick={() => setMode("purchase")}>
          Por compra
        </FilterChip>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        <FilterChip on={cardId === "all"} onClick={() => setCardId("all")}>
          Todas
        </FilterChip>
        {cards.map((c) => (
          <FilterChip key={c.id} on={cardId === c.id} onClick={() => setCardId(c.id)}>
            {c.name}
          </FilterChip>
        ))}
      </div>

      {rows.length === 0 ? (
        <div className="rounded-xl bg-surface px-4 py-10 text-center text-sm text-fg-muted">
          Nada en este corte. Prueba otro mes o sube un ticket.
        </div>
      ) : (
        <ul className="divide-y divide-border">
          {rows.map(({ charge, card }) => (
            <li key={`${charge.expense.id}-${charge.installmentIndex}`}>
              <ExpenseRow
                expense={charge.expense}
                card={card}
                currency={currency}
                charge={charge}
                onClick={() => onOpenExpense(charge.expense.id)}
              />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function FilterChip({
  on,
  onClick,
  children,
}: {
  on: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-9 shrink-0 rounded-full px-3 text-xs font-medium",
        on ? "bg-accent text-accent-fg" : "bg-surface text-fg-muted",
      )}
    >
      {children}
    </button>
  );
}
