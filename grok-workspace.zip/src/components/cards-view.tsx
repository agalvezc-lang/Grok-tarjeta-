import { Plus } from "lucide-react";
import { PlasticCard } from "./plastic-card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import {
  availableCredit,
  buildCycle,
  currentCycleKey,
  cycleTotal,
  isPaid,
} from "@/lib/cycle";
import { daysUntil, formatMoney } from "@/lib/format";
import { useStore } from "@/lib/store";
import type { CycleKey } from "@/lib/types";

export function CardsView({
  cycle,
  onAdd,
  onOpen,
}: {
  cycle: CycleKey;
  onAdd: () => void;
  onOpen: (id: string) => void;
}) {
  const cards = useStore((s) => s.cards);
  const expenses = useStore((s) => s.expenses);
  const paid = useStore((s) => s.paid);
  const currency = useStore((s) => s.currency);
  const togglePaid = useStore((s) => s.togglePaid);

  return (
    <div className="flex flex-col gap-5 pb-8">
      <header className="flex items-end justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-fg-subtle">Plástico</p>
          <h1 className="font-display text-3xl font-medium tracking-tight">Tarjetas</h1>
        </div>
        <Button size="sm" onClick={onAdd}>
          <Plus className="size-4" />
          Nueva
        </Button>
      </header>

      {cards.length === 0 ? (
        <div className="rounded-xl bg-surface px-4 py-12 text-center">
          <p className="text-sm text-fg-muted">
            Agrega tu primera tarjeta: nombre, últimos 4, límite y día de corte.
          </p>
          <Button className="mt-4" onClick={onAdd}>
            Agregar tarjeta
          </Button>
        </div>
      ) : (
        <ul className="flex flex-col gap-5">
          {cards.map((card) => {
            const total = cycleTotal(expenses, card, cycle);
            const available = availableCredit(expenses, card, paid);
            const paidFlag = isPaid(paid, card.id, cycle);
            const built = buildCycle(card, cycle);
            const dueIn = daysUntil(built.due);
            const used = Math.min(1, Math.max(0, (card.limit - available) / card.limit || 0));
            return (
              <li key={card.id} className="rounded-xl bg-surface p-3">
                <button type="button" className="w-full text-left" onClick={() => onOpen(card.id)}>
                  <PlasticCard card={card} currency={currency} compact />
                </button>
                <div className="mt-3 flex items-center justify-between gap-3 px-1">
                  <div>
                    <p className="text-xs text-fg-muted">Este corte</p>
                    <p className="font-display text-xl tabular tracking-tight">
                      {formatMoney(total, currency)}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-fg-muted">Disponible</p>
                    <p className="tabular text-sm font-medium">{formatMoney(available, currency)}</p>
                  </div>
                </div>
                <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-bg">
                  <div
                    className="h-full rounded-full bg-accent"
                    style={{ width: `${Math.round(used * 100)}%` }}
                  />
                </div>
                <div className="mt-3 flex items-center justify-between px-1">
                  <p className="text-xs text-fg-muted">
                    Corte {card.closeDay} · Pago {card.dueDay}
                    {dueIn >= 0 ? ` · ${dueIn}d` : ""}
                  </p>
                  <button
                    type="button"
                    onClick={() => togglePaid(card.id, cycle.year, cycle.month)}
                  >
                    <Badge className={paidFlag ? "bg-ok/20 text-ok" : ""}>
                      {paidFlag ? "Pagado" : "Marcar pagado"}
                    </Badge>
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
