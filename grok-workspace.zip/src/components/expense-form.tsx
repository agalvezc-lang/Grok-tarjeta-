import { useMemo, useState } from "react";
import { Camera, ImageIcon } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { CAMERA_INPUT_ID, GALLERY_INPUT_ID, GalleryLabel } from "./gallery-capture";
import { CATEGORY_LIST } from "@/lib/categories";
import { formatMoney, parseAmount } from "@/lib/format";
import type { Card, CategoryId, Currency, Expense } from "@/lib/types";
import { cn, todayISO } from "@/lib/utils";
import { PlasticCard } from "./plastic-card";

export type ExpenseDraft = {
  cardId: string;
  merchant: string;
  amount: string;
  category: CategoryId;
  date: string;
  installments: number;
  note: string;
  receiptThumb?: string;
};

export function emptyDraft(cardId: string): ExpenseDraft {
  return {
    cardId,
    merchant: "",
    amount: "",
    category: "other",
    date: todayISO(),
    installments: 1,
    note: "",
  };
}

export function draftFromExpense(e: Expense): ExpenseDraft {
  return {
    cardId: e.cardId,
    merchant: e.merchant,
    amount: String(e.amount),
    category: e.category,
    date: e.date,
    installments: e.installments,
    note: e.note,
    receiptThumb: e.receiptThumb,
  };
}

export function ExpenseForm({
  cards,
  currency,
  draft,
  onChange,
  onSubmit,
  onCancel,
  submitLabel = "Guardar gasto",
  scanning = false,
}: {
  cards: Card[];
  currency: Currency;
  draft: ExpenseDraft;
  onChange: (d: ExpenseDraft) => void;
  onSubmit: () => void;
  onCancel: () => void;
  submitLabel?: string;
  scanning?: boolean;
}) {
  const [amountError, setAmountError] = useState(false);
  const parsed = parseAmount(draft.amount);
  const card = cards.find((c) => c.id === draft.cardId) ?? cards[0];
  const per = useMemo(() => {
    if (parsed == null || draft.installments <= 1) return null;
    return parsed / draft.installments;
  }, [parsed, draft.installments]);

  function submit() {
    if (parsed == null || parsed <= 0 || !draft.merchant.trim() || !draft.cardId) {
      setAmountError(parsed == null || parsed <= 0);
      return;
    }
    onSubmit();
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center gap-3 rounded-lg bg-surface p-2">
        {draft.receiptThumb ? (
          <img
            src={draft.receiptThumb}
            alt="Ticket adjunto"
            className="size-16 shrink-0 rounded-md object-cover outline outline-1 -outline-offset-1 outline-fg/10"
          />
        ) : (
          <span className="flex size-16 shrink-0 items-center justify-center rounded-md bg-surface-2 text-fg-muted">
            <ImageIcon className="size-5" />
          </span>
        )}
        <div className="min-w-0 flex-1">
          <GalleryLabel
            htmlFor={GALLERY_INPUT_ID}
            className="block text-sm font-medium text-fg underline-offset-4 hover:underline"
          >
            {draft.receiptThumb ? "Cambiar foto de la galería" : "Adjuntar foto de la galería"}
          </GalleryLabel>
          <GalleryLabel
            htmlFor={CAMERA_INPUT_ID}
            className="mt-1 inline-flex items-center gap-1 text-xs text-fg-muted hover:text-fg"
          >
            <Camera className="size-3.5" />
            O tomar foto
          </GalleryLabel>
        </div>
      </div>

      {card ? (
        <PlasticCard card={card} currency={currency} compact className="max-h-28" />
      ) : null}

      <div className="grid gap-2">
        <Label>Tarjeta</Label>
        <div className="flex gap-2 overflow-x-auto pb-1">
          {cards.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => onChange({ ...draft, cardId: c.id })}
              className={cn(
                "shrink-0 rounded-md px-3 py-2 text-left text-sm shadow-[var(--shadow-border)]",
                draft.cardId === c.id ? "bg-accent text-accent-fg" : "bg-surface text-fg",
              )}
            >
              <span className="block font-medium">{c.name}</span>
              <span className="block text-xs opacity-70">•••• {c.last4}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-2">
        <Label htmlFor="merchant">Comercio</Label>
        <Input
          id="merchant"
          value={draft.merchant}
          onChange={(e) => onChange({ ...draft, merchant: e.target.value })}
          placeholder="Oxxo, CFE, Liverpool…"
          autoComplete="off"
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="grid gap-2">
          <Label htmlFor="amount">Monto</Label>
          <Input
            id="amount"
            inputMode="decimal"
            value={draft.amount}
            onChange={(e) => {
              setAmountError(false);
              onChange({ ...draft, amount: e.target.value });
            }}
            placeholder="0.00"
            className={cn("tabular", amountError && "ring-2 ring-danger")}
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="date">Fecha</Label>
          <Input
            id="date"
            type="date"
            value={draft.date}
            onChange={(e) => onChange({ ...draft, date: e.target.value })}
          />
        </div>
      </div>

      <div className="grid gap-2">
        <Label>Categoría</Label>
        <div className="flex flex-wrap gap-2">
          {CATEGORY_LIST.map((cat) => {
            const Icon = cat.icon;
            const on = draft.category === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => onChange({ ...draft, category: cat.id })}
                className={cn(
                  "inline-flex h-9 items-center gap-1.5 rounded-full px-3 text-xs font-medium",
                  on ? "bg-accent text-accent-fg" : "bg-surface text-fg-muted",
                )}
              >
                <Icon className="size-3.5" />
                {cat.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid gap-2">
        <div className="flex items-center justify-between">
          <Label htmlFor="cuotas">Meses</Label>
          {per != null && parsed != null ? (
            <span className="text-xs text-fg-muted tabular">
              {draft.installments} × {formatMoney(per, currency)}
            </span>
          ) : null}
        </div>
        <input
          id="cuotas"
          type="range"
          min={1}
          max={24}
          value={draft.installments}
          onChange={(e) => onChange({ ...draft, installments: Number(e.target.value) })}
          className="h-11 w-full accent-accent"
        />
        <div className="flex justify-between text-xs text-fg-subtle">
          <span>1 pago</span>
          <span className="tabular">
            {draft.installments} {draft.installments === 1 ? "mes" : "meses"}
          </span>
          <span>24</span>
        </div>
      </div>

      <div className="grid gap-2">
        <Label htmlFor="note">Nota</Label>
        <Textarea
          id="note"
          value={draft.note}
          onChange={(e) => onChange({ ...draft, note: e.target.value })}
          placeholder="Folio, MSI, quién pagó…"
          rows={2}
        />
      </div>

      <div className="flex gap-2 pt-1">
        <Button variant="ghost" className="flex-1" type="button" onClick={onCancel}>
          Cancelar
        </Button>
        <Button className="flex-1" type="button" onClick={submit} disabled={scanning || cards.length === 0}>
          {submitLabel}
        </Button>
      </div>
    </div>
  );
}
