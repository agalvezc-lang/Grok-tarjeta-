import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { PlasticCard } from "./plastic-card";
import { BRAND_LABEL } from "./network-mark";
import { CARD_BRANDS, CARD_COLORS, type Card, type CardBrand, type CardColor, type Currency } from "@/lib/types";
import { cn } from "@/lib/utils";
import { parseAmount } from "@/lib/format";
import { X } from "lucide-react";

const COLOR_DOT: Record<CardColor, string> = {
  navy: "bg-card-navy",
  wine: "bg-card-wine",
  forest: "bg-card-forest",
  ink: "bg-card-ink",
  slate: "bg-card-slate",
  rust: "bg-card-rust",
  ocean: "bg-card-ocean",
  plum: "bg-card-plum",
};

type Draft = {
  name: string;
  last4: string;
  brand: CardBrand;
  color: CardColor;
  limit: string;
  closeDay: string;
  dueDay: string;
};

function fromCard(card?: Card | null): Draft {
  return {
    name: card?.name ?? "",
    last4: card?.last4 ?? "",
    brand: card?.brand ?? "visa",
    color: card?.color ?? "navy",
    limit: card ? String(card.limit) : "",
    closeDay: String(card?.closeDay ?? 12),
    dueDay: String(card?.dueDay ?? 20),
  };
}

export function CardEditor({
  open,
  card,
  currency,
  onClose,
  onSave,
  onDelete,
}: {
  open: boolean;
  card?: Card | null;
  currency: Currency;
  onClose: () => void;
  onSave: (data: Omit<Card, "id" | "createdAt">) => void;
  onDelete?: () => void;
}) {
  const [draft, setDraft] = useState<Draft>(fromCard(card));

  if (!open) return null;

  const preview: Card = {
    id: card?.id ?? "preview",
    name: draft.name || "Nueva tarjeta",
    last4: draft.last4.replace(/\D/g, "").slice(0, 4).padStart(4, "0"),
    brand: draft.brand,
    color: draft.color,
    limit: parseAmount(draft.limit) ?? 0,
    closeDay: Number(draft.closeDay) || 1,
    dueDay: Number(draft.dueDay) || 1,
    createdAt: card?.createdAt ?? "",
  };

  function save() {
    const last4 = draft.last4.replace(/\D/g, "").slice(-4);
    const limit = parseAmount(draft.limit);
    const closeDay = Math.min(28, Math.max(1, Number(draft.closeDay) || 1));
    const dueDay = Math.min(28, Math.max(1, Number(draft.dueDay) || 1));
    if (!draft.name.trim() || last4.length !== 4 || limit == null || limit <= 0) return;
    onSave({
      name: draft.name.trim(),
      last4,
      brand: draft.brand,
      color: draft.color,
      limit,
      closeDay,
      dueDay,
    });
  }

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-bg">
      <header className="flex items-center justify-between px-4 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-fg-subtle">
            {card ? "Editar" : "Nueva"}
          </p>
          <h2 className="font-display text-2xl font-medium tracking-tight">Tarjeta</h2>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} aria-label="Cerrar">
          <X className="size-5" />
        </Button>
      </header>
      <div className="mx-auto flex w-full max-w-lg flex-1 flex-col gap-5 overflow-y-auto px-4 pb-8">
        <PlasticCard card={preview} currency={currency} />

        <div className="grid gap-2">
          <Label htmlFor="card-name">Nombre</Label>
          <Input
            id="card-name"
            value={draft.name}
            onChange={(e) => setDraft({ ...draft, name: e.target.value })}
            placeholder="Nu, BBVA Azul…"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="grid gap-2">
            <Label htmlFor="last4">Últimos 4</Label>
            <Input
              id="last4"
              inputMode="numeric"
              maxLength={4}
              value={draft.last4}
              onChange={(e) => setDraft({ ...draft, last4: e.target.value.replace(/\D/g, "").slice(0, 4) })}
              placeholder="4412"
              className="font-mono tracking-[0.2em]"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="limit">Límite</Label>
            <Input
              id="limit"
              inputMode="decimal"
              value={draft.limit}
              onChange={(e) => setDraft({ ...draft, limit: e.target.value })}
              placeholder="35000"
              className="tabular"
            />
          </div>
        </div>

        <div className="grid gap-2">
          <Label>Red</Label>
          <div className="flex flex-wrap gap-2">
            {CARD_BRANDS.map((b) => (
              <button
                key={b}
                type="button"
                onClick={() => setDraft({ ...draft, brand: b })}
                className={cn(
                  "h-9 rounded-full px-3 text-xs font-medium",
                  draft.brand === b ? "bg-accent text-accent-fg" : "bg-surface text-fg-muted",
                )}
              >
                {BRAND_LABEL[b]}
              </button>
            ))}
          </div>
        </div>

        <div className="grid gap-2">
          <Label>Color</Label>
          <div className="flex flex-wrap gap-2">
            {CARD_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                aria-label={c}
                onClick={() => setDraft({ ...draft, color: c })}
                className={cn(
                  "size-9 rounded-full shadow-[var(--shadow-border)]",
                  COLOR_DOT[c],
                  draft.color === c && "ring-2 ring-accent ring-offset-2 ring-offset-bg",
                )}
              />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="grid gap-2">
            <Label htmlFor="close">Día de corte</Label>
            <Input
              id="close"
              inputMode="numeric"
              value={draft.closeDay}
              onChange={(e) => setDraft({ ...draft, closeDay: e.target.value.replace(/\D/g, "").slice(0, 2) })}
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="due">Día de pago</Label>
            <Input
              id="due"
              inputMode="numeric"
              value={draft.dueDay}
              onChange={(e) => setDraft({ ...draft, dueDay: e.target.value.replace(/\D/g, "").slice(0, 2) })}
            />
          </div>
        </div>

        <div className="mt-auto flex flex-col gap-2 pt-4">
          <Button onClick={save}>{card ? "Guardar tarjeta" : "Agregar tarjeta"}</Button>
          {card && onDelete ? (
            <Button variant="ghost" className="text-danger" onClick={onDelete}>
              Eliminar tarjeta
            </Button>
          ) : (
            <Button variant="ghost" onClick={onClose}>
              Cancelar
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
