import type { LabelHTMLAttributes } from "react";
import { IMAGE_ACCEPT } from "@/lib/image";
import { cn } from "@/lib/utils";

export const GALLERY_INPUT_ID = "gastos-gallery-input";
export const CAMERA_INPUT_ID = "gastos-camera-input";

export function GalleryFileInputs({
  onFiles,
}: {
  onFiles: (files: File[], source: "gallery" | "camera") => void;
}) {
  return (
    <>
      <input
        id={GALLERY_INPUT_ID}
        type="file"
        accept={IMAGE_ACCEPT}
        multiple
        className="sr-only"
        tabIndex={-1}
        aria-hidden
        onChange={(e) => {
          const files = Array.from(e.currentTarget.files ?? []);
          e.currentTarget.value = "";
          if (files.length) onFiles(files, "gallery");
        }}
      />
      <input
        id={CAMERA_INPUT_ID}
        type="file"
        accept="image/*"
        capture="environment"
        className="sr-only"
        tabIndex={-1}
        aria-hidden
        onChange={(e) => {
          const files = Array.from(e.currentTarget.files ?? []);
          e.currentTarget.value = "";
          if (files.length) onFiles(files, "camera");
        }}
      />
    </>
  );
}

export function GalleryLabel({
  htmlFor = GALLERY_INPUT_ID,
  className,
  children,
  ...props
}: LabelHTMLAttributes<HTMLLabelElement>) {
  return (
    <label htmlFor={htmlFor} className={cn("cursor-pointer", className)} {...props}>
      {children}
    </label>
  );
}
