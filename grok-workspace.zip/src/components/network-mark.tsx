import type { CardBrand } from "@/lib/types";

export function NetworkMark({ brand, className }: { brand: CardBrand; className?: string }) {
  if (brand === "visa") {
    return (
      <svg viewBox="0 0 60 20" className={className} aria-hidden>
        <text
          x="60"
          y="16"
          textAnchor="end"
          fill="currentColor"
          fontSize="16"
          fontWeight="700"
          fontFamily="var(--font-sans)"
          letterSpacing="1"
        >
          VISA
        </text>
      </svg>
    );
  }
  if (brand === "mastercard") {
    return (
      <svg viewBox="0 0 48 28" className={className} aria-hidden>
        <circle cx="18" cy="14" r="12" fill="currentColor" opacity="0.55" />
        <circle cx="30" cy="14" r="12" fill="currentColor" opacity="0.9" />
      </svg>
    );
  }
  if (brand === "amex") {
    return (
      <svg viewBox="0 0 72 20" className={className} aria-hidden>
        <text
          x="72"
          y="16"
          textAnchor="end"
          fill="currentColor"
          fontSize="13"
          fontWeight="700"
          fontFamily="var(--font-sans)"
          letterSpacing="0.5"
        >
          AMEX
        </text>
      </svg>
    );
  }
  if (brand === "carnet") {
    return (
      <svg viewBox="0 0 80 20" className={className} aria-hidden>
        <text
          x="80"
          y="16"
          textAnchor="end"
          fill="currentColor"
          fontSize="13"
          fontWeight="600"
          fontFamily="var(--font-sans)"
          letterSpacing="0.8"
        >
          CARNET
        </text>
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 28 20" className={className} aria-hidden>
      <rect x="1" y="3" width="26" height="14" rx="3" fill="none" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  );
}

export const BRAND_LABEL: Record<CardBrand, string> = {
  visa: "Visa",
  mastercard: "Mastercard",
  amex: "American Express",
  carnet: "Carnet",
  other: "Otra",
};
