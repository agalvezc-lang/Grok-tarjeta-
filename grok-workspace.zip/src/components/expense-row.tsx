import { CATEGORY_META } from "@/lib/categories";
import { formatDayMonth, formatMoney } from "@/lib/format";
import type { Card, Charge, Currency, Expense } from "@/lib/types";
import { cn } from "@/lib/utils";

export function ExpenseRow({
  expense,
  card,
  currency,
  charge,
  onClick,
}: {
  expense: Expense;
  card?: Card;
  currency: Currency;
  charge?: Charge;
  onClick?: () => void;
}) {
  const meta = CATEGORY_META[expense.category];
  const Icon = meta.icon;
  const amount = charge?.amount ?? expense.amount;
  const installmentLabel =
    expense.installments > 1
      ? `${(charge?.installmentIndex ?? 0) + 1}/${expense.installments}`
      : null;

  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-3 rounded-lg px-1 py-2.5 text-left transition-colors duration-150 hover:bg-surface",
      )}
    >
      {expense.receiptThumb ? (
        <img
          src={expense.receiptThumb}
          alt=""
          className="size-10 shrink-0 rounded-md object-cover outline outline-1 -outline-offset-1 outline-fg/10"
        />
      ) : (
        <span className="flex size-10 shrink-0 items-center justify-center rounded-md bg-surface-2 text-fg-muted">
          <Icon className="size-4" />
        </span>
      )}
      <span className="min-w-0 flex-1">
        <span className="flex items-baseline justify-between gap-3">
          <span className="truncate text-sm font-medium">{expense.merchant}</span>
          <span className="shrink-0 font-display text-base tabular tracking-tight">
            {formatMoney(amount, currency)}
          </span>
        </span>
        <span className="mt-0.5 flex items-center gap-2 text-xs text-fg-muted">
          <span>{formatDayMonth(expense.date)}</span>
          {card ? <span>· {card.name}</span> : null}
          {installmentLabel ? <span>· {installmentLabel}</span> : null}
        </span>
      </span>
    </button>
  );
}
