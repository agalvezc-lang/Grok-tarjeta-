import { NetworkMark } from "./network-mark";
import type { Card } from "@/lib/types";
import { cn } from "@/lib/utils";
import { formatMoney } from "@/lib/format";
import type { Currency } from "@/lib/types";

const COLOR_CLASS: Record<Card["color"], string> = {
  navy: "bg-card-navy",
  wine: "bg-card-wine",
  forest: "bg-card-forest",
  ink: "bg-card-ink",
  slate: "bg-card-slate",
  rust: "bg-card-rust",
  ocean: "bg-card-ocean",
  plum: "bg-card-plum",
};

export function PlasticCard({
  card,
  subtitle,
  amount,
  currency,
  compact = false,
  className,
}: {
  card: Card;
  subtitle?: string;
  amount?: number;
  currency: Currency;
  compact?: boolean;
  className?: string;
}) {
  return (
    <article
      className={cn(
        "relative overflow-hidden rounded-xl text-fg",
        COLOR_CLASS[card.color],
        compact ? "aspect-[1.7/1] p-4" : "aspect-[1.62/1] p-5",
        className,
      )}
    >
      <div className="pointer-events-none absolute -right-8 -top-10 size-40 rounded-full bg-fg/8" />
      <div className="pointer-events-none absolute -bottom-12 left-16 size-36 rounded-full bg-bg/20" />
      <div className="relative flex h-full flex-col justify-between">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-medium tracking-wide text-fg/70">{card.name}</p>
            <p className="mt-1 font-mono text-sm tracking-[0.18em] text-fg/90">
              •••• {card.last4}
            </p>
          </div>
          <NetworkMark brand={card.brand} className="h-6 w-12 text-fg/85" />
        </div>
        <div className="flex items-end justify-between">
          <div className="flex items-center gap-3">
            <span className="block h-7 w-9 rounded-sm bg-chip/90 shadow-inner" />
            {subtitle ? (
              <span className="text-xs text-fg/70">{subtitle}</span>
            ) : null}
          </div>
          {typeof amount === "number" ? (
            <p className="font-display text-lg font-medium tabular leading-none tracking-tight">
              {formatMoney(amount, currency)}
            </p>
          ) : null}
        </div>
      </div>
    </article>
  );
}
