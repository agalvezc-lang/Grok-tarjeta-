import { useCallback, useEffect, useMemo, useState } from "react";
import { BarChart3, CreditCard, Home, ImageIcon, Receipt } from "lucide-react";
import { Toaster } from "sonner";
import { HomeView } from "./home-view";
import { CardsView } from "./cards-view";
import { HistoryView } from "./history-view";
import { InsightsView } from "./insights-view";
import { AddExpense } from "./add-expense";
import { CardEditor } from "./card-editor";
import { GALLERY_INPUT_ID, GalleryFileInputs, GalleryLabel } from "./gallery-capture";
import { filesFromList, isSupportedImage } from "@/lib/image";
import { useStore, type TabId } from "@/lib/store";
import { currentCycleKey } from "@/lib/cycle";
import { cn } from "@/lib/utils";
import type { CycleKey, Expense } from "@/lib/types";

export function AppShell() {
  const hydrated = useStore((s) => s.hydrated);
  const setHydrated = useStore((s) => s.setHydrated);
  const tab = useStore((s) => s.tab);
  const setTab = useStore((s) => s.setTab);
  const cards = useStore((s) => s.cards);
  const expenses = useStore((s) => s.expenses);
  const currency = useStore((s) => s.currency);
  const addCard = useStore((s) => s.addCard);
  const updateCard = useStore((s) => s.updateCard);
  const deleteCard = useStore((s) => s.deleteCard);

  const [cycle, setCycle] = useState<CycleKey>(() => {
    const first = useStore.getState().cards[0];
    if (first) return currentCycleKey(first);
    const n = new Date();
    return { year: n.getFullYear(), month: n.getMonth() };
  });
  const [addOpen, setAddOpen] = useState(false);
  const [addMode, setAddMode] = useState<"pick" | "manual">("pick");
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [incomingFiles, setIncomingFiles] = useState<File[] | undefined>(undefined);
  const [cardOpen, setCardOpen] = useState(false);
  const [editingCardId, setEditingCardId] = useState<string | null>(null);
  const [dropOver, setDropOver] = useState(false);

  const onGalleryFiles = useCallback((files: File[]) => {
    const images = files.filter(isSupportedImage);
    if (!images.length) return;
    setAddOpen((wasOpen) => {
      if (!wasOpen) {
        setEditingExpense(null);
        setAddMode("pick");
      }
      return true;
    });
    setIncomingFiles(images);
  }, []);

  useEffect(() => {
    const unsub = useStore.persist.onFinishHydration(() => setHydrated(true));
    if (useStore.persist.hasHydrated()) setHydrated(true);
    return unsub;
  }, [setHydrated]);

  useEffect(() => {
    if (!hydrated) return;
    if (cards[0]) setCycle(currentCycleKey(cards[0]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated]);

  useEffect(() => {
    function onPaste(e: ClipboardEvent) {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) {
        const items = e.clipboardData?.files;
        if (!items?.length) return;
      }
      const files = filesFromList(e.clipboardData?.files ?? null);
      if (!files.length && e.clipboardData) {
        for (const item of Array.from(e.clipboardData.items ?? [])) {
          if (item.type.startsWith("image/")) {
            const file = item.getAsFile();
            if (file) files.push(file);
          }
        }
      }
      if (!files.length) return;
      e.preventDefault();
      onGalleryFiles(files);
    }
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, [onGalleryFiles]);

  useEffect(() => {
    function hasFiles(e: DragEvent) {
      return Array.from(e.dataTransfer?.types ?? []).includes("Files");
    }
    function onDragOver(e: DragEvent) {
      if (!hasFiles(e)) return;
      e.preventDefault();
      setDropOver(true);
    }
    function onDragLeave(e: DragEvent) {
      if (e.relatedTarget == null) setDropOver(false);
    }
    function onDrop(e: DragEvent) {
      e.preventDefault();
      setDropOver(false);
      const files = filesFromList(e.dataTransfer?.files ?? null);
      if (files.length) onGalleryFiles(files);
    }
    window.addEventListener("dragover", onDragOver);
    window.addEventListener("dragleave", onDragLeave);
    window.addEventListener("drop", onDrop);
    return () => {
      window.removeEventListener("dragover", onDragOver);
      window.removeEventListener("dragleave", onDragLeave);
      window.removeEventListener("drop", onDrop);
    };
  }, [onGalleryFiles]);

  const editingCard = useMemo(
    () => cards.find((c) => c.id === editingCardId) ?? null,
    [cards, editingCardId],
  );

  function openManual() {
    setEditingExpense(null);
    setIncomingFiles(undefined);
    setAddMode("manual");
    setAddOpen(true);
  }

  return (
    <div className="mx-auto min-h-dvh max-w-lg bg-bg">
      <GalleryFileInputs onFiles={(files) => onGalleryFiles(files)} />

      <main className="px-4 pb-28 pt-[max(1rem,env(safe-area-inset-top))]">
        {tab === "home" ? (
          <HomeView
            cycle={cycle}
            onCycle={setCycle}
            onAdd={openManual}
            onDemoTicket={() => {
              void (async () => {
                try {
                  const res = await fetch("/demo-ticket.png");
                  const blob = await res.blob();
                  const file = new File([blob], "ticket.png", { type: "image/png" });
                  onGalleryFiles([file]);
                } catch {
                  /* ignore */
                }
              })();
            }}
            onOpenExpense={(id) => {
              const e = expenses.find((x) => x.id === id);
              if (!e) return;
              setIncomingFiles(undefined);
              setEditingExpense(e);
              setAddOpen(true);
            }}
            onOpenCard={(id) => {
              setEditingCardId(id);
              setCardOpen(true);
            }}
          />
        ) : null}
        {tab === "cards" ? (
          <CardsView
            cycle={cycle}
            onAdd={() => {
              setEditingCardId(null);
              setCardOpen(true);
            }}
            onOpen={(id) => {
              setEditingCardId(id);
              setCardOpen(true);
            }}
          />
        ) : null}
        {tab === "history" ? (
          <HistoryView
            cycle={cycle}
            onOpenExpense={(id) => {
              const e = expenses.find((x) => x.id === id);
              if (!e) return;
              setIncomingFiles(undefined);
              setEditingExpense(e);
              setAddOpen(true);
            }}
          />
        ) : null}
        {tab === "insights" ? <InsightsView cycle={cycle} /> : null}
      </main>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md">
        <div className="mx-auto flex max-w-lg items-end justify-around px-2 pt-2">
          <NavBtn id="home" tab={tab} onClick={setTab} label="Inicio" icon={Home} />
          <NavBtn id="cards" tab={tab} onClick={setTab} label="Tarjetas" icon={CreditCard} />
          <GalleryLabel
            htmlFor={GALLERY_INPUT_ID}
            className="-mt-5 flex size-14 items-center justify-center rounded-full bg-accent text-accent-fg shadow-[var(--shadow-lift)]"
            aria-label="Agregar gasto desde galería"
          >
            <ImageIcon className="size-6" />
          </GalleryLabel>
          <NavBtn id="history" tab={tab} onClick={setTab} label="Historial" icon={Receipt} />
          <NavBtn id="insights" tab={tab} onClick={setTab} label="Análisis" icon={BarChart3} />
        </div>
      </nav>

      <AddExpense
        key={editingExpense?.id ?? (addOpen ? "new" : "idle")}
        open={addOpen}
        editing={editingExpense}
        forceManual={addMode === "manual" && !editingExpense}
        incomingFiles={incomingFiles}
        onConsumedIncoming={() => setIncomingFiles(undefined)}
        onClose={() => {
          setAddOpen(false);
          setEditingExpense(null);
          setIncomingFiles(undefined);
        }}
      />

      {cardOpen ? (
        <CardEditor
          key={editingCardId ?? "new-card"}
          open
          card={editingCard}
          currency={currency}
          onClose={() => setCardOpen(false)}
          onSave={(data) => {
            if (editingCard) updateCard(editingCard.id, data);
            else addCard(data);
            setCardOpen(false);
          }}
          onDelete={
            editingCard
              ? () => {
                  deleteCard(editingCard.id);
                  setCardOpen(false);
                }
              : undefined
          }
        />
      ) : null}

      {dropOver ? (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-bg/80 px-8 text-center">
          <div className="rounded-xl bg-surface px-8 py-10 shadow-[var(--shadow-lift)]">
            <ImageIcon className="mx-auto size-8 text-accent" />
            <p className="mt-3 font-display text-xl">Suelta el ticket</p>
            <p className="mt-1 text-sm text-fg-muted">Se abre como un gasto nuevo, con la foto adjunta.</p>
          </div>
        </div>
      ) : null}

      <Toaster theme="dark" position="top-center" />
    </div>
  );
}

function NavBtn({
  id,
  tab,
  onClick,
  label,
  icon: Icon,
}: {
  id: TabId;
  tab: TabId;
  onClick: (id: TabId) => void;
  label: string;
  icon: typeof Home;
}) {
  const on = tab === id;
  return (
    <button
      type="button"
      onClick={() => onClick(id)}
      className={cn(
        "flex min-w-14 flex-col items-center gap-1 py-1 text-[11px] font-medium",
        on ? "text-fg" : "text-fg-subtle",
      )}
    >
      <Icon className="size-5" />
      {label}
    </button>
  );
}
