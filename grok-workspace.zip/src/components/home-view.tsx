import { ChevronLeft, ChevronRight, ImageIcon, Plus } from "lucide-react";
import { PlasticCard } from "./plastic-card";
import { ExpenseRow } from "./expense-row";
import { Button } from "./ui/button";
import { GALLERY_INPUT_ID, GalleryLabel } from "./gallery-capture";
import {
  availableCredit,
  buildCycle,
  cycleTotal,
  isPaid,
} from "@/lib/cycle";
import { daysUntil, formatMoney, formatMonthTitle } from "@/lib/format";
import { addMonths } from "@/lib/utils";
import type { CycleKey } from "@/lib/types";
import { useStore } from "@/lib/store";
import { Badge } from "./ui/badge";

export function HomeView({
  onAdd,
  onDemoTicket,
  onOpenExpense,
  onOpenCard,
  cycle,
  onCycle,
}: {
  onAdd: () => void;
  onDemoTicket: () => void;
  onOpenExpense: (id: string) => void;
  onOpenCard: (id: string) => void;
  cycle: CycleKey;
  onCycle: (key: CycleKey) => void;
}) {
  const cards = useStore((s) => s.cards);
  const expenses = useStore((s) => s.expenses);
  const paid = useStore((s) => s.paid);
  const currency = useStore((s) => s.currency);

  const totals = cards.map((card) => ({
    card,
    total: cycleTotal(expenses, card, cycle),
    available: availableCredit(expenses, card, paid),
    paid: isPaid(paid, card.id, cycle),
    due: buildCycle(card, cycle).due,
  }));
  const grand = totals.reduce((s, t) => s + t.total, 0);
  const nearestDue = totals
    .map((t) => t.due)
    .sort((a, b) => a.getTime() - b.getTime())[0];
  const dueIn = nearestDue ? daysUntil(nearestDue) : null;

  const recent = [...expenses]
    .sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt))
    .slice(0, 8);

  const withPhotos = expenses.filter((e) => e.receiptThumb).slice(0, 10);

  return (
    <div className="flex flex-col gap-6 pb-8">
      <header className="flex items-end justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.16em] text-fg-subtle">Este corte</p>
          <h1 className="font-display text-3xl font-medium tracking-tight capitalize">
            {formatMonthTitle(cycle.year, cycle.month)}
          </h1>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="size-10"
            aria-label="Mes anterior"
            onClick={() => onCycle(addMonths(cycle.year, cycle.month, -1))}
          >
            <ChevronLeft className="size-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="size-10"
            aria-label="Mes siguiente"
            onClick={() => onCycle(addMonths(cycle.year, cycle.month, 1))}
          >
            <ChevronRight className="size-5" />
          </Button>
        </div>
      </header>

      <section className="rounded-xl bg-surface p-5 lift">
        <p className="text-xs font-medium uppercase tracking-[0.14em] text-fg-subtle">A pagar</p>
        <p className="mt-2 font-display text-4xl font-medium tabular tracking-tight">
          {formatMoney(grand, currency)}
        </p>
        <p className="mt-2 text-sm text-fg-muted">
          {dueIn == null
            ? "Agrega una tarjeta para ver el vencimiento"
            : dueIn < 0
              ? `Venció hace ${Math.abs(dueIn)} días`
              : dueIn === 0
                ? "Vence hoy"
                : `Próximo pago en ${dueIn} días`}
        </p>
        <div className="mt-5 grid grid-cols-2 gap-2">
          <Button asChild className="h-12">
            <GalleryLabel
              htmlFor={GALLERY_INPUT_ID}
              className="inline-flex h-12 items-center justify-center gap-2"
            >
              <ImageIcon className="size-4" />
              Desde galería
            </GalleryLabel>
          </Button>
          <Button variant="secondary" onClick={onAdd} className="h-12">
            <Plus className="size-4" />
            Manual
          </Button>
        </div>
        <button
          type="button"
          onClick={onDemoTicket}
          className="mt-3 w-full text-center text-xs text-fg-muted underline-offset-4 hover:text-fg hover:underline"
        >
          Probar con un ticket de ejemplo
        </button>
      </section>

      <section className="-mx-4">
        <div className="flex items-center justify-between px-4">
          <h2 className="text-sm font-medium">Tickets</h2>
        </div>
        <div className="mt-3 flex snap-x gap-2 overflow-x-auto px-4 pb-1">
          <GalleryLabel
            htmlFor={GALLERY_INPUT_ID}
            className="flex size-20 shrink-0 snap-start flex-col items-center justify-center gap-1 rounded-lg bg-surface text-fg-muted shadow-[var(--shadow-border)]"
          >
            <ImageIcon className="size-5" />
            <span className="text-[10px] font-medium">Añadir</span>
          </GalleryLabel>
          {withPhotos.map((e) => (
            <button
              key={e.id}
              type="button"
              onClick={() => onOpenExpense(e.id)}
              className="size-20 shrink-0 snap-start overflow-hidden rounded-lg"
              aria-label={`Ticket de ${e.merchant}`}
            >
              <img src={e.receiptThumb} alt="" className="size-full object-cover" />
            </button>
          ))}
        </div>
      </section>

      <section className="-mx-4">
        <div className="flex items-center justify-between px-4">
          <h2 className="text-sm font-medium">Tarjetas</h2>
        </div>
        {cards.length === 0 ? (
          <p className="px-4 pt-4 text-sm text-fg-muted">Aún no hay tarjetas.</p>
        ) : (
          <div className="mt-3 flex snap-x gap-3 overflow-x-auto px-4 pb-2">
            {totals.map(({ card, total, available, paid: paidFlag }) => (
              <button
                key={card.id}
                type="button"
                onClick={() => onOpenCard(card.id)}
                className="w-[min(78vw,22rem)] shrink-0 snap-start text-left"
              >
                <PlasticCard
                  card={card}
                  currency={currency}
                  amount={total}
                  subtitle={paidFlag ? "Pagado" : `Disp. ${formatMoney(available, currency)}`}
                />
              </button>
            ))}
          </div>
        )}
      </section>

      <section>
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-sm font-medium">Gastos recientes</h2>
          {recent.length > 0 ? <Badge>{recent.length} últimos</Badge> : null}
        </div>
        {recent.length === 0 ? (
          <EmptyRecent onDemoTicket={onDemoTicket} />
        ) : (
          <ul className="divide-y divide-border">
            {recent.map((e) => (
              <li key={e.id}>
                <ExpenseRow
                  expense={e}
                  card={cards.find((c) => c.id === e.cardId)}
                  currency={currency}
                  onClick={() => onOpenExpense(e.id)}
                />
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function EmptyRecent({ onDemoTicket }: { onDemoTicket: () => void }) {
  return (
    <div className="rounded-xl bg-surface px-4 py-10 text-center">
      <p className="text-sm text-fg-muted">
        Todavía no hay movimientos. Elige un ticket de la galería.
      </p>
      <Button asChild className="mt-4">
        <GalleryLabel
          htmlFor={GALLERY_INPUT_ID}
          className="inline-flex h-11 items-center justify-center gap-2 px-4"
        >
          <ImageIcon className="size-4" />
          Leer ticket
        </GalleryLabel>
      </Button>
      <button
        type="button"
        onClick={onDemoTicket}
        className="mt-3 block w-full text-xs text-fg-muted underline-offset-4 hover:text-fg hover:underline"
      >
        Probar con un ticket de ejemplo
      </button>
    </div>
  );
}
