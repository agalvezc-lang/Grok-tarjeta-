//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BWvKiLaK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CH9CrLBv.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CH9CrLBv.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-ByY5z0WK.js"]
	}
} });
//#endregion
export { tsrStartManifest };
