//#region node_modules/.nitro/vite/services/ssr/assets/types-BDEBqRxR.js
var CARD_COLORS = [
	"navy",
	"wine",
	"forest",
	"ink",
	"slate",
	"rust",
	"ocean",
	"plum"
];
var CARD_BRANDS = [
	"visa",
	"mastercard",
	"amex",
	"carnet",
	"other"
];
var CATEGORIES = [
	"food",
	"groceries",
	"transport",
	"home",
	"health",
	"entertainment",
	"shopping",
	"subscriptions",
	"travel",
	"services",
	"other"
];
var CURRENCIES = [
	"MXN",
	"USD",
	"EUR",
	"COP",
	"ARS",
	"CLP",
	"PEN"
];
//#endregion
export { CURRENCIES as i, CARD_COLORS as n, CATEGORIES as r, CARD_BRANDS as t };
