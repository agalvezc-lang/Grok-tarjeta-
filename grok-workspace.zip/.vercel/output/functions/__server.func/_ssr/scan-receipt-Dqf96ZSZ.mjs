import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { r as CATEGORIES } from "./types-BDEBqRxR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scan-receipt-Dqf96ZSZ.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var SYSTEM = `Eres un extractor de tickets, recibos y estados de cuenta de tarjetas en México, España y LatAm.
Devuelve SOLO un objeto JSON válido, sin markdown, con esta forma:
{
  "merchant": string,
  "amount": number | null,
  "date": "YYYY-MM-DD" | null,
  "category": string,
  "installments": number | null,
  "note": string,
  "confidence": number
}
Reglas:
- amount es SIEMPRE la línea TOTAL / GRAN TOTAL / IMPORTE / A PAGAR. Nunca el SUBTOTAL ni el IVA suelto. Número con punto decimal.
- merchant es el comercio corto (ej. "Oxxo", "CFE", "Mercadona"), no la razón social completa.
- date en ISO (YYYY-MM-DD). Si el ticket trae DD/MM/YYYY o DD-MM-YYYY, conviértelo. Si no hay fecha, null.
- category uno de: ${CATEGORIES.join(", ")}.
- installments: si dice MSI / meses / cuotas usa ese número; si es un pago, 1.
- note: una línea útil (folio, plan, MSI) o "".
- Si la imagen no es un ticket, merchant="", amount=null, confidence=0.`;
var scanReceipt_createServerFn_handler = createServerRpc({
	id: "f1d655a88e4fdbccfe967b7a3384ed8892acbd4ec73087cb0f489d3b808d185c",
	name: "scanReceipt",
	filename: "src/lib/scan-receipt.ts"
}, (opts) => scanReceipt.__executeServer(opts));
var scanReceipt = createServerFn({ method: "POST" }).validator((input) => {
	if (typeof input !== "object" || input === null) throw new Error("Datos inválidos");
	const image = input.image;
	if (typeof image !== "string" || image.length < 32) throw new Error("Imagen vacía");
	if (image.length > 28e5) throw new Error("La imagen es demasiado grande");
	return { image };
}).handler(scanReceipt_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "La lectura automática no está disponible ahora."
	};
	const image = data.image.startsWith("data:") ? data.image : `data:image/jpeg;base64,${data.image}`;
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .1,
				max_tokens: 400,
				messages: [{
					role: "system",
					content: SYSTEM
				}, {
					role: "user",
					content: [{
						type: "text",
						text: "Extrae los datos de este ticket o recibo."
					}, {
						type: "image_url",
						image_url: { url: image }
					}]
				}]
			})
		});
		if (!res.ok) {
			const body = await res.text().catch(() => "");
			if (res.status === 401 || res.status === 403) return {
				ok: false,
				error: "La lectura automática no está disponible ahora."
			};
			console.error("xAI scan error", res.status, body.slice(0, 400));
			return {
				ok: false,
				error: "No pude leer el ticket. Completa el gasto a mano; la foto queda adjunta."
			};
		}
		const parsed = parseModelJson((await res.json()).choices?.[0]?.message?.content ?? "");
		if (!parsed) return {
			ok: false,
			error: "No encontré datos claros en la imagen. Completa el gasto; la foto queda adjunta."
		};
		const category = CATEGORIES.includes(parsed.category) ? parsed.category : "other";
		const amount = typeof parsed.amount === "number" && Number.isFinite(parsed.amount) ? Math.round(parsed.amount * 100) / 100 : null;
		const installmentsRaw = Number(parsed.installments);
		const installments = Number.isFinite(installmentsRaw) ? Math.min(24, Math.max(1, Math.round(installmentsRaw))) : 1;
		return {
			ok: true,
			merchant: String(parsed.merchant ?? "").trim().slice(0, 80),
			amount,
			date: validDate(String(parsed.date ?? "")),
			category,
			installments,
			note: String(parsed.note ?? "").trim().slice(0, 140),
			confidence: clamp01(Number(parsed.confidence ?? .6))
		};
	} catch (err) {
		console.error("scanReceipt", err);
		return {
			ok: false,
			error: "No pude leer el ticket. Completa el gasto; la foto queda adjunta."
		};
	}
});
function parseModelJson(text) {
	const start = text.indexOf("{");
	const end = text.lastIndexOf("}");
	if (start < 0 || end <= start) return null;
	try {
		return JSON.parse(text.slice(start, end + 1));
	} catch {
		return null;
	}
}
function validDate(value) {
	if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
	const t = Date.parse(value + "T00:00:00");
	if (!Number.isFinite(t)) return null;
	return value;
}
function clamp01(n) {
	if (!Number.isFinite(n)) return .5;
	return Math.min(1, Math.max(0, n));
}
//#endregion
export { scanReceipt_createServerFn_handler };
