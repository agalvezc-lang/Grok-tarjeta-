import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as ChartColumn, S as ChevronLeft, _ as Ellipsis, a as TrainFront, b as Clapperboard, c as ShoppingBag, d as Plus, f as Plane, g as House, h as Image$1, l as Search, m as Keyboard, n as Wrench, o as Sparkles, p as LoaderCircle, r as Utensils, s as ShoppingCart, t as X, u as Receipt, v as Cross, w as Camera, x as ChevronRight, y as CreditCard } from "../_libs/lucide-react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { i as CURRENCIES, n as CARD_COLORS, t as CARD_BRANDS } from "./types-BDEBqRxR.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as format, t as es } from "../_libs/date-fns.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { a as Bar, c as ResponsiveContainer, i as XAxis, l as Tooltip, n as BarChart, o as Pie, r as YAxis, s as Cell, t as PieChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C8ElUFYR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NetworkMark({ brand, className }) {
	if (brand === "visa") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 60 20",
		className,
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "60",
			y: "16",
			textAnchor: "end",
			fill: "currentColor",
			fontSize: "16",
			fontWeight: "700",
			fontFamily: "var(--font-sans)",
			letterSpacing: "1",
			children: "VISA"
		})
	});
	if (brand === "mastercard") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 48 28",
		className,
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "18",
			cy: "14",
			r: "12",
			fill: "currentColor",
			opacity: "0.55"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "30",
			cy: "14",
			r: "12",
			fill: "currentColor",
			opacity: "0.9"
		})]
	});
	if (brand === "amex") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 72 20",
		className,
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "72",
			y: "16",
			textAnchor: "end",
			fill: "currentColor",
			fontSize: "13",
			fontWeight: "700",
			fontFamily: "var(--font-sans)",
			letterSpacing: "0.5",
			children: "AMEX"
		})
	});
	if (brand === "carnet") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 80 20",
		className,
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
			x: "80",
			y: "16",
			textAnchor: "end",
			fill: "currentColor",
			fontSize: "13",
			fontWeight: "600",
			fontFamily: "var(--font-sans)",
			letterSpacing: "0.8",
			children: "CARNET"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 28 20",
		className,
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			x: "1",
			y: "3",
			width: "26",
			height: "14",
			rx: "3",
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "1.5"
		})
	});
}
var BRAND_LABEL = {
	visa: "Visa",
	mastercard: "Mastercard",
	amex: "American Express",
	carnet: "Carnet",
	other: "Otra"
};
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	return crypto.randomUUID();
}
function todayISO() {
	const d = /* @__PURE__ */ new Date();
	const m = String(d.getMonth() + 1).padStart(2, "0");
	const day = String(d.getDate()).padStart(2, "0");
	return `${d.getFullYear()}-${m}-${day}`;
}
function clampDay(year, month, day) {
	const last = new Date(year, month + 1, 0).getDate();
	return Math.min(Math.max(1, day), last);
}
function addMonths(year, month, count) {
	const d = new Date(year, month + count, 1);
	return {
		year: d.getFullYear(),
		month: d.getMonth()
	};
}
function isoToParts(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	return {
		year: y,
		month: m - 1,
		day: d
	};
}
function formatMoney(amount, currency) {
	return new Intl.NumberFormat("es-MX", {
		style: "currency",
		currency,
		minimumFractionDigits: 2
	}).format(amount);
}
function formatDayMonth(iso) {
	const [y, m, d] = iso.split("-").map(Number);
	const date = new Date(y, m - 1, d);
	return format(date, "d MMM", { locale: es });
}
function formatMonthTitle(year, month) {
	const date = new Date(year, month, 1);
	return format(date, "MMMM yyyy", { locale: es });
}
function formatMonthShort(year, month) {
	const date = new Date(year, month, 1);
	return format(date, "MMM yy", { locale: es });
}
function parseAmount(raw) {
	const cleaned = raw.replace(/[^\d.,-]/g, "").trim();
	if (!cleaned) return null;
	const hasComma = cleaned.includes(",");
	const hasDot = cleaned.includes(".");
	let normalized = cleaned;
	if (hasComma && hasDot) {
		if (cleaned.lastIndexOf(",") > cleaned.lastIndexOf(".")) normalized = cleaned.replace(/\./g, "").replace(",", ".");
		else normalized = cleaned.replace(/,/g, "");
	} else if (hasComma) {
		const parts = cleaned.split(",");
		normalized = parts.length === 2 && parts[1].length <= 2 ? parts.join(".") : cleaned.replace(/,/g, "");
	}
	const n = Number(normalized);
	return Number.isFinite(n) ? Math.round(n * 100) / 100 : null;
}
function splitInstallments(total, n) {
	const count = Math.max(1, Math.min(24, Math.round(n)));
	const cents = Math.round(total * 100);
	const base = Math.floor(cents / count);
	const rem = cents - base * count;
	return Array.from({ length: count }, (_, i) => (base + (i < rem ? 1 : 0)) / 100);
}
function daysUntil(date) {
	const today = /* @__PURE__ */ new Date();
	today.setHours(0, 0, 0, 0);
	const target = new Date(date);
	target.setHours(0, 0, 0, 0);
	return Math.round((target.getTime() - today.getTime()) / 864e5);
}
var COLOR_CLASS = {
	navy: "bg-card-navy",
	wine: "bg-card-wine",
	forest: "bg-card-forest",
	ink: "bg-card-ink",
	slate: "bg-card-slate",
	rust: "bg-card-rust",
	ocean: "bg-card-ocean",
	plum: "bg-card-plum"
};
function PlasticCard({ card, subtitle, amount, currency, compact = false, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("relative overflow-hidden rounded-xl text-fg", COLOR_CLASS[card.color], compact ? "aspect-[1.7/1] p-4" : "aspect-[1.62/1] p-5", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -right-8 -top-10 size-40 rounded-full bg-fg/8" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute -bottom-12 left-16 size-36 rounded-full bg-bg/20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex h-full flex-col justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-fg/70",
						children: card.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-mono text-sm tracking-[0.18em] text-fg/90",
						children: ["•••• ", card.last4]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NetworkMark, {
						brand: card.brand,
						className: "h-6 w-12 text-fg/85"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-end justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-7 w-9 rounded-sm bg-chip/90 shadow-inner" }), subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-fg/70",
							children: subtitle
						}) : null]
					}), typeof amount === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg font-medium tabular leading-none tracking-tight",
						children: formatMoney(amount, currency)
					}) : null]
				})]
			})
		]
	});
}
var CATEGORY_META = {
	food: {
		label: "Comida",
		icon: Utensils,
		chart: "var(--color-chart-1)"
	},
	groceries: {
		label: "Despensa",
		icon: ShoppingCart,
		chart: "var(--color-chart-2)"
	},
	transport: {
		label: "Transporte",
		icon: TrainFront,
		chart: "var(--color-chart-3)"
	},
	home: {
		label: "Hogar",
		icon: House,
		chart: "var(--color-chart-4)"
	},
	health: {
		label: "Salud",
		icon: Cross,
		chart: "var(--color-chart-5)"
	},
	entertainment: {
		label: "Ocio",
		icon: Clapperboard,
		chart: "var(--color-chart-6)"
	},
	shopping: {
		label: "Compras",
		icon: ShoppingBag,
		chart: "var(--color-chart-1)"
	},
	subscriptions: {
		label: "Suscripciones",
		icon: Sparkles,
		chart: "var(--color-chart-3)"
	},
	travel: {
		label: "Viajes",
		icon: Plane,
		chart: "var(--color-chart-4)"
	},
	services: {
		label: "Servicios",
		icon: Wrench,
		chart: "var(--color-chart-5)"
	},
	other: {
		label: "Otros",
		icon: Ellipsis,
		chart: "var(--color-chart-6)"
	}
};
var CATEGORY_LIST = Object.keys(CATEGORY_META).map((id) => ({
	id,
	...CATEGORY_META[id]
}));
var MERCHANT_HINTS = [
	[/oxxo|seven eleven|7-eleven|circle k|mercadona|carrefour|dia |aldi|lidl/i, "groceries"],
	[/uber|didi|cabify|metro|pemex|gasolin|shell|bp |renfe|bolt/i, "transport"],
	[/netflix|spotify|disney|hbo|prime video|youtube|apple one|icloud/i, "subscriptions"],
	[/cfe|telmex|izzi|totalplay|axtel|telcel|movistar|at&t|endesa|iberdrola|naturgy/i, "services"],
	[/uber eats|rappi|didi food|starbucks|vips|sanborns|restaur|mcdonald|burger king/i, "food"],
	[/walmart|soriana|chedraui|aurrera|superama|heb |costco|sams|mercadona/i, "groceries"],
	[/farmacia|guadalajara|similares|benavides|hospital|farmacias/i, "health"],
	[/cinepolis|cinemex|boleto|ticketmaster|cinesa/i, "entertainment"],
	[/liverpool|palacio|zara|h&m|amazon|mercado libre|shein|el corte ingles/i, "shopping"],
	[/aeromexico|volaris|viva aerobus|booking|airbnb|hotel|iberia|vueling|ryanair/i, "travel"],
	[/ikea|home depot|sodimac|coppel hogar|leroy merlin/i, "home"]
];
function guessCategory(merchant) {
	for (const [re, cat] of MERCHANT_HINTS) if (re.test(merchant)) return cat;
	return "other";
}
function ExpenseRow({ expense, card, currency, charge, onClick }) {
	const Icon = CATEGORY_META[expense.category].icon;
	const amount = charge?.amount ?? expense.amount;
	const installmentLabel = expense.installments > 1 ? `${(charge?.installmentIndex ?? 0) + 1}/${expense.installments}` : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex w-full items-center gap-3 rounded-lg px-1 py-2.5 text-left transition-colors duration-150 hover:bg-surface"),
		children: [expense.receiptThumb ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: expense.receiptThumb,
			alt: "",
			className: "size-10 shrink-0 rounded-md object-cover outline outline-1 -outline-offset-1 outline-fg/10"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-10 shrink-0 items-center justify-center rounded-md bg-surface-2 text-fg-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex items-baseline justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate text-sm font-medium",
					children: expense.merchant
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 font-display text-base tabular tracking-tight",
					children: formatMoney(amount, currency)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "mt-0.5 flex items-center gap-2 text-xs text-fg-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatDayMonth(expense.date) }),
					card ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· ", card.name] }) : null,
					installmentLabel ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· ", installmentLabel] }) : null
				]
			})]
		})]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-colors duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:bg-accent/90 active:scale-[0.98]",
			secondary: "bg-surface-2 text-fg hover:bg-surface-2/80 shadow-[var(--shadow-border)]",
			ghost: "text-fg-muted hover:bg-surface hover:text-fg",
			outline: "text-fg shadow-[var(--shadow-border)] hover:bg-surface",
			danger: "bg-danger text-fg hover:bg-danger/90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var IMAGE_ACCEPT = "image/*,image/jpeg,image/png,image/webp,image/heic,image/heif,.jpg,.jpeg,.png,.webp,.heic,.heif";
async function compressImage(source, maxEdge = 1280, quality = .72) {
	const img = await loadImage(source);
	const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
	const width = Math.max(1, Math.round(img.width * scale));
	const height = Math.max(1, Math.round(img.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = width;
	canvas.height = height;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("No se pudo procesar la imagen");
	ctx.fillStyle = "#111110";
	ctx.fillRect(0, 0, width, height);
	ctx.drawImage(img, 0, 0, width, height);
	return canvas.toDataURL("image/jpeg", quality);
}
async function loadImage(source) {
	if (source instanceof HTMLImageElement) return source;
	if (typeof createImageBitmap === "function" && typeof source !== "string") try {
		const bitmap = await createImageBitmap(source);
		const canvas = document.createElement("canvas");
		canvas.width = bitmap.width;
		canvas.height = bitmap.height;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("bitmap");
		ctx.drawImage(bitmap, 0, 0);
		bitmap.close();
		const img = new Image();
		img.crossOrigin = "anonymous";
		await new Promise((resolve, reject) => {
			img.onload = () => resolve();
			img.onerror = () => reject(/* @__PURE__ */ new Error("No se pudo leer la imagen"));
			img.src = canvas.toDataURL("image/jpeg", .92);
		});
		return img;
	} catch {}
	const img = new Image();
	img.crossOrigin = "anonymous";
	const url = typeof source === "string" ? source : URL.createObjectURL(source);
	try {
		await new Promise((resolve, reject) => {
			img.onload = () => resolve();
			img.onerror = () => reject(/* @__PURE__ */ new Error("No se pudo leer la imagen"));
			img.src = url;
		});
	} finally {
		if (typeof source !== "string") URL.revokeObjectURL(url);
	}
	return img;
}
function isSupportedImage(file) {
	if (!file) return false;
	if (/image\/(jpeg|jpg|png|webp|gif|heic|heif|bmp)/i.test(file.type)) return true;
	return /\.(jpe?g|png|webp|gif|heic|heif|bmp)$/i.test(file.name);
}
function filesFromList(list) {
	if (!list) return [];
	return Array.from(list).filter(isSupportedImage);
}
async function prepareReceipt(file) {
	if (!isSupportedImage(file)) throw new Error("Usa una foto JPG, PNG o WEBP del ticket.");
	try {
		return {
			scanSrc: await compressImage(file, 1024, .6),
			thumb: await compressImage(file, 360, .5)
		};
	} catch {
		throw new Error("No se pudo abrir esa foto. Elige otra de la galería (JPG o PNG).");
	}
}
var GALLERY_INPUT_ID = "gastos-gallery-input";
var CAMERA_INPUT_ID = "gastos-camera-input";
function GalleryFileInputs({ onFiles }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		id: GALLERY_INPUT_ID,
		type: "file",
		accept: IMAGE_ACCEPT,
		multiple: true,
		className: "sr-only",
		tabIndex: -1,
		"aria-hidden": true,
		onChange: (e) => {
			const files = Array.from(e.currentTarget.files ?? []);
			e.currentTarget.value = "";
			if (files.length) onFiles(files, "gallery");
		}
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		id: CAMERA_INPUT_ID,
		type: "file",
		accept: "image/*",
		capture: "environment",
		className: "sr-only",
		tabIndex: -1,
		"aria-hidden": true,
		onChange: (e) => {
			const files = Array.from(e.currentTarget.files ?? []);
			e.currentTarget.value = "";
			if (files.length) onFiles(files, "camera");
		}
	})] });
}
function GalleryLabel({ htmlFor = GALLERY_INPUT_ID, className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		htmlFor,
		className: cn("cursor-pointer", className),
		...props,
		children
	});
}
function cycleKeyOf(closeDay, isoDate) {
	const { year, month, day } = isoToParts(isoDate);
	if (day > closeDay) return addMonths(year, month, 1);
	return {
		year,
		month
	};
}
function buildCycle(card, key) {
	const closeDay = clampDay(key.year, key.month, card.closeDay);
	const close = new Date(key.year, key.month, closeDay);
	const prev = addMonths(key.year, key.month, -1);
	const prevCloseDay = clampDay(prev.year, prev.month, card.closeDay);
	const start = new Date(prev.year, prev.month, prevCloseDay + 1);
	let dueYear = key.year;
	let dueMonth = key.month;
	if (card.dueDay <= card.closeDay) {
		const next = addMonths(key.year, key.month, 1);
		dueYear = next.year;
		dueMonth = next.month;
	}
	const due = new Date(dueYear, dueMonth, clampDay(dueYear, dueMonth, card.dueDay));
	return {
		...key,
		close,
		due,
		start
	};
}
function currentCycleKey(card, from = /* @__PURE__ */ new Date()) {
	const iso = `${from.getFullYear()}-${String(from.getMonth() + 1).padStart(2, "0")}-${String(from.getDate()).padStart(2, "0")}`;
	return cycleKeyOf(card.closeDay, iso);
}
function sameCycle(a, b) {
	return a.year === b.year && a.month === b.month;
}
function expenseCharges(expense, card) {
	const parts = splitInstallments(expense.amount, expense.installments);
	const first = cycleKeyOf(card.closeDay, expense.date);
	return parts.map((amount, installmentIndex) => {
		return {
			expense,
			installmentIndex,
			amount,
			cycle: addMonths(first.year, first.month, installmentIndex)
		};
	});
}
function chargesInCycle(expenses, card, key) {
	return expenses.filter((e) => e.cardId === card.id).flatMap((e) => expenseCharges(e, card)).filter((c) => sameCycle(c.cycle, key));
}
function cycleTotal(expenses, card, key) {
	return chargesInCycle(expenses, card, key).reduce((s, c) => s + c.amount, 0);
}
function isPaid(paid, cardId, key) {
	return paid.some((p) => p.cardId === cardId && p.year === key.year && p.month === key.month);
}
function outstandingForCard(expenses, card, paid, from = /* @__PURE__ */ new Date()) {
	const current = currentCycleKey(card, from);
	let total = 0;
	for (const expense of expenses.filter((e) => e.cardId === card.id)) for (const charge of expenseCharges(expense, card)) {
		const isFutureOrCurrent = charge.cycle.year > current.year || charge.cycle.year === current.year && charge.cycle.month >= current.month;
		const unpaidPast = !isFutureOrCurrent && !isPaid(paid, card.id, charge.cycle);
		if (isFutureOrCurrent || unpaidPast) total += charge.amount;
	}
	return total;
}
function availableCredit(expenses, card, paid) {
	return Math.round((card.limit - outstandingForCard(expenses, card, paid)) * 100) / 100;
}
function shiftISO(days) {
	const d = /* @__PURE__ */ new Date();
	d.setDate(d.getDate() + days);
	const m = String(d.getMonth() + 1).padStart(2, "0");
	const day = String(d.getDate()).padStart(2, "0");
	return `${d.getFullYear()}-${m}-${day}`;
}
function createDemoCards() {
	const now = "2026-01-01T00:00:00.000Z";
	return [
		{
			id: "card-nu",
			name: "Nu",
			last4: "4412",
			brand: "mastercard",
			color: "plum",
			limit: 35e3,
			closeDay: 12,
			dueDay: 20,
			createdAt: now
		},
		{
			id: "card-bbva",
			name: "BBVA Azul",
			last4: "8891",
			brand: "visa",
			color: "navy",
			limit: 5e4,
			closeDay: 25,
			dueDay: 12,
			createdAt: now
		},
		{
			id: "card-santander",
			name: "Santander Like",
			last4: "2204",
			brand: "visa",
			color: "wine",
			limit: 22e3,
			closeDay: 5,
			dueDay: 18,
			createdAt: now
		}
	];
}
function createDemoExpenses(cards) {
	const nu = cards[0]?.id ?? "card-nu";
	const bbva = cards[1]?.id ?? "card-bbva";
	const san = cards[2]?.id ?? "card-santander";
	return [
		{
			cardId: nu,
			merchant: "Netflix",
			amount: 299,
			category: "subscriptions",
			date: shiftISO(-2),
			installments: 1,
			note: "Plan estándar"
		},
		{
			cardId: nu,
			merchant: "Uber",
			amount: 186.5,
			category: "transport",
			date: shiftISO(-1),
			installments: 1,
			note: ""
		},
		{
			cardId: nu,
			merchant: "Oxxo Reforma",
			amount: 99.4,
			category: "groceries",
			date: todayISO(),
			installments: 1,
			note: ""
		},
		{
			cardId: nu,
			merchant: "Spotify",
			amount: 129,
			category: "subscriptions",
			date: shiftISO(-18),
			installments: 1,
			note: ""
		},
		{
			cardId: bbva,
			merchant: "CFE",
			amount: 1240,
			category: "services",
			date: shiftISO(-6),
			installments: 1,
			note: "Recibo bimestral"
		},
		{
			cardId: bbva,
			merchant: "Liverpool",
			amount: 7200,
			category: "shopping",
			date: shiftISO(-10),
			installments: 6,
			note: "MSI"
		},
		{
			cardId: bbva,
			merchant: "Walmart",
			amount: 1864.2,
			category: "groceries",
			date: shiftISO(-4),
			installments: 1,
			note: ""
		},
		{
			cardId: bbva,
			merchant: "Uber Eats",
			amount: 312,
			category: "food",
			date: shiftISO(-3),
			installments: 1,
			note: ""
		},
		{
			cardId: san,
			merchant: "Cinépolis",
			amount: 248,
			category: "entertainment",
			date: shiftISO(-8),
			installments: 1,
			note: ""
		},
		{
			cardId: san,
			merchant: "Farmacia Guadalajara",
			amount: 540.8,
			category: "health",
			date: shiftISO(-5),
			installments: 1,
			note: ""
		},
		{
			cardId: san,
			merchant: "Telcel",
			amount: 449,
			category: "services",
			date: shiftISO(-14),
			installments: 1,
			note: "Plan"
		},
		{
			cardId: nu,
			merchant: "Rappi",
			amount: 221,
			category: "food",
			date: shiftISO(-12),
			installments: 1,
			note: ""
		},
		{
			cardId: bbva,
			merchant: "Pemex",
			amount: 980,
			category: "transport",
			date: shiftISO(-9),
			installments: 1,
			note: ""
		},
		{
			cardId: san,
			merchant: "Aeroméxico",
			amount: 4680,
			category: "travel",
			date: shiftISO(-22),
			installments: 3,
			note: "Vuelo GDL"
		}
	].map((row, i) => ({
		...row,
		id: `exp-demo-${i}`,
		createdAt: `${row.date}T12:00:00.000Z`
	}));
}
var empty = {
	cards: [],
	expenses: [],
	paid: [],
	currency: "MXN",
	isDemo: false,
	hasOnboarded: false
};
function demoState() {
	const cards = createDemoCards();
	return {
		cards,
		expenses: createDemoExpenses(cards),
		paid: [],
		currency: "MXN",
		isDemo: true,
		hasOnboarded: false
	};
}
var useStore = create()(persist((set, get) => ({
	...demoState(),
	hydrated: false,
	tab: "home",
	setHydrated: (v) => set({ hydrated: v }),
	setTab: (tab) => set({ tab }),
	setCurrency: (currency) => set({ currency }),
	addCard: (card) => {
		const id = uid();
		set({
			cards: [...get().cards, {
				...card,
				id,
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			}],
			isDemo: false,
			hasOnboarded: true
		});
		return id;
	},
	updateCard: (id, patch) => set({ cards: get().cards.map((c) => c.id === id ? {
		...c,
		...patch,
		id
	} : c) }),
	deleteCard: (id) => set({
		cards: get().cards.filter((c) => c.id !== id),
		expenses: get().expenses.filter((e) => e.cardId !== id),
		paid: get().paid.filter((p) => p.cardId !== id),
		isDemo: false,
		hasOnboarded: true
	}),
	addExpense: (expense) => {
		const id = uid();
		set({
			expenses: [{
				...expense,
				id,
				createdAt: (/* @__PURE__ */ new Date()).toISOString()
			}, ...get().expenses],
			isDemo: false,
			hasOnboarded: true
		});
		return id;
	},
	updateExpense: (id, patch) => set({
		expenses: get().expenses.map((e) => e.id === id ? {
			...e,
			...patch,
			id
		} : e),
		isDemo: false
	}),
	deleteExpense: (id) => set({
		expenses: get().expenses.filter((e) => e.id !== id),
		isDemo: false
	}),
	togglePaid: (cardId, year, month) => {
		const paid = get().paid;
		set({ paid: paid.some((p) => p.cardId === cardId && p.year === year && p.month === month) ? paid.filter((p) => !(p.cardId === cardId && p.year === year && p.month === month)) : [...paid, {
			cardId,
			year,
			month
		}] });
	},
	loadDemo: () => {
		const cards = createDemoCards();
		set({
			cards,
			expenses: createDemoExpenses(cards),
			paid: [],
			isDemo: true,
			hasOnboarded: true,
			currency: "MXN"
		});
	},
	clearAll: () => set({
		...empty,
		hasOnboarded: true
	})
}), {
	name: "gastos-alcorte-v1",
	partialize: (s) => ({
		cards: s.cards,
		expenses: s.expenses,
		paid: s.paid,
		currency: s.currency,
		isDemo: s.isDemo,
		hasOnboarded: s.hasOnboarded
	}),
	onRehydrateStorage: () => (state) => {
		if (!state) return;
		if (state.cards.length === 0 && !state.hasOnboarded) state.loadDemo();
		state.setHydrated(true);
	}
}));
function Badge({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full bg-surface-2 px-2.5 py-1 text-xs font-medium text-fg-muted", className),
		...props
	});
}
function HomeView({ onAdd, onDemoTicket, onOpenExpense, onOpenCard, cycle, onCycle }) {
	const cards = useStore((s) => s.cards);
	const expenses = useStore((s) => s.expenses);
	const paid = useStore((s) => s.paid);
	const currency = useStore((s) => s.currency);
	const totals = cards.map((card) => ({
		card,
		total: cycleTotal(expenses, card, cycle),
		available: availableCredit(expenses, card, paid),
		paid: isPaid(paid, card.id, cycle),
		due: buildCycle(card, cycle).due
	}));
	const grand = totals.reduce((s, t) => s + t.total, 0);
	const nearestDue = totals.map((t) => t.due).sort((a, b) => a.getTime() - b.getTime())[0];
	const dueIn = nearestDue ? daysUntil(nearestDue) : null;
	const recent = [...expenses].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt)).slice(0, 8);
	const withPhotos = expenses.filter((e) => e.receiptThumb).slice(0, 10);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.16em] text-fg-subtle",
					children: "Este corte"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight capitalize",
					children: formatMonthTitle(cycle.year, cycle.month)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-10",
						"aria-label": "Mes anterior",
						onClick: () => onCycle(addMonths(cycle.year, cycle.month, -1)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						className: "size-10",
						"aria-label": "Mes siguiente",
						onClick: () => onCycle(addMonths(cycle.year, cycle.month, 1)),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-5 lift",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.14em] text-fg-subtle",
						children: "A pagar"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-4xl font-medium tabular tracking-tight",
						children: formatMoney(grand, currency)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-fg-muted",
						children: dueIn == null ? "Agrega una tarjeta para ver el vencimiento" : dueIn < 0 ? `Venció hace ${Math.abs(dueIn)} días` : dueIn === 0 ? "Vence hoy" : `Próximo pago en ${dueIn} días`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "h-12",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GalleryLabel, {
								htmlFor: GALLERY_INPUT_ID,
								className: "inline-flex h-12 items-center justify-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-4" }), "Desde galería"]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							onClick: onAdd,
							className: "h-12",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Manual"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onDemoTicket,
						className: "mt-3 w-full text-center text-xs text-fg-muted underline-offset-4 hover:text-fg hover:underline",
						children: "Probar con un ticket de ejemplo"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "-mx-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-between px-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Tickets"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex snap-x gap-2 overflow-x-auto px-4 pb-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GalleryLabel, {
						htmlFor: GALLERY_INPUT_ID,
						className: "flex size-20 shrink-0 snap-start flex-col items-center justify-center gap-1 rounded-lg bg-surface text-fg-muted shadow-[var(--shadow-border)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] font-medium",
							children: "Añadir"
						})]
					}), withPhotos.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onOpenExpense(e.id),
						className: "size-20 shrink-0 snap-start overflow-hidden rounded-lg",
						"aria-label": `Ticket de ${e.merchant}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: e.receiptThumb,
							alt: "",
							className: "size-full object-cover"
						})
					}, e.id))]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "-mx-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center justify-between px-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Tarjetas"
					})
				}), cards.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-4 pt-4 text-sm text-fg-muted",
					children: "Aún no hay tarjetas."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 flex snap-x gap-3 overflow-x-auto px-4 pb-2",
					children: totals.map(({ card, total, available, paid: paidFlag }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onOpenCard(card.id),
						className: "w-[min(78vw,22rem)] shrink-0 snap-start text-left",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlasticCard, {
							card,
							currency,
							amount: total,
							subtitle: paidFlag ? "Pagado" : `Disp. ${formatMoney(available, currency)}`
						})
					}, card.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Gastos recientes"
				}), recent.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: [recent.length, " últimos"] }) : null]
			}), recent.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyRecent, { onDemoTicket }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border",
				children: recent.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseRow, {
					expense: e,
					card: cards.find((c) => c.id === e.cardId),
					currency,
					onClick: () => onOpenExpense(e.id)
				}) }, e.id))
			})] })
		]
	});
}
function EmptyRecent({ onDemoTicket }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-surface px-4 py-10 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-fg-muted",
				children: "Todavía no hay movimientos. Elige un ticket de la galería."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GalleryLabel, {
					htmlFor: GALLERY_INPUT_ID,
					className: "inline-flex h-11 items-center justify-center gap-2 px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-4" }), "Leer ticket"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onDemoTicket,
				className: "mt-3 block w-full text-xs text-fg-muted underline-offset-4 hover:text-fg hover:underline",
				children: "Probar con un ticket de ejemplo"
			})
		]
	});
}
function CardsView({ cycle, onAdd, onOpen }) {
	const cards = useStore((s) => s.cards);
	const expenses = useStore((s) => s.expenses);
	const paid = useStore((s) => s.paid);
	const currency = useStore((s) => s.currency);
	const togglePaid = useStore((s) => s.togglePaid);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-end justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.16em] text-fg-subtle",
				children: "Plástico"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-medium tracking-tight",
				children: "Tarjetas"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				onClick: onAdd,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "Nueva"]
			})]
		}), cards.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface px-4 py-12 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-fg-muted",
				children: "Agrega tu primera tarjeta: nombre, últimos 4, límite y día de corte."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: onAdd,
				children: "Agregar tarjeta"
			})]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-5",
			children: cards.map((card) => {
				const total = cycleTotal(expenses, card, cycle);
				const available = availableCredit(expenses, card, paid);
				const paidFlag = isPaid(paid, card.id, cycle);
				const dueIn = daysUntil(buildCycle(card, cycle).due);
				const used = Math.min(1, Math.max(0, (card.limit - available) / card.limit || 0));
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl bg-surface p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "w-full text-left",
							onClick: () => onOpen(card.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlasticCard, {
								card,
								currency,
								compact: true
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center justify-between gap-3 px-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-fg-muted",
								children: "Este corte"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl tabular tracking-tight",
								children: formatMoney(total, currency)
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-fg-muted",
									children: "Disponible"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "tabular text-sm font-medium",
									children: formatMoney(available, currency)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-1.5 overflow-hidden rounded-full bg-bg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-full bg-accent",
								style: { width: `${Math.round(used * 100)}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center justify-between px-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-fg-muted",
								children: [
									"Corte ",
									card.closeDay,
									" · Pago ",
									card.dueDay,
									dueIn >= 0 ? ` · ${dueIn}d` : ""
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => togglePaid(card.id, cycle.year, cycle.month),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									className: paidFlag ? "bg-ok/20 text-ok" : "",
									children: paidFlag ? "Pagado" : "Marcar pagado"
								})
							})]
						})
					]
				}, card.id);
			})
		})]
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md bg-surface px-3 text-sm text-fg shadow-[var(--shadow-border)] placeholder:text-fg-subtle", "transition-shadow duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70", "disabled:opacity-40", className),
		...props
	});
}
function HistoryView({ cycle, onOpenExpense }) {
	const cards = useStore((s) => s.cards);
	const expenses = useStore((s) => s.expenses);
	const currency = useStore((s) => s.currency);
	const [q, setQ] = (0, import_react.useState)("");
	const [cardId, setCardId] = (0, import_react.useState)("all");
	const [mode, setMode] = (0, import_react.useState)("cycle");
	const rows = (0, import_react.useMemo)(() => {
		const query = q.trim().toLowerCase();
		if (mode === "cycle") return cards.filter((c) => cardId === "all" || c.id === cardId).flatMap((card) => chargesInCycle(expenses, card, cycle).map((charge) => ({
			charge,
			card
		}))).filter(({ charge }) => query ? charge.expense.merchant.toLowerCase().includes(query) : true).sort((a, b) => b.charge.expense.date.localeCompare(a.charge.expense.date));
		return expenses.filter((e) => cardId === "all" ? true : e.cardId === cardId).filter((e) => {
			const key = cards.find((c) => c.id === e.cardId);
			if (!key) return false;
			const ck = cycleKeyOf(key.closeDay, e.date);
			return ck.year === cycle.year && ck.month === cycle.month;
		}).filter((e) => query ? e.merchant.toLowerCase().includes(query) : true).sort((a, b) => b.date.localeCompare(a.date)).map((expense) => ({
			charge: {
				expense,
				installmentIndex: 0,
				amount: expense.amount,
				cycle
			},
			card: cards.find((c) => c.id === expense.cardId)
		})).filter((r) => r.card);
	}, [
		cards,
		expenses,
		cycle,
		cardId,
		q,
		mode
	]);
	const total = rows.reduce((s, r) => s + r.charge.amount, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.16em] text-fg-subtle",
					children: "Movimientos"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: "Historial"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-xl tabular text-fg-muted",
					children: formatMoney(total, currency)
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-fg-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Buscar comercio",
					className: "pl-9"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					on: mode === "cycle",
					onClick: () => setMode("cycle"),
					children: "Por corte"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					on: mode === "purchase",
					onClick: () => setMode("purchase"),
					children: "Por compra"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					on: cardId === "all",
					onClick: () => setCardId("all"),
					children: "Todas"
				}), cards.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					on: cardId === c.id,
					onClick: () => setCardId(c.id),
					children: c.name
				}, c.id))]
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-xl bg-surface px-4 py-10 text-center text-sm text-fg-muted",
				children: "Nada en este corte. Prueba otro mes o sube un ticket."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border",
				children: rows.map(({ charge, card }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseRow, {
					expense: charge.expense,
					card,
					currency,
					charge,
					onClick: () => onOpenExpense(charge.expense.id)
				}) }, `${charge.expense.id}-${charge.installmentIndex}`))
			})
		]
	});
}
function FilterChip({ on, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-9 shrink-0 rounded-full px-3 text-xs font-medium", on ? "bg-accent text-accent-fg" : "bg-surface text-fg-muted"),
		children
	});
}
function InsightsView({ cycle }) {
	const cards = useStore((s) => s.cards);
	const expenses = useStore((s) => s.expenses);
	const currency = useStore((s) => s.currency);
	const setCurrency = useStore((s) => s.setCurrency);
	const loadDemo = useStore((s) => s.loadDemo);
	const clearAll = useStore((s) => s.clearAll);
	const isDemo = useStore((s) => s.isDemo);
	const byCategory = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const e of expenses) {
			const card = cards.find((c) => c.id === e.cardId);
			if (!card) continue;
			const key = cycleKeyOf(card.closeDay, e.date);
			if (key.year !== cycle.year || key.month !== cycle.month) continue;
			map.set(e.category, (map.get(e.category) ?? 0) + e.amount);
		}
		return [...map.entries()].map(([id, value]) => ({
			id,
			name: CATEGORY_META[id].label,
			value: Math.round(value * 100) / 100,
			fill: CATEGORY_META[id].chart
		})).sort((a, b) => b.value - a.value);
	}, [
		cards,
		expenses,
		cycle
	]);
	const trend = (0, import_react.useMemo)(() => {
		const points = [];
		for (let i = 5; i >= 0; i--) {
			const key = addMonths(cycle.year, cycle.month, -i);
			const total = cards.reduce((s, c) => s + cycleTotal(expenses, c, key), 0);
			points.push({
				name: formatMonthShort(key.year, key.month),
				total: Math.round(total)
			});
		}
		return points;
	}, [
		cards,
		expenses,
		cycle
	]);
	const catTotal = byCategory.reduce((s, c) => s + c.value, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.16em] text-fg-subtle",
				children: "Lectura"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-medium tracking-tight",
				children: "Análisis"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Por categoría"
				}), byCategory.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-10 text-center text-sm text-fg-muted",
					children: "Sin gastos en este corte."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 grid grid-cols-2 items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-44",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
								data: byCategory,
								dataKey: "value",
								nameKey: "name",
								innerRadius: 42,
								outerRadius: 68,
								paddingAngle: 2,
								stroke: "none",
								children: byCategory.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: e.fill }, e.id))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								formatter: (v) => formatMoney(Number(v), currency),
								contentStyle: {
									background: "var(--color-surface-2)",
									border: "none",
									borderRadius: 8,
									color: "var(--color-fg)"
								}
							})] })
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-1.5",
						children: byCategory.slice(0, 5).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-fg-muted",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular text-fg",
								children: [catTotal ? Math.round(c.value / catTotal * 100) : 0, "%"]
							})]
						}, c.id))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Últimos cortes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 h-44",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
							data: trend,
							barCategoryGap: "28%",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "name",
									tick: {
										fill: "var(--color-fg-muted)",
										fontSize: 11
									},
									axisLine: false,
									tickLine: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									formatter: (v) => formatMoney(Number(v), currency),
									cursor: { fill: "rgb(243 239 230 / 0.04)" },
									contentStyle: {
										background: "var(--color-surface-2)",
										border: "none",
										borderRadius: 8,
										color: "var(--color-fg)"
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
									dataKey: "total",
									fill: "var(--color-accent)",
									radius: [
										6,
										6,
										0,
										0
									]
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Ajustes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-fg-muted",
						children: "Moneda de la app. Los montos no se convierten."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: CURRENCIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCurrency(c),
							className: c === currency ? "h-9 rounded-full bg-accent px-3 text-xs font-medium text-accent-fg" : "h-9 rounded-full bg-bg px-3 text-xs font-medium text-fg-muted",
							children: c
						}, c))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-col gap-2",
						children: [
							isDemo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-fg-subtle",
								children: "Estás viendo datos de ejemplo. Se reemplazan al agregar un gasto real."
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								onClick: loadDemo,
								children: "Restaurar ejemplo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								className: "text-danger",
								onClick: clearAll,
								children: "Borrar todos los datos"
							})
						]
					})
				]
			})
		]
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-xs font-medium tracking-wide text-fg-muted", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-20 w-full rounded-md bg-surface px-3 py-2.5 text-sm text-fg shadow-[var(--shadow-border)] placeholder:text-fg-subtle", "transition-shadow duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70", className),
		...props
	});
}
function emptyDraft(cardId) {
	return {
		cardId,
		merchant: "",
		amount: "",
		category: "other",
		date: todayISO(),
		installments: 1,
		note: ""
	};
}
function draftFromExpense(e) {
	return {
		cardId: e.cardId,
		merchant: e.merchant,
		amount: String(e.amount),
		category: e.category,
		date: e.date,
		installments: e.installments,
		note: e.note,
		receiptThumb: e.receiptThumb
	};
}
function ExpenseForm({ cards, currency, draft, onChange, onSubmit, onCancel, submitLabel = "Guardar gasto", scanning = false }) {
	const [amountError, setAmountError] = (0, import_react.useState)(false);
	const parsed = parseAmount(draft.amount);
	const card = cards.find((c) => c.id === draft.cardId) ?? cards[0];
	const per = (0, import_react.useMemo)(() => {
		if (parsed == null || draft.installments <= 1) return null;
		return parsed / draft.installments;
	}, [parsed, draft.installments]);
	function submit() {
		if (parsed == null || parsed <= 0 || !draft.merchant.trim() || !draft.cardId) {
			setAmountError(parsed == null || parsed <= 0);
			return;
		}
		onSubmit();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 rounded-lg bg-surface p-2",
				children: [draft.receiptThumb ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: draft.receiptThumb,
					alt: "Ticket adjunto",
					className: "size-16 shrink-0 rounded-md object-cover outline outline-1 -outline-offset-1 outline-fg/10"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-16 shrink-0 items-center justify-center rounded-md bg-surface-2 text-fg-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GalleryLabel, {
						htmlFor: GALLERY_INPUT_ID,
						className: "block text-sm font-medium text-fg underline-offset-4 hover:underline",
						children: draft.receiptThumb ? "Cambiar foto de la galería" : "Adjuntar foto de la galería"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GalleryLabel, {
						htmlFor: CAMERA_INPUT_ID,
						className: "mt-1 inline-flex items-center gap-1 text-xs text-fg-muted hover:text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-3.5" }), "O tomar foto"]
					})]
				})]
			}),
			card ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlasticCard, {
				card,
				currency,
				compact: true,
				className: "max-h-28"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Tarjeta" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2 overflow-x-auto pb-1",
					children: cards.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => onChange({
							...draft,
							cardId: c.id
						}),
						className: cn("shrink-0 rounded-md px-3 py-2 text-left text-sm shadow-[var(--shadow-border)]", draft.cardId === c.id ? "bg-accent text-accent-fg" : "bg-surface text-fg"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: c.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "block text-xs opacity-70",
							children: ["•••• ", c.last4]
						})]
					}, c.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "merchant",
					children: "Comercio"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "merchant",
					value: draft.merchant,
					onChange: (e) => onChange({
						...draft,
						merchant: e.target.value
					}),
					placeholder: "Oxxo, CFE, Liverpool…",
					autoComplete: "off"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "amount",
						children: "Monto"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "amount",
						inputMode: "decimal",
						value: draft.amount,
						onChange: (e) => {
							setAmountError(false);
							onChange({
								...draft,
								amount: e.target.value
							});
						},
						placeholder: "0.00",
						className: cn("tabular", amountError && "ring-2 ring-danger")
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "date",
						children: "Fecha"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "date",
						type: "date",
						value: draft.date,
						onChange: (e) => onChange({
							...draft,
							date: e.target.value
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Categoría" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: CATEGORY_LIST.map((cat) => {
						const Icon = cat.icon;
						const on = draft.category === cat.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onChange({
								...draft,
								category: cat.id
							}),
							className: cn("inline-flex h-9 items-center gap-1.5 rounded-full px-3 text-xs font-medium", on ? "bg-accent text-accent-fg" : "bg-surface text-fg-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-3.5" }), cat.label]
						}, cat.id);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "cuotas",
							children: "Meses"
						}), per != null && parsed != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-fg-muted tabular",
							children: [
								draft.installments,
								" × ",
								formatMoney(per, currency)
							]
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "cuotas",
						type: "range",
						min: 1,
						max: 24,
						value: draft.installments,
						onChange: (e) => onChange({
							...draft,
							installments: Number(e.target.value)
						}),
						className: "h-11 w-full accent-accent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-xs text-fg-subtle",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "1 pago" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular",
								children: [
									draft.installments,
									" ",
									draft.installments === 1 ? "mes" : "meses"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "24" })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "note",
					children: "Nota"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "note",
					value: draft.note,
					onChange: (e) => onChange({
						...draft,
						note: e.target.value
					}),
					placeholder: "Folio, MSI, quién pagó…",
					rows: 2
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2 pt-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "flex-1",
					type: "button",
					onClick: onCancel,
					children: "Cancelar"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "flex-1",
					type: "button",
					onClick: submit,
					disabled: scanning || cards.length === 0,
					children: submitLabel
				})]
			})
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var scanReceipt = createServerFn({ method: "POST" }).validator((input) => {
	if (typeof input !== "object" || input === null) throw new Error("Datos inválidos");
	const image = input.image;
	if (typeof image !== "string" || image.length < 32) throw new Error("Imagen vacía");
	if (image.length > 28e5) throw new Error("La imagen es demasiado grande");
	return { image };
}).handler(createSsrRpc("f1d655a88e4fdbccfe967b7a3384ed8892acbd4ec73087cb0f489d3b808d185c"));
function AddExpense({ open, onClose, editing, forceManual = false, incomingFiles, onConsumedIncoming }) {
	const cards = useStore((s) => s.cards);
	const currency = useStore((s) => s.currency);
	const addExpense = useStore((s) => s.addExpense);
	const updateExpense = useStore((s) => s.updateExpense);
	const [step, setStep] = (0, import_react.useState)(editing ? "form" : incomingFiles && incomingFiles.length > 0 ? "reading" : forceManual ? "form" : "pick");
	const [preview, setPreview] = (0, import_react.useState)(editing?.receiptThumb ?? null);
	const [draft, setDraft] = (0, import_react.useState)(editing ? draftFromExpense(editing) : emptyDraft(cards[0]?.id ?? ""));
	const [hint, setHint] = (0, import_react.useState)(null);
	const [queue, setQueue] = (0, import_react.useState)([]);
	const handledRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!open) {
			handledRef.current = null;
			return;
		}
		setHint(null);
		setQueue([]);
		if (editing) {
			setStep("form");
			setPreview(editing.receiptThumb ?? null);
			setDraft(draftFromExpense(editing));
		} else if (incomingFiles && incomingFiles.length > 0) {} else {
			setStep(forceManual ? "form" : "pick");
			setPreview(null);
			setDraft(emptyDraft(cards[0]?.id ?? ""));
		}
	}, [open, editing]);
	(0, import_react.useEffect)(() => {
		if (!open || !incomingFiles?.length) return;
		if (handledRef.current === incomingFiles) return;
		handledRef.current = incomingFiles;
		const [first, ...rest] = incomingFiles;
		setQueue(rest);
		onConsumedIncoming?.();
		handleFile(first);
	}, [open, incomingFiles]);
	if (!open) return null;
	function resetAndClose() {
		setStep(editing ? "form" : "pick");
		setPreview(null);
		setHint(null);
		setQueue([]);
		setDraft(emptyDraft(cards[0]?.id ?? ""));
		onClose();
	}
	async function handleFile(file) {
		if (!isSupportedImage(file)) {
			toast.error("Usa una foto JPG o PNG del ticket.");
			setStep(editing ? "form" : "pick");
			return;
		}
		setStep("reading");
		setHint(null);
		try {
			const { scanSrc, thumb } = await prepareReceipt(file);
			setPreview(scanSrc);
			setDraft((d) => ({
				...d,
				receiptThumb: thumb,
				cardId: d.cardId || cards[0]?.id || ""
			}));
			const result = await scanReceipt({ data: { image: scanSrc } });
			if (!result.ok) {
				setHint(result.error);
				setStep("form");
				return;
			}
			const merchant = result.merchant || "";
			setDraft((d) => ({
				...d,
				merchant: merchant || d.merchant,
				amount: result.amount != null ? String(result.amount) : d.amount,
				date: result.date || d.date || todayISO(),
				category: result.category !== "other" ? result.category : guessCategory(merchant || d.merchant),
				installments: result.installments || d.installments || 1,
				note: result.note || d.note,
				receiptThumb: thumb
			}));
			if (!result.merchant && result.amount == null) setHint("No encontré el total. Revisa el ticket y completa el gasto. La foto queda adjunta.");
			setStep("form");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "No se pudo abrir esa imagen.");
			setStep(editing ? "form" : "pick");
		}
	}
	async function loadDemoTicket() {
		try {
			const blob = await (await fetch("/demo-ticket.png")).blob();
			await handleFile(new File([blob], "ticket.png", { type: "image/png" }));
		} catch {
			toast.error("No se pudo cargar el ticket de ejemplo.");
		}
	}
	function save() {
		const amount = parseAmount(draft.amount);
		if (amount == null || amount <= 0 || !draft.merchant.trim()) {
			toast.error("Falta el comercio o el monto.");
			return;
		}
		const payload = {
			cardId: draft.cardId || cards[0]?.id || "",
			merchant: draft.merchant.trim(),
			amount,
			category: draft.category,
			date: draft.date || todayISO(),
			installments: draft.installments,
			note: draft.note.trim(),
			receiptThumb: draft.receiptThumb
		};
		if (!payload.cardId) {
			toast.error("Primero agrega una tarjeta.");
			return;
		}
		if (editing) updateExpense(editing.id, payload);
		else addExpense(payload);
		if (!editing && queue.length > 0) {
			const [next, ...rest] = queue;
			setQueue(rest);
			toast.success("Gasto agregado. Siguiente ticket…");
			setDraft(emptyDraft(payload.cardId));
			handleFile(next);
			return;
		}
		toast.success(editing ? "Gasto actualizado" : "Gasto agregado");
		resetAndClose();
	}
	const queueLabel = queue.length > 0 ? ` · ${queue.length + 1} tickets` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex flex-col bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between px-4 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-fg-subtle",
				children: [editing ? "Editar" : "Nuevo gasto", queueLabel]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-medium tracking-tight",
				children: step === "pick" ? "Desde la galería" : step === "reading" ? "Leyendo ticket" : "Revisa los datos"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				onClick: resetAndClose,
				"aria-label": "Cerrar",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 overflow-y-auto px-4 pb-8",
			children: [
				step === "pick" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-lg flex-col gap-4 pt-2 fade-up",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GalleryLabel, {
							className: "flex min-h-56 flex-col items-center justify-center gap-3 rounded-xl bg-surface px-6 text-center shadow-[var(--shadow-border)]",
							onDragOver: (e) => {
								e.preventDefault();
							},
							onDrop: (e) => {
								e.preventDefault();
								const files = filesFromList(e.dataTransfer.files);
								if (files[0]) {
									setQueue(files.slice(1));
									handleFile(files[0]);
								}
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-14 items-center justify-center rounded-lg bg-surface-2 text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-6" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-base font-medium",
								children: "Elegir de la galería"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 max-w-xs text-sm text-fg-muted",
								children: "Abre tus fotos, elige el ticket y rellenamos el gasto. Puedes elegir varios."
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "secondary",
								className: "h-14",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(GalleryLabel, {
									htmlFor: CAMERA_INPUT_ID,
									className: "flex h-14 items-center justify-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" }), "Cámara"]
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "secondary",
								className: "h-14",
								onClick: () => {
									setDraft(emptyDraft(cards[0]?.id ?? ""));
									setPreview(null);
									setStep("form");
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Keyboard, { className: "size-4" }), "A mano"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void loadDemoTicket(),
							className: "text-center text-sm text-fg-muted underline-offset-4 hover:text-fg hover:underline",
							children: "Probar con un ticket de ejemplo"
						})
					]
				}) : null,
				step === "reading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-lg pt-2 fade-up",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden rounded-xl bg-surface",
						children: [preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: preview,
							alt: "Ticket seleccionado",
							className: "max-h-80 w-full object-contain outline outline-1 -outline-offset-1 outline-fg/10"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-64 items-center justify-center text-fg-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-6 animate-spin" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scan-line pointer-events-none absolute inset-x-0 top-0 h-px bg-accent shadow-[0_0_18px_var(--color-accent)]" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-center text-sm text-fg-muted",
						children: "Leyendo comercio, total y fecha…"
					})]
				}) : null,
				step === "form" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-lg pt-2 fade-up",
					children: [
						hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-4 rounded-md bg-surface px-3 py-2 text-sm text-fg-muted",
							children: hint
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpenseForm, {
							cards,
							currency,
							draft,
							onChange: setDraft,
							onSubmit: save,
							onCancel: resetAndClose,
							submitLabel: editing ? "Guardar cambios" : queue.length > 0 ? `Agregar y seguir (${queue.length} más)` : "Agregar gasto"
						}),
						editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								useStore.getState().deleteExpense(editing.id);
								toast.success("Gasto eliminado");
								resetAndClose();
							},
							className: "mt-3 w-full text-center text-sm text-danger",
							children: "Eliminar gasto"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GalleryLabel, {
							htmlFor: GALLERY_INPUT_ID,
							className: "mt-4 block w-full text-center text-sm text-fg-muted underline-offset-4 hover:text-fg hover:underline",
							children: "Elegir otra foto de la galería"
						})
					]
				}) : null
			]
		})]
	});
}
var COLOR_DOT = {
	navy: "bg-card-navy",
	wine: "bg-card-wine",
	forest: "bg-card-forest",
	ink: "bg-card-ink",
	slate: "bg-card-slate",
	rust: "bg-card-rust",
	ocean: "bg-card-ocean",
	plum: "bg-card-plum"
};
function fromCard(card) {
	return {
		name: card?.name ?? "",
		last4: card?.last4 ?? "",
		brand: card?.brand ?? "visa",
		color: card?.color ?? "navy",
		limit: card ? String(card.limit) : "",
		closeDay: String(card?.closeDay ?? 12),
		dueDay: String(card?.dueDay ?? 20)
	};
}
function CardEditor({ open, card, currency, onClose, onSave, onDelete }) {
	const [draft, setDraft] = (0, import_react.useState)(fromCard(card));
	if (!open) return null;
	const preview = {
		id: card?.id ?? "preview",
		name: draft.name || "Nueva tarjeta",
		last4: draft.last4.replace(/\D/g, "").slice(0, 4).padStart(4, "0"),
		brand: draft.brand,
		color: draft.color,
		limit: parseAmount(draft.limit) ?? 0,
		closeDay: Number(draft.closeDay) || 1,
		dueDay: Number(draft.dueDay) || 1,
		createdAt: card?.createdAt ?? ""
	};
	function save() {
		const last4 = draft.last4.replace(/\D/g, "").slice(-4);
		const limit = parseAmount(draft.limit);
		const closeDay = Math.min(28, Math.max(1, Number(draft.closeDay) || 1));
		const dueDay = Math.min(28, Math.max(1, Number(draft.dueDay) || 1));
		if (!draft.name.trim() || last4.length !== 4 || limit == null || limit <= 0) return;
		onSave({
			name: draft.name.trim(),
			last4,
			brand: draft.brand,
			color: draft.color,
			limit,
			closeDay,
			dueDay
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex flex-col bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between px-4 pb-2 pt-[max(0.75rem,env(safe-area-inset-top))]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-fg-subtle",
				children: card ? "Editar" : "Nueva"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl font-medium tracking-tight",
				children: "Tarjeta"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				onClick: onClose,
				"aria-label": "Cerrar",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-lg flex-1 flex-col gap-5 overflow-y-auto px-4 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlasticCard, {
					card: preview,
					currency
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "card-name",
						children: "Nombre"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "card-name",
						value: draft.name,
						onChange: (e) => setDraft({
							...draft,
							name: e.target.value
						}),
						placeholder: "Nu, BBVA Azul…"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "last4",
							children: "Últimos 4"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "last4",
							inputMode: "numeric",
							maxLength: 4,
							value: draft.last4,
							onChange: (e) => setDraft({
								...draft,
								last4: e.target.value.replace(/\D/g, "").slice(0, 4)
							}),
							placeholder: "4412",
							className: "font-mono tracking-[0.2em]"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "limit",
							children: "Límite"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "limit",
							inputMode: "decimal",
							value: draft.limit,
							onChange: (e) => setDraft({
								...draft,
								limit: e.target.value
							}),
							placeholder: "35000",
							className: "tabular"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Red" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: CARD_BRANDS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setDraft({
								...draft,
								brand: b
							}),
							className: cn("h-9 rounded-full px-3 text-xs font-medium", draft.brand === b ? "bg-accent text-accent-fg" : "bg-surface text-fg-muted"),
							children: BRAND_LABEL[b]
						}, b))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Color" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: CARD_COLORS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": c,
							onClick: () => setDraft({
								...draft,
								color: c
							}),
							className: cn("size-9 rounded-full shadow-[var(--shadow-border)]", COLOR_DOT[c], draft.color === c && "ring-2 ring-accent ring-offset-2 ring-offset-bg")
						}, c))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "close",
							children: "Día de corte"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "close",
							inputMode: "numeric",
							value: draft.closeDay,
							onChange: (e) => setDraft({
								...draft,
								closeDay: e.target.value.replace(/\D/g, "").slice(0, 2)
							})
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "due",
							children: "Día de pago"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "due",
							inputMode: "numeric",
							value: draft.dueDay,
							onChange: (e) => setDraft({
								...draft,
								dueDay: e.target.value.replace(/\D/g, "").slice(0, 2)
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto flex flex-col gap-2 pt-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: save,
						children: card ? "Guardar tarjeta" : "Agregar tarjeta"
					}), card && onDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "text-danger",
						onClick: onDelete,
						children: "Eliminar tarjeta"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: onClose,
						children: "Cancelar"
					})]
				})
			]
		})]
	});
}
function AppShell() {
	const hydrated = useStore((s) => s.hydrated);
	const setHydrated = useStore((s) => s.setHydrated);
	const tab = useStore((s) => s.tab);
	const setTab = useStore((s) => s.setTab);
	const cards = useStore((s) => s.cards);
	const expenses = useStore((s) => s.expenses);
	const currency = useStore((s) => s.currency);
	const addCard = useStore((s) => s.addCard);
	const updateCard = useStore((s) => s.updateCard);
	const deleteCard = useStore((s) => s.deleteCard);
	const [cycle, setCycle] = (0, import_react.useState)(() => {
		const first = useStore.getState().cards[0];
		if (first) return currentCycleKey(first);
		const n = /* @__PURE__ */ new Date();
		return {
			year: n.getFullYear(),
			month: n.getMonth()
		};
	});
	const [addOpen, setAddOpen] = (0, import_react.useState)(false);
	const [addMode, setAddMode] = (0, import_react.useState)("pick");
	const [editingExpense, setEditingExpense] = (0, import_react.useState)(null);
	const [incomingFiles, setIncomingFiles] = (0, import_react.useState)(void 0);
	const [cardOpen, setCardOpen] = (0, import_react.useState)(false);
	const [editingCardId, setEditingCardId] = (0, import_react.useState)(null);
	const [dropOver, setDropOver] = (0, import_react.useState)(false);
	const onGalleryFiles = (0, import_react.useCallback)((files) => {
		const images = files.filter(isSupportedImage);
		if (!images.length) return;
		setAddOpen((wasOpen) => {
			if (!wasOpen) {
				setEditingExpense(null);
				setAddMode("pick");
			}
			return true;
		});
		setIncomingFiles(images);
	}, []);
	(0, import_react.useEffect)(() => {
		const unsub = useStore.persist.onFinishHydration(() => setHydrated(true));
		if (useStore.persist.hasHydrated()) setHydrated(true);
		return unsub;
	}, [setHydrated]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		if (cards[0]) setCycle(currentCycleKey(cards[0]));
	}, [hydrated]);
	(0, import_react.useEffect)(() => {
		function onPaste(e) {
			const target = e.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) {
				if (!(e.clipboardData?.files)?.length) return;
			}
			const files = filesFromList(e.clipboardData?.files ?? null);
			if (!files.length && e.clipboardData) {
				for (const item of Array.from(e.clipboardData.items ?? [])) if (item.type.startsWith("image/")) {
					const file = item.getAsFile();
					if (file) files.push(file);
				}
			}
			if (!files.length) return;
			e.preventDefault();
			onGalleryFiles(files);
		}
		window.addEventListener("paste", onPaste);
		return () => window.removeEventListener("paste", onPaste);
	}, [onGalleryFiles]);
	(0, import_react.useEffect)(() => {
		function hasFiles(e) {
			return Array.from(e.dataTransfer?.types ?? []).includes("Files");
		}
		function onDragOver(e) {
			if (!hasFiles(e)) return;
			e.preventDefault();
			setDropOver(true);
		}
		function onDragLeave(e) {
			if (e.relatedTarget == null) setDropOver(false);
		}
		function onDrop(e) {
			e.preventDefault();
			setDropOver(false);
			const files = filesFromList(e.dataTransfer?.files ?? null);
			if (files.length) onGalleryFiles(files);
		}
		window.addEventListener("dragover", onDragOver);
		window.addEventListener("dragleave", onDragLeave);
		window.addEventListener("drop", onDrop);
		return () => {
			window.removeEventListener("dragover", onDragOver);
			window.removeEventListener("dragleave", onDragLeave);
			window.removeEventListener("drop", onDrop);
		};
	}, [onGalleryFiles]);
	const editingCard = (0, import_react.useMemo)(() => cards.find((c) => c.id === editingCardId) ?? null, [cards, editingCardId]);
	function openManual() {
		setEditingExpense(null);
		setIncomingFiles(void 0);
		setAddMode("manual");
		setAddOpen(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-dvh max-w-lg bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GalleryFileInputs, { onFiles: (files) => onGalleryFiles(files) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "px-4 pb-28 pt-[max(1rem,env(safe-area-inset-top))]",
				children: [
					tab === "home" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeView, {
						cycle,
						onCycle: setCycle,
						onAdd: openManual,
						onDemoTicket: () => {
							(async () => {
								try {
									const blob = await (await fetch("/demo-ticket.png")).blob();
									const file = new File([blob], "ticket.png", { type: "image/png" });
									onGalleryFiles([file]);
								} catch {}
							})();
						},
						onOpenExpense: (id) => {
							const e = expenses.find((x) => x.id === id);
							if (!e) return;
							setIncomingFiles(void 0);
							setEditingExpense(e);
							setAddOpen(true);
						},
						onOpenCard: (id) => {
							setEditingCardId(id);
							setCardOpen(true);
						}
					}) : null,
					tab === "cards" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardsView, {
						cycle,
						onAdd: () => {
							setEditingCardId(null);
							setCardOpen(true);
						},
						onOpen: (id) => {
							setEditingCardId(id);
							setCardOpen(true);
						}
					}) : null,
					tab === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryView, {
						cycle,
						onOpenExpense: (id) => {
							const e = expenses.find((x) => x.id === id);
							if (!e) return;
							setIncomingFiles(void 0);
							setEditingExpense(e);
							setAddOpen(true);
						}
					}) : null,
					tab === "insights" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsightsView, { cycle }) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-40 border-t border-border bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-lg items-end justify-around px-2 pt-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							id: "home",
							tab,
							onClick: setTab,
							label: "Inicio",
							icon: House
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							id: "cards",
							tab,
							onClick: setTab,
							label: "Tarjetas",
							icon: CreditCard
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GalleryLabel, {
							htmlFor: GALLERY_INPUT_ID,
							className: "-mt-5 flex size-14 items-center justify-center rounded-full bg-accent text-accent-fg shadow-[var(--shadow-lift)]",
							"aria-label": "Agregar gasto desde galería",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "size-6" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							id: "history",
							tab,
							onClick: setTab,
							label: "Historial",
							icon: Receipt
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
							id: "insights",
							tab,
							onClick: setTab,
							label: "Análisis",
							icon: ChartColumn
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddExpense, {
				open: addOpen,
				editing: editingExpense,
				forceManual: addMode === "manual" && !editingExpense,
				incomingFiles,
				onConsumedIncoming: () => setIncomingFiles(void 0),
				onClose: () => {
					setAddOpen(false);
					setEditingExpense(null);
					setIncomingFiles(void 0);
				}
			}, editingExpense?.id ?? (addOpen ? "new" : "idle")),
			cardOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardEditor, {
				open: true,
				card: editingCard,
				currency,
				onClose: () => setCardOpen(false),
				onSave: (data) => {
					if (editingCard) updateCard(editingCard.id, data);
					else addCard(data);
					setCardOpen(false);
				},
				onDelete: editingCard ? () => {
					deleteCard(editingCard.id);
					setCardOpen(false);
				} : void 0
			}, editingCardId ?? "new-card") : null,
			dropOver ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[60] flex items-center justify-center bg-bg/80 px-8 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-surface px-8 py-10 shadow-[var(--shadow-lift)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image$1, { className: "mx-auto size-8 text-accent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-xl",
							children: "Suelta el ticket"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-fg-muted",
							children: "Se abre como un gasto nuevo, con la foto adjunta."
						})
					]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center"
			})
		]
	});
}
function NavBtn({ id, tab, onClick, label, icon: Icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: () => onClick(id),
		className: cn("flex min-w-14 flex-col items-center gap-1 py-1 text-[11px] font-medium", tab === id ? "text-fg" : "text-fg-subtle"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }), label]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
